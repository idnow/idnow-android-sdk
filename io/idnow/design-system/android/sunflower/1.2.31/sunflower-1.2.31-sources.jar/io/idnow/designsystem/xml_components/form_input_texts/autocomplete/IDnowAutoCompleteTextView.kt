package io.idnow.designsystem.xml_components.form_input_texts.autocomplete

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.util.AttributeSet
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AutoCompleteTextView
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.doOnNextLayout
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import androidx.core.widget.doOnTextChanged
import io.idnow.designsystem.R
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.databinding.IdnowAutoCompleteTextViewBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowFormInputs
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItem
import io.idnow.designsystem.xml_components.form_input_texts.common.OnIDnowItemSelected

class IDnowAutoCompleteTextView : IDnowFormInputs {
    /** Stub binding, replace the view stub with a auto complete view. */
    private var autoCompleteBinding: IdnowAutoCompleteTextViewBinding

    /** The autocomplete dropdown adapter */
    private val dropdownAdapter by lazy { IDnowAutoCompleteAdapter(context = context, autoCompleteFilterType = autoCompleteFilterType) }

    /** Set the suggestion list to be displayed in the autocomplete dropdown. */
    var autoCompleteSuggestions: List<IDnowItem> = emptyList()
        set(value) {
            field = value
            dropdownAdapter.onDatasetUpdated(value)
        }

    /** Change the autocomplete hint */
    var hint: CharSequence
        get() = autoCompleteBinding.idnAutocomplete.hint.toString()
        set(value) {
            autoCompleteBinding.idnAutocomplete.hint = value
        }

    /** Display or hide the trailing icon. */
    var showLeadingIcon: Boolean = true
        set(value) {
            field = value
            displayViewWithIcon(binding.idnContLeadingIcon, if (value) ResourcesCompat.getDrawable(resources, R.drawable.sunflower_ic_magnifying_glass, null) else null)
        }

    /** Display or hide the clear icon. */
    var clearIcon: Boolean = false
        set(value) {
            field = value
            binding.idnContClear.isVisible = (autoCompleteBinding.idnAutocomplete.text?.isNotEmpty() == true && value)
        }

    /** Update the auto complete filter type */
    var autoCompleteFilterType: AutoCompleteFilterType = AutoCompleteFilterType.CONTAINS
        set(value) {
            field = value
            dropdownAdapter.autoCompleteFilterType = value
        }

    /** Set this value to receive callback on item selected. */
    var onIDnowItemSelected: OnIDnowItemSelected? = null

    init {
        binding.idnField.layoutResource = R.layout.idnow_auto_complete_text_view
        autoCompleteBinding = IdnowAutoCompleteTextViewBinding.bind(binding.idnField.inflate())
    }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowAutoCompleteTextView)
        hint = customArray.getString(R.styleable.IDnowAutoCompleteTextView_hint) ?: ""
        clearIcon = customArray.getBoolean(R.styleable.IDnowAutoCompleteTextView_clearIcon, false)
        showLeadingIcon = customArray.getBoolean(R.styleable.IDnowAutoCompleteTextView_showLeadingIcon, true)
        val inputType = customArray.getInt(R.styleable.IDnowAutoCompleteTextView_android_inputType, InputType.TYPE_CLASS_TEXT)
        isEnabled = customArray.getBoolean(R.styleable.IDnowAutoCompleteTextView_android_enabled, true)
        autoCompleteFilterType = AutoCompleteFilterType.entries[customArray.getInt(R.styleable.IDnowAutoCompleteTextView_filter_type, AutoCompleteFilterType.CONTAINS.ordinal)]
        customArray.recycle()
        initialize(inputType = inputType)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initialize(inputType: Int) {
        with(FormInputsStyle) {
            autoCompleteBinding.idnAutocomplete.apply {
                /** Set the input type to the edit text. */
                this.inputType = inputType
                // Set top and bottom as padding to have more space to click (recommended by Android for accessibility)
                setPadding(itemMargin.toDp(context))
                setTypography(ContainerStyle.font(context))
                setTextColor(ContainerStyle.textColor)
                setHintTextColor(Utils.adjustAlpha(ContainerStyle.textColor, ContainerStyle.hintOpacity))
                // It is not possible to update (without reflection) the cursor color below API 29.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    textCursorDrawable?.setTint(ContainerStyle.Filling.strokeColor)
                }
                dropDownVerticalOffset = 0
                setAdapter(dropdownAdapter)
                setOnTouchListener { _, _ ->
                    if (isPopupShowing.not()) {
                        showDropDown()
                        /** Call filter manually when showing the dropdown */
                        dropdownAdapter.filter.filter(text)
                    }
                    false
                }
                /** Update the drop down style */
                (dropDownBackground as GradientDrawable).apply {
                    cornerRadius = ContainerStyle.cornerRadius.toDp(context).toFloat()
                    setStroke(strokeWidth.toDp(context), popupBackgroundColor)
                    setColor(popupBackgroundColor)
                }
                /** Transmit the on item click callback */
                setOnItemClickListener { _, _, position, _ ->
                    dropdownAdapter.itemList.getOrNull(position)?.let {
                        onIDnowItemSelected?.onItemSelected(it)
                    }
                }
                /** Set a clear action */
                if(!binding.idnContClear.hasOnClickListeners()) {
                    binding.idnContClear.setOnClickListener {
                        text.clear()
                    }
                }
                /** Set on text change listener */
                doOnTextChanged { text, _, _, _ ->
                    binding.idnContClear.isVisible = (text?.isNotEmpty() == true && clearIcon)
                }
                /** Set IME option keyboard click listener */
                setOnEditorActionListener { _, actionId, _ ->
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        clearFocus()
                        binding.idnContClear.clearFocus()
                    }
                    false
                }
                doOnNextLayout {
                    dropDownWidth = binding.idnContainer.width
                    if (showLeadingIcon) {
                        /** Apply offset so the dropdown will show at the beginning of the container */
                        dropDownHorizontalOffset = - (binding.idnContLeadingIcon.width + itemMargin.toDp(context))
                    }
                }
            }
            /** Move focus to main auto complete when clicking on search icon */
            binding.idnContLeadingIcon.setOnTouchListener { _, event ->
                autoCompleteBinding.idnAutocomplete.dispatchTouchEvent(event)
                true
            }
        }

        /** Set content description */
        setContentDescription()
    }

    /** Set a custom clear button clicked listener if needed. */
    fun setOnClearClickListener(lambda: (() -> Unit)?) {
        lambda?.let {
            binding.idnContClear.setOnClickListener { it() }
        } ?: run {
            binding.idnContClear.setOnClickListener {
                autoCompleteBinding.idnAutocomplete.text.clear()
            }
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        autoCompleteBinding.idnAutocomplete.isEnabled = enabled
    }

    /** Expose the autoCompleteTextView to allow the use of specific autoCompleteTextView callbacks. */
    fun getAutoComplete(): AutoCompleteTextView = autoCompleteBinding.idnAutocomplete

    enum class AutoCompleteFilterType {
        CONTAINS, STARTS_WITH
    }

    override fun setContentDescription() {
        @Suppress("UNNECESSARY_SAFE_CALL") // Wrong it will be null in some cases.
        if(autoCompleteBinding?.idnAutocomplete == null) return
        ViewCompat.setAccessibilityDelegate(autoCompleteBinding.idnAutocomplete, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.text = getAccessibilityContentText().append(info.text ?: "")
            }
        })
    }
}