package io.idnow.designsystem.xml_components.form_input_texts.spinner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import androidx.core.content.res.ResourcesCompat
import androidx.core.content.withStyledAttributes
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.doOnDetach
import androidx.core.view.doOnLayout
import androidx.core.view.doOnNextLayout
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowSpinnerBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowFormInputs
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItem
import io.idnow.designsystem.xml_components.form_input_texts.common.OnIDnowItemSelected

class IDnowSpinner : IDnowFormInputs {
    /** Stub binding, replace the view stub with a spinner. */
    private var spinnerBinding: IdnowSpinnerBinding

    /** Hint which will be displayed by default and does not result in a concrete item. */
    private var hint: CharSequence? = null

    /** Set the item list to display in the spinner. */
    var itemList: List<IDnowItem> = emptyList()
        set(value) {
            field = value
            spinnerBinding.idnContSpinner.adapter = IDnowAdapter(context, value, hint?.let { IDnowItem(null, it) })
            // Hint is the last item in the list, so we select it by default.
            if (hint != null) spinnerBinding.idnContSpinner.setSelection(value.size)
        }

    /** Set this value to receive callback on item selected. */
    var onIDnowItemSelectedListener: OnIDnowItemSelected? = null

    init {
        binding.idnField.layoutResource = R.layout.idnow_spinner
        spinnerBinding = IdnowSpinnerBinding.bind(binding.idnField.inflate())
    }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        context.withStyledAttributes(attrs, R.styleable.IDnowSpinner, defStyleAttr) {
            hint = getString(R.styleable.IDnowSpinner_hint)
        }
        initialize()
    }

    private fun initialize() {
        /** To apply the token to all the constraints, we need to update them all with the tokens here. */
        doOnLayout { updateConstraints() }

        /** Set content description */
        setContentDescription()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun updateConstraints() {
        binding.idnContTrailingIcon.apply {
            val drawable = ResourcesCompat.getDrawable(resources, R.drawable.sunflower_ic_chevron_up_down, null)
            displayViewWithIcon(this, drawable)
            /* It's voluntary that we don't perform a click as we are transmitting the event directly to the spinner. */
            setOnTouchListener { _, event ->
                spinnerBinding.idnContSpinner.dispatchTouchEvent(event)
                true
            }
        }
        spinnerBinding.idnContSpinner.apply {
            /** Prepare the focus of the view by registering it to be focus on newt windows focus change if it was pressed*/
            setOnTouchListener { _, _ ->
                binding.idnContainer.requestFocus()
                binding.idnContTrailingIcon.isSelected = true
                false
            }

            val spinnerFocusObserver = ViewTreeObserver.OnWindowFocusChangeListener { isWindowFocus ->
                if (isWindowFocus) {
                    binding.idnContTrailingIcon.isSelected = false
                }
            }
            viewTreeObserver.addOnWindowFocusChangeListener(spinnerFocusObserver)
            doOnDetach { viewTreeObserver.removeOnWindowFocusChangeListener(spinnerFocusObserver) }

            /** Update the drop down style */
            (popupBackground as GradientDrawable).apply {
                cornerRadius = ContainerStyle.cornerRadius.toDp(context).toFloat()
                setStroke(FormInputsStyle.strokeWidth.toDp(context), FormInputsStyle.popupBackgroundColor)
                setColor(FormInputsStyle.popupBackgroundColor)
            }
            /** Transmit the on item selected callback and update the adapter to show a check in the dropdown */
            onItemSelectedListener = object : OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val adapter = spinnerBinding.idnContSpinner.adapter as IDnowAdapter
                    adapter.selection = position
                    onIDnowItemSelectedListener?.onItemSelected(getItemAtPosition(position) as IDnowItem)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) { /* Do nothing here */
                }
            }
            doOnNextLayout {
                dropDownWidth = binding.idnContainer.width
                // TODO We may improve this to make it work also when displayed on top.
                dropDownVerticalOffset = binding.idnContainer.height
            }
        }
    }

    /**
     * Jump directly to a specific item in the adapter data.
     * @param iDnowItem the specific item
     * @param animate animate the transition to the specific item
     */
    fun setSelection(iDnowItem: IDnowItem, animate: Boolean = false) {
        val position = (spinnerBinding.idnContSpinner.adapter as IDnowAdapter).findPositionForItem(iDnowItem)
        spinnerBinding.idnContSpinner.setSelection(position, animate)
    }

    /**
     * @return The data corresponding to the currently selected item, or null if there is nothing selected.
     */
    fun getSelectedItem(): IDnowItem? {
        return spinnerBinding.idnContSpinner.selectedItem as? IDnowItem
    }

    override fun setContentDescription() {
        @Suppress("UNNECESSARY_SAFE_CALL", "KotlinConstantConditions") // Wrong it will be null in some cases.
        if (spinnerBinding?.idnContSpinner == null) return
        ViewCompat.setAccessibilityDelegate(spinnerBinding.idnContSpinner, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.text = getAccessibilityContentText().append(info.text ?: "")
            }
        })
    }

    override fun onDetachedFromWindow() {
        this.onIDnowItemSelectedListener = null
        super.onDetachedFromWindow()
    }
}