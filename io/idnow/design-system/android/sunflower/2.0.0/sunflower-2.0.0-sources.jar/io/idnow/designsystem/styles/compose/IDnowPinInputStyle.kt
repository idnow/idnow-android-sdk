package io.idnow.designsystem.styles.compose

import android.graphics.Paint
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.styles.xml.ContainerStyle
import io.idnow.designsystem.tokens.Tokens

/**
 * Resolved visual values for the Compose IDnowPinInput. Mirrors the XML's ContainerStyle states
 * (Empty/Filling/Error/Disabled) + the IDnowPinDrawable metrics.
 */
@Immutable
data class IDnowPinInputStyle(
    /** Pre-built Android Paint for drawing digits in the Canvas (typeface + color + textSize).
     * Reused for both height calculation and digit rendering — single source of truth. */
    val digitPaint: Paint,
    /** Rounded corner radius of each box. */
    val boxCornerRadius: Dp,
    /** Width of one box (content + internal padding × 2). */
    val boxWidth: Dp,
    /** Height of one box (taller than wide, matching XML minHeight 48dp). */
    val boxHeight: Dp,
    /** Space between adjacent boxes. */
    val boxSpacing: Dp,
    /** Stroke width for the normal (empty) box. */
    val emptyStrokeWidth: Dp,
    /** Stroke width for the focused/filling AND error box (both use 2dp in XML). */
    val activeStrokeWidth: Dp,
    /** Stroke color per state. */
    val emptyStrokeColor: Color,
    val fillingStrokeColor: Color,
    val errorStrokeColor: Color,
    val disabledFillColor: Color,
    /** Error text style (BODY_SMALL, error color). */
    val errorTextStyle: TextStyle,
    /** Error icon color (= error token). */
    val errorColor: Color,
    /** Error icon size (idnow_text_icon_size = 19dp). */
    val errorIconSize: Dp,
    /** Eye icon tint (ACCENT token). */
    val eyeIconColor: Color,
)

object IDnowPinInputDefaults {

    @Composable
    fun style(): IDnowPinInputStyle {
        val primitives = IDnowDesignSystem.primitives
        // Box metrics: content = 24dp, internal padding = 8dp → width = 24 + 2×8 = 40dp.
        // Height mirrors XML IDnowPinDrawable exactly:
        //   val lineHeight = fontMetrics.bottom - fontMetrics.top
        //   height = (lineHeight * lineSpacingMultiplier + internalPaddingTotal).roundToInt()
        // where textSize = typography.size * density (px), internalPaddingTotal = boxInternalPadding * 2 (px).
        val boxContentSize = 24.dp
        val boxInternalPadding = SpacingEnum.SPACING_SM.dp // 8dp
        val boxWidth = boxContentSize + boxInternalPadding * 2 // 40dp

        val density = LocalDensity.current.density
        val typo = TypographyEnum.BODY_BOLD_LARGE.toTypography(LocalContext.current)
        // Single Paint used for both height calculation AND digit rendering in the composable.
        val digitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = typo.size * density
            typeface = typo.typeface
            color = Tokens.inputText
        }
        val fm = digitPaint.fontMetrics
        val lineHeightPx = fm.bottom - fm.top
        val internalPaddingPx = boxInternalPadding.value * density
        val boxHeightPx = (lineHeightPx * typo.lineSpacingMultiplier + internalPaddingPx * 2)
        val boxHeight = (boxHeightPx / density).dp

        return IDnowPinInputStyle(
            digitPaint = digitPaint,
            boxCornerRadius = ContainerStyle.cornerRadius.dp, // radiusMd
            boxWidth = boxWidth,
            boxHeight = boxHeight,
            boxSpacing = SpacingEnum.SPACING_SM.dp,
            emptyStrokeWidth = ContainerStyle.Empty.strokeWidth.dp, // 1dp
            activeStrokeWidth = ContainerStyle.Filling.strokeWidth.dp, // 2dp (same for error)
            emptyStrokeColor = Color(ContainerStyle.Empty.strokeColor),
            fillingStrokeColor = Color(ContainerStyle.Filling.strokeColor),
            errorStrokeColor = Color(ContainerStyle.Error.strokeColor),
            disabledFillColor = Color(ContainerStyle.Disabled.strokeColor),
            errorTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(Color(Tokens.error))
                .copy(platformStyle = PlatformTextStyle(includeFontPadding = false)),
            errorColor = Color(Tokens.error),
            errorIconSize = dimensionResource(R.dimen.idnow_text_icon_size), // 19dp
            eyeIconColor = TintColorEnum.ACCENT.composeColor,
        )
    }
}
