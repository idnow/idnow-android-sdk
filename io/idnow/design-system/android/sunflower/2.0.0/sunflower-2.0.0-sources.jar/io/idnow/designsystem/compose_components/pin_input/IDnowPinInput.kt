package io.idnow.designsystem.compose_components.pin_input

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.editableText
import androidx.compose.ui.semantics.maxTextLength
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.styles.compose.IDnowPinInputDefaults
import io.idnow.designsystem.styles.compose.IDnowPinInputStyle
import kotlinx.coroutines.delay

/** PIN visibility mode, mirrors the XML `type` attribute. */
enum class IDnowPinType {
    /** Content is always hidden (•). */
    HIDDEN,
    /** Toggle show/hide via the eye icon. When hidden, the last entered digit is briefly visible. */
    VIEWABLE,
    /** Content is always visible (digits displayed). */
    VISIBLE,
}

/**
 * State holder for [IDnowPinInput]. Created via [rememberIDnowPinInputState].
 * Provides [clear] and [fill] actions to the integrator.
 */
class IDnowPinInputState internal constructor(initial: String) {
    internal var value by mutableStateOf(initial)
        private set

    /** Clear all entered digits. */
    fun clear() { value = "" }

    /** Fill the input with [content]. */
    fun fill(content: String) { value = content }

    internal fun append(c: Char, pinSize: Int) { if (value.length < pinSize) value += c }
    internal fun removeLast() { if (value.isNotEmpty()) value = value.dropLast(1) }
}

/** Create and remember an [IDnowPinInputState] that survives configuration changes. */
@Composable
fun rememberIDnowPinInputState(initial: String = ""): IDnowPinInputState {
    return rememberSaveable(saver = Saver(
        save = { it.value },
        restore = { IDnowPinInputState(it) },
    )) { IDnowPinInputState(initial) }
}

/**
 * Compose counterpart of the XML `IDnowPinInput`.
 *
 * A single-focus PIN entry field that draws [pinSize] boxes. Digits are entered one by one and
 * deleted from the end (sequential only — no individual selection). The entire component is one
 * accessibility focus node.
 *
 * @param pinSize the number of boxes.
 * @param type visibility mode (HIDDEN/VIEWABLE/VISIBLE).
 * @param errorText when non-null, displayed above the boxes as an error message.
 * @param enabled when false, input is disabled.
 * @param lastBoxVisibilityMillis in HIDDEN/VIEWABLE-hidden, how long the last digit stays visible.
 * @param accessibilityLabel the type of code announced by TalkBack (e.g. "Pin", "Code"). The field
 *   is read as "$accessibilityLabel. $pinSize digits. Edit Box. Double-tap to edit text."
 * @param onDigitAdded called when a digit is appended.
 * @param onDigitRemoved called when the last digit is removed.
 */
@Composable
fun IDnowPinInput(
    pinSize: Int,
    accessibilityLabel: String,
    modifier: Modifier = Modifier,
    state: IDnowPinInputState = rememberIDnowPinInputState(),
    type: IDnowPinType = IDnowPinType.VIEWABLE,
    errorText: String? = null,
    enabled: Boolean = true,
    lastBoxVisibilityMillis: Long = 1000L,
    onDigitAdded: ((Char) -> Unit)? = null,
    onDigitRemoved: (() -> Unit)? = null,
) {
    val value = state.value
    val style = IDnowPinInputDefaults.style()
    val isError = errorText != null

    // Eye-toggle state (only for VIEWABLE type) — survives rotation.
    var isContentVisible by rememberSaveable { mutableStateOf(type == IDnowPinType.VISIBLE) }

    // "Last digit visible" timer: temporarily reveal the last digit only when a digit is ADDED
    // (never on deletion). Track previous value to skip reveal on restoration (rotation): if value
    // hasn't actually changed (same as previous), it's a recomposition/restoration → don't re-reveal.
    var lastRevealedIndex by remember { mutableIntStateOf(-1) }
    var previousValue by remember { mutableStateOf(value) }
    LaunchedEffect(value) {
        if (value == previousValue) return@LaunchedEffect // restoration, not a real change
        val digitAdded = value.length > previousValue.length
        previousValue = value
        if (digitAdded && !isContentVisible && type != IDnowPinType.VISIBLE) {
            lastRevealedIndex = value.lastIndex
            delay(lastBoxVisibilityMillis)
            lastRevealedIndex = -1
        } else {
            // Deletion / clear: hide everything immediately, no reveal of the new last digit.
            lastRevealedIndex = -1
        }
    }

    Column(modifier = modifier) {
        // Error row (above boxes): warning icon (19dp) + error text (BODY_SMALL, error color).
        // Margin = SPACING_SM (8dp) between error and boxes (XML verItemMargin(NORMAL)).
        if (isError) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = SpacingEnum.SPACING_SM.dp),
            ) {
                Image(
                    painter = painterResource(R.drawable.sunflower_ic_warning),
                    contentDescription = null,
                    colorFilter = ColorFilter.tint(style.errorColor),
                    modifier = Modifier.size(style.errorIconSize),
                )
                Spacer(Modifier.width(SpacingEnum.SPACING_SM.dp))
                BasicText(
                    text = errorText,
                    style = style.errorTextStyle,
                )
            }
        }

        // PIN boxes + eye toggle + invisible BasicTextField.
        // A11y: read error FIRST (warning prefix), then label + number_of_digits string. TalkBack appends "Edit Box".
        val warningPrefix = stringResource(R.string.sunflower_warning)
        val numberOfDigits = stringResource(R.string.sunflower_number_of_digits, pinSize.toString())
        val contDescription = buildString {
            if (isError) {
                append("$warningPrefix. $errorText${if (!errorText.endsWith(".")) "." else ""} ")
            }
            append("$accessibilityLabel. $numberOfDigits")
        }
        var isFocused by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            // The hidden BasicTextField captures keyboard; decorationBox draws the boxes.
            BasicTextField(
                value = value,
                onValueChange = { newText ->
                    if (!enabled) return@BasicTextField
                    val filtered = newText.filter { it.isDigit() }.take(pinSize)
                    when {
                        // Exactly one digit appended at the end.
                        filtered.length == value.length + 1 && filtered.startsWith(value) -> {
                            state.append(filtered.last(), pinSize)
                            onDigitAdded?.invoke(filtered.last())
                        }
                        // Exactly one digit removed from the end.
                        filtered.length == value.length - 1 && value.startsWith(filtered) -> {
                            state.removeLast()
                            onDigitRemoved?.invoke()
                        }
                        // Clear (select-all + delete).
                        filtered.isEmpty() && value.isNotEmpty() -> {
                            state.clear()
                        }
                        // Reject anything else (paste etc.).
                    }
                },
                enabled = enabled,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                // Make the text itself invisible — visuals are in decorationBox.
                textStyle = TextStyle(color = Color.Transparent),
                // semantics (not clear) so the BasicTextField keeps its editable role ("Edit Box. Double-tap to edit text.").
                modifier = Modifier
                    .onFocusChanged { isFocused = it.isFocused }
                    .semantics {
                        contentDescription = contDescription
                        editableText = if (!isContentVisible) {
                            AnnotatedString("•".repeat(value.length))
                        } else {
                            AnnotatedString(value.toList().joinToString(". ") { it.toString() })
                        }
                        maxTextLength = pinSize
                    },
                decorationBox = { innerTextField ->
                    Box {
                        PinBoxRow(
                            value = value,
                            pinSize = pinSize,
                            isContentVisible = isContentVisible,
                            lastRevealedIndex = lastRevealedIndex,
                            isError = isError,
                            enabled = enabled,
                            isFocused = isFocused,
                            style = style,
                        )
                        // Invisible inner text field to capture input/focus.
                        Box(Modifier.matchParentSize().alpha(0f)) { innerTextField() }
                    }
                },
            )

            // Eye icon (VIEWABLE only): tinted ACCENT, intrinsic size.
            if (type == IDnowPinType.VIEWABLE) {
                Spacer(Modifier.width(SpacingEnum.SPACING_SM.dp))
                val eyeRes = if (isContentVisible) R.drawable.sunflower_ic_eye_off else R.drawable.sunflower_ic_eye_on
                val eyeDesc = stringResource(if (isContentVisible) R.string.sunflower_hide_pin_input_content_description else R.string.sunflower_show_pin_input_content_description)
                Image(
                    painter = painterResource(eyeRes),
                    contentDescription = eyeDesc,
                    colorFilter = ColorFilter.tint(style.eyeIconColor),
                    modifier = Modifier.clickable {
                        isContentVisible = !isContentVisible
                        if (!isContentVisible) lastRevealedIndex = -1
                    },
                )
            }
        }
    }
}

/** Draws the row of N pin boxes. */
@Composable
private fun PinBoxRow(
    value: String,
    pinSize: Int,
    isContentVisible: Boolean,
    lastRevealedIndex: Int,
    isError: Boolean,
    enabled: Boolean,
    isFocused: Boolean,
    style: IDnowPinInputStyle,
) {
    Row(horizontalArrangement = Arrangement.spacedBy(style.boxSpacing)) {
        repeat(pinSize) { index ->
            val isFilling = isFocused && enabled && (index == value.length || (index == value.lastIndex && value.length == pinSize))
            val strokeColor = when {
                !enabled -> style.disabledFillColor
                // The currently focused/filling box keeps the active color, even in the error state.
                isFilling -> style.fillingStrokeColor
                isError -> style.errorStrokeColor
                else -> style.emptyStrokeColor
            }
            // Error AND filling both use the thicker stroke (2dp); empty uses thin (1dp).
            val strokeWidth = when {
                isError -> style.activeStrokeWidth
                isFilling -> style.activeStrokeWidth
                else -> style.emptyStrokeWidth
            }
            val boxShape = RoundedCornerShape(style.boxCornerRadius)

            Box(
                modifier = Modifier
                    .size(width = style.boxWidth, height = style.boxHeight)
                    .then(
                        if (!enabled) Modifier.background(style.disabledFillColor, boxShape)
                        else Modifier,
                    )
                    .border(strokeWidth, strokeColor, boxShape)
                    .clearAndSetSemantics { },
                contentAlignment = Alignment.Center,
            ) {
                if (index < value.length) {
                    val showDigit = isContentVisible || index == lastRevealedIndex
                    val displayChar = if (showDigit) value[index].toString() else "•"
                    // Center exactly like XML: baseline = height/2 - ascent/2, char centered horizontally.
                    // Uses style.digitPaint (single Paint built once in the style resolver).
                    Canvas(Modifier.matchParentSize()) {
                        val textBaseline = (size.height / 2f) - (style.digitPaint.fontMetrics.ascent / 2f)
                        val charWidth = style.digitPaint.measureText(displayChar)
                        val x = (size.width - charWidth) / 2f
                        drawIntoCanvas { canvas ->
                            canvas.nativeCanvas.drawText(displayChar, x, textBaseline, style.digitPaint)
                        }
                    }
                }
            }
        }
    }
}
