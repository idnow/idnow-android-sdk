package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values for [io.idnow.designsystem.compose_components.navigation.IDnowEntryButton],
 * the Compose mirror of the XML [io.idnow.designsystem.styles.xml.EntryButtonStyle] (+ the two
 * `idnow_entry_button*.xml` layouts and the `idnow_entry_button_lottie_size` dimen).
 *
 * Both variants share the rounded border ([cornerRadius] = `radiusMd`, [strokeColor] = `borderSecondary`,
 * [strokeWidth] = 1dp) and the dimmed description ([descriptionAlpha] = 0.83, the XML `descOpacity`).
 * The per-variant spacing differs: each layout uses a single base spacing for its content padding AND
 * the gap between the leading element, the text and the end icon ([mediumSpacing] = `SPACING_MD`,
 * [largeSpacing] = `SPACING_SM`), plus a smaller gap above the description ([mediumDescriptionGap] =
 * `SPACING_SM`, [largeDescriptionGap] = `SPACING_XS`). The Large leading Lottie is [lottieSize] square.
 *
 * Typography and text colors are NOT stored here: they are passed straight to `IDnowText` as the public
 * [io.idnow.designsystem.common.TypographyEnum] / [io.idnow.designsystem.common.TextColorEnum] token
 * enums by the composable (Medium: `BODY`/`BODY`, Large: `H5`/`HEADING`).
 */
@Immutable
data class IDnowEntryButtonStyle(
    /** Container corner radius (XML: `Tokens.radiusMd`). */
    val cornerRadius: Dp,
    /** Border color (XML: `Tokens.borderSecondary`). */
    val strokeColor: Color,
    /** Border width (XML: 1dp). */
    val strokeWidth: Dp,
    /** Medium content padding + leading/end-icon gap (XML: `SPACING_MD`). */
    val mediumSpacing: Dp,
    /** Gap above the Medium description (XML: title→description `SPACING_SM`). */
    val mediumDescriptionGap: Dp,
    /** Large content padding + lottie/end-icon gap (XML: `SPACING_SM`). */
    val largeSpacing: Dp,
    /** Gap above the Large description (XML: title→description `SPACING_XS`). */
    val largeDescriptionGap: Dp,
    /** Square size of the Large leading Lottie (XML dimen `idnow_entry_button_lottie_size` = 96dp). */
    val lottieSize: Dp,
    /** Description opacity, shared by both variants (XML: `EntryButtonStyle.descOpacity`). */
    val descriptionAlpha: Float,
)

/** Default resolver for [IDnowEntryButtonStyle], analogous to Material3's `XxxDefaults`. */
object IDnowEntryButtonDefaults {

    /** Description opacity, matching the XML `EntryButtonStyle.descOpacity`. */
    private const val DESCRIPTION_ALPHA = 0.83f

    /** Border width in dp, matching the XML `EntryButtonStyle.strokeWidth`. */
    private const val STROKE_WIDTH_DP = 1f

    @Composable
    fun style(): IDnowEntryButtonStyle = IDnowEntryButtonStyle(
        // radiusMd / borderSecondary have no enum, so they are read straight from Tokens here — only
        // allowed in a Defaults resolver. These reads transitively touch the snapshot-backed
        // IDnowDesignSystem.primitives, so a runtime re-theme recomposes the caller. The radius token
        // is a dp magnitude (see ComposeTokens unit note) → wrap as `Int.dp`.
        cornerRadius = Tokens.radiusMd.dp,
        strokeColor = Color(Tokens.borderSecondary),
        strokeWidth = STROKE_WIDTH_DP.dp,
        mediumSpacing = SpacingEnum.SPACING_MD.dp,
        mediumDescriptionGap = SpacingEnum.SPACING_SM.dp,
        largeSpacing = SpacingEnum.SPACING_SM.dp,
        largeDescriptionGap = SpacingEnum.SPACING_XS.dp,
        lottieSize = dimensionResource(R.dimen.idnow_entry_button_lottie_size),
        descriptionAlpha = DESCRIPTION_ALPHA,
    )
}
