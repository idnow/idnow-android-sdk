package io.idnow.designsystem.styles.xml

import android.content.Context
import androidx.annotation.Dimension
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography
import io.idnow.designsystem.xml_components.controls.common.Size

internal object ControlStyle {
    /**
     * Stroke of the color when inactive
     */
    val strokeColor get() = Tokens.borderTertiary

    /**
     * Color of the divider
     */
    val dividerColor get() = Tokens.borderPrimary

    /**
     * Color of a control when active
     */
    val activeColor get() = Tokens.success

    /**
     * Color of a control when not checked
     */
    val uncheckedColor get() = Tokens.backgroundTertiary

    /**
     * Color of a control thumb (knob)
     */
    val toggleKnobColor get() = Tokens.backgroundPrimary

    /**
     * Border radius, checkbox (used also for the borders)
     */
    fun checkBoxRadius(size: Size) = if(size == Size.SMALL) Tokens.radiusSm else Tokens.radiusMd

    /**
     * Container stroke width
     */
    @Dimension(unit = Dimension.DP)
    fun strokeWidth(isActive: Boolean = true) = if (isActive) 2 else 1

    /**
     * Icon color
     */
    val iconColor get() = Tokens.overlay

    /**
     * Enable/Disable opacity
     */
    fun opacity(enable: Boolean) = if(enable) 1.0f else 0.5f

    /**
     * Text color
     */
    val textColor get() = Tokens.body

    /**
     * Description opacity
     */
    val descOpacity = 0.83f

    /**
     * Error text color
     */
    val errorColor get() = Tokens.error

    /**
     * Control size
     */
    @Dimension(unit = Dimension.DP)
    fun controlSize(size: Size) = when(size) {
        Size.SMALL -> 24
        Size.NORMAL -> 32
        Size.BIG -> 44
    }

    /**
     * Apply this margin to the top of the content only if used with inside borders.
     */
    val contentMargin get() = Tokens.spacingXs

    /**
     * Item margin (horizontal)
     */
    val horItemMargin get() = Tokens.spacingSm

    /**
     * Item margin (horizontal)
     */
    fun verItemMargin(size: Size) = if(size == Size.SMALL) Tokens.spacingXs else Tokens.spacingSm

    /**
     * Toggle width
     */
    fun toggleWidth(size: Size) = if(size == Size.SMALL) 40 else 51

    /**
     * Toggle width
     */
    fun toggleHeight(size: Size) = if(size == Size.SMALL) 23 else 31

    /**
     * Thumb size
     */
    fun thumbSize(size: Size) = if(size == Size.SMALL) 19 else 27

    /**
     * Stroke margin for checkbox with borders.
     */
    val strokeMargin get() = Tokens.spacingMd

    /**
     * All the margins in DP
     */
    val margins = SpacingQuad()

    /**
     * Text typography
     */
    fun font(context: Context, size: Size) = if(size == Size.NORMAL) Typography.Body(context) else Typography.BodySmall(context)


    /**
     * Description text typography
     */
    fun descFont(context: Context) = Typography.BodySmall(context)

    /**
     * Font of the potential link.
     */
    fun fontColor(context: Context, size: Size) = if(size == Size.NORMAL) Typography.Links(context) else Typography.LinksSmall(context)
}