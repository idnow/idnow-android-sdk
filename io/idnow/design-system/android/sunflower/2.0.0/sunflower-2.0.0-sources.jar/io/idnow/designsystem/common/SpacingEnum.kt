package io.idnow.designsystem.common

import io.idnow.designsystem.tokens.Tokens

enum class SpacingEnum(val value: Int) {
    NO_SPACING(0),
    SPACING_XS(Tokens.spacingXs),
    SPACING_SM(Tokens.spacingSm),
    SPACING_MD(Tokens.spacingMd),
    SPACING_LG(Tokens.spacingLg),
    SPACING_XL(Tokens.spacingXl),
    SPACING_2XL(Tokens.spacing2xl),
    SPACING_3XL(Tokens.spacing3xl)
}