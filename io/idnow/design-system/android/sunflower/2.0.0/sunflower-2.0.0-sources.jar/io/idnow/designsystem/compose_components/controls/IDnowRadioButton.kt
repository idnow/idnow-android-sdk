package io.idnow.designsystem.compose_components.controls

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.compose_components.controls.common.IDnowControlLayout
import io.idnow.designsystem.styles.compose.IDnowControlDefaults
import io.idnow.designsystem.styles.compose.IDnowControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size

/**
 * Compose counterpart of the XML `IDnowRadioButton`. A single radio option with an optional title,
 * description, error and border. Exclusivity is owned by the caller (a group toggles [selected]).
 *
 * The control is one accessibility node ([Role.RadioButton]); spacing is applied by the caller through
 * [modifier]. Radio supports SMALL / NORMAL sizes (BIG behaves like NORMAL).
 *
 * @param selected whether this option is selected.
 * @param onCheckedChange invoked with the toggled selection (`!selected`) when the control is tapped.
 * @param errorText when non-null, shown below the option as an error message and turns the border red.
 */
@Composable
fun IDnowRadioButton(
    selected: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    text: String? = null,
    description: String? = null,
    errorText: String? = null,
    enabled: Boolean = true,
    borders: Boolean = false,
    divider: Boolean = false,
    size: Size = Size.NORMAL,
) {
    val style = IDnowControlDefaults.style(size)
    val interactionSource = remember { MutableInteractionSource() }
    // Mirror the XML `onInternalChange = { stateError = false }`: the error clears on first interaction
    // and reappears only if the caller supplies a new errorText.
    var errorVisible by rememberSaveable(errorText) { mutableStateOf(errorText != null) }
    IDnowControlLayout(
        style = style,
        text = text,
        description = description,
        errorText = errorText?.takeIf { errorVisible },
        enabled = enabled,
        borders = borders,
        divider = divider,
        isFieldOnRightSide = false,
        isActive = selected,
        controlModifier = Modifier.selectable(
            selected = selected,
            enabled = enabled,
            role = Role.RadioButton,
            interactionSource = interactionSource,
            indication = null,
            onClick = { errorVisible = false; onCheckedChange(!selected) },
        ),
        modifier = modifier,
    ) {
        RadioIndicator(selected, style)
    }
}

/** Outlined circle; when selected, a filled inner dot inset by (stroke + 2dp), matching the XML. */
@Composable
private fun RadioIndicator(selected: Boolean, style: IDnowControlStyle) {
    val ringColor = if (selected) style.activeColor else style.strokeColor
    Box(
        modifier = Modifier
            .size(style.indicatorSize)
            .border(style.activeStrokeWidth, ringColor, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(style.activeStrokeWidth + 2.dp)
                    .background(style.activeColor, CircleShape),
            )
        }
    }
}
