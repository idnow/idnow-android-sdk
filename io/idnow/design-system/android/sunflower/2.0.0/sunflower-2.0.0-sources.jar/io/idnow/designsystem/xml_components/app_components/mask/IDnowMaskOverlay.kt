package io.idnow.designsystem.xml_components.app_components.mask

import io.idnow.designsystem.styles.xml.MaskStyle

sealed class IDnowMaskOverlay {
    data object None: IDnowMaskOverlay()
    data class Corners(val isBouncing: Boolean = false): IDnowMaskOverlay()
    data object Full: IDnowMaskOverlay()
    data class Progress(val duration: Int = MaskStyle.progressDuration): IDnowMaskOverlay()
}

internal enum class MaskOverlay {
    NONE, CORNERS, FULL, PROGRESS;

    fun toIDnowMaskOverlay(progressDuration: Int, isBouncing: Boolean): IDnowMaskOverlay {
        return when(this) {
            NONE -> IDnowMaskOverlay.None
            CORNERS -> IDnowMaskOverlay.Corners(isBouncing)
            FULL -> IDnowMaskOverlay.Full
            PROGRESS -> IDnowMaskOverlay.Progress(progressDuration)
        }
    }
}