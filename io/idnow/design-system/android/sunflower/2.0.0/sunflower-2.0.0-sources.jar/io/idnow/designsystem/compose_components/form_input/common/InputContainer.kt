package io.idnow.designsystem.compose_components.form_input.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle
import io.idnow.designsystem.styles.compose.IDnowInputContainerState

/**
 * The bordered input container background — Compose mirror of the XML `IDnowContainer` state-list
 * drawable. Clips to the rounded shape first so children (field, icons) stay inside the radius, then
 * fills the state background and draws the state border.
 */
fun Modifier.idnowInputContainer(
    state: IDnowInputContainerState,
    style: IDnowFormInputStyle,
): Modifier {
    val shape = RoundedCornerShape(style.cornerRadius)
    return this
        .clip(shape)
        .background(style.backgroundFor(state), shape)
        .border(style.strokeWidthFor(state), style.strokeColorFor(state), shape)
}

/**
 * Resolve the container state from the live focus/error/enabled inputs, following the XML state-list
 * precedence: disabled > error > focused(filling) > empty.
 */
fun resolveContainerState(focused: Boolean, isError: Boolean, enabled: Boolean): IDnowInputContainerState = when {
    !enabled -> IDnowInputContainerState.Disabled
    isError -> IDnowInputContainerState.Error
    focused -> IDnowInputContainerState.Filling
    else -> IDnowInputContainerState.Empty
}

/** Convenience: live container state driven by an [interactionSource]'s focus. */
@Composable
fun rememberContainerState(
    interactionSource: MutableInteractionSource,
    isError: Boolean,
    enabled: Boolean,
): IDnowInputContainerState {
    val focused by interactionSource.collectIsFocusedAsState()
    return resolveContainerState(focused, isError, enabled)
}
