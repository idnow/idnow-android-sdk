package io.idnow.designsystem.xml_components.controls.common

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Parcelable
import android.text.SpannableStringBuilder
import android.util.AttributeSet
import android.util.SparseArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.os.ParcelCompat
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowControlsBinding
import io.idnow.designsystem.styles.xml.ControlStyle
import io.idnow.designsystem.xml_components.extension.StateEntryBuilder
import io.idnow.designsystem.xml_components.extension.addActionForLinks
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.handleUrlClicks
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.stateListDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp

abstract class IDnowControls : ConstraintLayout, IDnowMarginable {
    private val stateErrorAttr = intArrayOf(R.attr.state_error)

    /** Inflate the layout into the view. */
    protected val binding = IdnowControlsBinding.inflate(LayoutInflater.from(context), this)

    /**
     * Some views require the field to be on the right side and text on left side
     * Override this constant to provide different value
     */
    open val isFieldOnRightSide: Boolean = false

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = ControlStyle.margins
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** Display and set the control text. */
    var text: CharSequence = ""
        set(value) {
            field = value
            updateTextsOnNextMeasure = true
            binding.idnContent.apply {
                isVisible = field.isNotEmpty()
                text = field
            }
            // Re-update the description with it's own design
            description = description
            setContentDescription()
        }

    /**
     * Display and set the description.
     * If there is no text, display the title instead of the description.
     * We need to it here instead of in the constraint settings method to have it well drawn in the android studio preview.
     */
    var description: String = ""
        set(value) {
            field = value
            updateTextsOnNextMeasure = true
            if (text.isEmpty()) {
                binding.idnContent.apply {
                    isVisible = field.isNotEmpty()
                    text = field
                }
            } else {
                binding.idnDescription.apply {
                    isVisible = field.isNotEmpty()
                    text = field
                }
            }
            setContentDescription()
        }

    /** Set the error text. */
    var errorText: String = ""
        set(value) {
            field = value
            binding.idnTvError.text = field
            setContentDescription()
        }

    /** Show/hide the error text group */
    var stateError: Boolean = false
        set(value) {
            field = value
            binding.idnErrorGroup.isVisible = field
            refreshDrawableState()
            setContentDescription()
        }

    /** Does this control have borders */
    var borders: Boolean = false
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** Show a divider at the bottom of the checkbox */
    var divider: Boolean = false
        set(value) {
            field = value
            binding.idnDivider.isVisible = field
        }

    /**
     * Size of the component.
     * It is internal because the parent can limit the number of size authorized for a component
     * But the generic control can handle all of them.
     */
    internal var controlSize: Size = Size.NORMAL

    /**
     * Should update text on next measure. It is important to update the text constraint in the onMeasure callback to have the android preview working.
     * We could use doOnLayout {} but it would broke the android studio preview.
     */
    private var updateTextsOnNextMeasure: Boolean = false

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowControls) {
            /** Handle the component margin. */
            val margin = getInt(R.styleable.IDnowControls_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowControls_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowControls_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowControls_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowControls_token_endMargin, -1)
            stateError = getBoolean(R.styleable.IDnowControls_state_error, false)
            text = getString(R.styleable.IDnowControls_text) ?: ""
            description = getString(R.styleable.IDnowControls_description) ?: ""
            errorText = getString(R.styleable.IDnowControls_errorText) ?: ""
            borders = getBoolean(R.styleable.IDnowControls_borders, false)
            divider = getBoolean(R.styleable.IDnowControls_separator, false)
            margins = ControlStyle.margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        }

        isDuplicateParentStateEnabled = true
    }

    override fun dispatchSaveInstanceState(container: SparseArray<Parcelable?>?) {
        dispatchFreezeSelfOnly(container)
    }

    override fun dispatchRestoreInstanceState(container: SparseArray<Parcelable?>?) {
        dispatchThawSelfOnly(container)
    }

    override fun onSaveInstanceState(): Parcelable? {
        val superState = super.onSaveInstanceState()
        return SavedState(superState, onSaveChildState())
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is SavedState) {
            super.onRestoreInstanceState(state)
            return
        }

        super.onRestoreInstanceState(state.superState)
        onRestoreChildState(state.childState)
    }

    private class SavedState : BaseSavedState {
        val childState: Parcelable?

        constructor(superState: Parcelable?, childState: Parcelable?) : super(superState) {
            this.childState = childState
        }

        constructor(source: android.os.Parcel) : super(source) {
            childState = ParcelCompat.readParcelable(source, SavedState::class.java.classLoader, SavedState::class.java)
        }

        override fun writeToParcel(out: android.os.Parcel, flags: Int) {
            super.writeToParcel(out, flags)
            out.writeParcelable(childState, flags)
        }

        companion object CREATOR : Parcelable.Creator<SavedState> {
            override fun createFromParcel(source: android.os.Parcel) = SavedState(source)
            override fun newArray(size: Int) = arrayOfNulls<SavedState>(size)
        }
    }

    protected fun initializeControls() {
        /** Set the control as focusable and clickable */
        isFocusable = true
        isFocusableInTouchMode = true
        isClickable = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO

        setupContainerBackground()
    }

    /**
     * Searches for all URLSpans in current text replaces them with our own ClickableSpans
     * forwards clicks to provided function.
     * This had to be called if the text contains links.
     */
    open fun handleUrlClicks(onClicked: ((String) -> Unit)) {
        binding.idnContent.handleUrlClicks(
            typography = ControlStyle.fontColor(context, controlSize),
            onClicked = onClicked
        ) { actionName, span -> addActionForLinks(binding.idnContainer, binding.root, actionName, span) }
    }

    private fun updateConstraints() {
        with(ControlStyle) {
            val strokeOrNoMargin = if (borders) strokeMargin else 0
            val strokeOrItemMargin = if (borders) strokeMargin else horItemMargin
            getStubView().apply {
                layoutParams = layoutParams.apply {
                    applyMargin(
                        context,
                        start = if (isFieldOnRightSide) strokeOrItemMargin else strokeOrNoMargin,
                        end = if (isFieldOnRightSide) strokeOrNoMargin else strokeOrItemMargin,
                        top = strokeOrNoMargin,
                        bottom = strokeOrNoMargin
                    )
                    /** ID binding is lost in the inflate process of the view stub, we need to manually add it again here. */
                    (this as LayoutParams).apply {
                        endToStart = if (isFieldOnRightSide) LayoutParams.UNSET else binding.idnContent.id
                        if (isFieldOnRightSide) {
                            startToStart = LayoutParams.UNSET
                            endToEnd = LayoutParams.PARENT_ID
                            startToEnd = binding.idnContent.id
                        }
                    }
                }
            }
            binding.idnContainer.apply {
                // To check the background based on the checkbox state.
                setAddStatesFromChildren(true)
            }
            binding.idnIvError.imageTintList = ColorStateList.valueOf(errorColor)
            binding.idnTvError.apply {
                layoutParams = layoutParams.applyMargin(context, start = horItemMargin, bottom = verItemMargin(controlSize))
                setTypography(descFont(context))
                setTextColor(errorColor)
            }
            binding.idnDivider.apply {
                layoutParams = layoutParams.applyMargin(context, top = verItemMargin(controlSize))
                setBackgroundColor(dividerColor)
            }
        }
    }

    /**
     * Update the text constraint to follow design system guidelines.
     * If only one text is display with one lines then we center this texts.
     * Otherwise we align it to control with a small top margin.
     * The description can also replace the text if there is no text.
     * This has to be called once the view layout has been created to check the lineCount.
     */
    private fun updateTextConstraints() {
        /** Update constraints */
        val strokeOrNoMargin = if (borders) ControlStyle.strokeMargin else 0

        // If there is at least one text with more than one lines, we add a margin on top of it.
        // Otherwise center the one lined text.
        val isMultiLine = text.isNotEmpty() && description.isNotEmpty()
                || binding.idnContent.lineCount > 1
                || binding.idnDescription.lineCount > 1

        /** ID binding is lost in the inflate process of the view stub, we need to manually add it again here. */
        binding.idnContent.apply {
            setTypography(ControlStyle.font(context, controlSize))
            setTextColor(ControlStyle.textColor)
            val newLayoutParams = layoutParams.applyMargin(
                context,
                top = if (isMultiLine) ControlStyle.contentMargin else 0,
                end = if (isFieldOnRightSide) 0 else strokeOrNoMargin,
                bottom = if (!binding.idnDescription.isVisible && isMultiLine) strokeOrNoMargin else 0,
                start = if (isFieldOnRightSide) strokeOrNoMargin else 0
            )
            layoutParams = (newLayoutParams as LayoutParams).apply {
                topToTop = getStubView().id
                if (isFieldOnRightSide) {
                    startToStart = LayoutParams.PARENT_ID
                    endToStart = getStubView().id
                } else {
                    startToEnd = getStubView().id
                    endToEnd = LayoutParams.PARENT_ID
                }
                bottomToBottom = when {
                    !isMultiLine -> getStubView().id
                    !binding.idnDescription.isVisible -> LayoutParams.PARENT_ID
                    else -> {
                        bottomToTop = binding.idnDescription.id
                        LayoutParams.PARENT_ID
                    }
                }
            }
        }

        /**
         * Little cheat here, as the description take the place and all the logics of the title when it's absent,
         * we prefer to update the title design with the description one instead of duplicating all the titles constraints
         */
        if (text.isEmpty() && description.isNotEmpty()) {
            binding.idnContent.apply {
                setTypography(ControlStyle.descFont(context))
                setTextColor(ControlStyle.textColor)
                alpha = ControlStyle.descOpacity
            }
        } else {
            binding.idnDescription.apply {
                setTypography(ControlStyle.descFont(context))
                setTextColor(ControlStyle.textColor)
                alpha = ControlStyle.descOpacity
                val newLayoutParams = layoutParams.applyMargin(
                    context,
                    top = ControlStyle.horItemMargin,
                    bottom = strokeOrNoMargin,
                    start = 0,
                    end = if (isFieldOnRightSide) 0 else strokeOrNoMargin
                )
                layoutParams = (newLayoutParams as LayoutParams).apply {
                    if (isFieldOnRightSide) {
                        endToEnd = binding.idnContent.id
                    }
                }
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        if (updateTextsOnNextMeasure) {
            updateTextConstraints()
            updateTextsOnNextMeasure = false
        }
    }

    private fun setupContainerBackground() {
        if (!borders) binding.idnContainer.setBackgroundColor(Color.TRANSPARENT)
        else binding.idnContainer.apply {
            fun StateEntryBuilder.background(strokeColor: Int, isActive: Boolean = true) = gradient {
                stroke(strokeColor, ControlStyle.strokeWidth(isActive).toDp(context))
                cornerRadius(ControlStyle.checkBoxRadius(controlSize).toDp(context).toFloat())
            }

            background = stateListDrawable {
                state(states = intArrayOf(android.R.attr.state_checked)) { background(ControlStyle.activeColor) }
                state(states = intArrayOf(R.attr.state_indeterminate)) { background(ControlStyle.activeColor) }
                state(states = intArrayOf(R.attr.state_error)) { background(ControlStyle.errorColor) }
                state { background(ControlStyle.strokeColor, false) }
            }
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        /** If borders are present, an alpha should be add to them also. */
        if (borders) {
            binding.idnContainer.background.alpha = (ControlStyle.opacity(enabled) * 255).toInt()
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** When the layout params changed, we need to reset some constraints */
        setupContainerBackground()
        updateConstraints()
        updateTextConstraints()
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(
            context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value
        )
        super.setLayoutParams(mParams)
    }

    /**
     * Add the state_error to the current state list if it has been set.
     */
    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        val drawableStates = super.onCreateDrawableState(extraSpace + 1)
        if (stateError) {
            mergeDrawableStates(drawableStates, stateErrorAttr)
        }
        return drawableStates
    }

    /** Return the stub view real type */
    protected abstract fun getStubView(): View

    protected open fun setContentDescription() {}

    /**
     * [IDnowControls] has ownership of state restoration.
     * This method will be called to retrieve child state and restore it afterward through [onRestoreChildState].
     */
    protected abstract fun onSaveChildState(): Parcelable?

    /** This method will be called when child state should be restored with the state returned from [onSaveChildState]. */
    protected abstract fun onRestoreChildState(childState: Parcelable?)

    /** Build the a custom content description for accessibility. */
    protected fun accessibilityContentText(): CharSequence {
        return SpannableStringBuilder().apply {
            if (stateError && errorText.isNotEmpty()) {
                append("${context.getString(R.string.sunflower_warning)}. ")
                append("$errorText${if (!errorText.endsWith(".")) "." else ""} ")
            }
            if (text.isNotEmpty()) append("$text${if (!text.endsWith(".")) "." else ""} ")
            if (description.isNotEmpty()) append("$description${if (!description.endsWith(".")) "." else ""} ")
        }
    }


    /** Use this method to reset the focus to this checkbox. */
    fun requestFocusForAccessibility() {
        binding.idnContainer.apply {
            requestFocus()
            sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
        }
    }

    override fun setAccessibilityTraversalBefore(beforeId: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            binding.idnContainer.setAccessibilityTraversalBefore(beforeId)
        } else {
            super.setAccessibilityTraversalBefore(beforeId)
        }
    }

    override fun getAccessibilityTraversalBefore(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            binding.idnContainer.accessibilityTraversalBefore
        } else {
            super.getAccessibilityTraversalBefore()
        }
    }

    override fun setAccessibilityTraversalAfter(afterId: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            binding.idnContainer.setAccessibilityTraversalAfter(afterId)
        } else {
            super.setAccessibilityTraversalAfter(afterId)
        }
    }

    override fun getAccessibilityTraversalAfter(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            binding.idnContainer.accessibilityTraversalAfter
        } else {
            super.getAccessibilityTraversalAfter()
        }
    }
}