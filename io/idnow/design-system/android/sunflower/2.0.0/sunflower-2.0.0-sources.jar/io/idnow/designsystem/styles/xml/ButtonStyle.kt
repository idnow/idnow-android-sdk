package io.idnow.designsystem.styles.xml

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.annotation.ColorInt
import androidx.annotation.DimenRes
import androidx.annotation.Dimension
import androidx.core.graphics.ColorUtils
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.buttons.ButtonSize
import io.idnow.designsystem.xml_components.extension.LayerBuilder
import io.idnow.designsystem.xml_components.extension.StateEntryBuilder
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.stateListDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp


internal sealed class ButtonStyle {
    abstract val size: ButtonSize

    /**
     * Pressed color opacity
     */
    abstract val pressedColorOpacity: Float

    /**
     * Background color [ColorInt]
     */
    abstract val backgroundColor: Int

    /**
     * Border color [ColorInt]
     */
    abstract val strokeColor: Int

    /**
     * Text color [ColorInt]
     */
    open val textColor: Int get() = Utils.getLuminanceTokenForPrimaryText(backgroundColor)

    /**
     * Border width in DP
     */
    @Dimension(unit = Dimension.DP)
    val strokeWidth = 1.5f

    /**
     * Max width in DP
     */
    @Dimension(unit = Dimension.DP)
    val maxWidth = 343

    /**
     * Icon padding in DP
     */
    val iconPadding
        get() = when (size) {
            ButtonSize.SMALL -> Tokens.spacingXs
            ButtonSize.MEDIUM, ButtonSize.LARGE -> Tokens.spacingSm
        }

    /**
     * Corner radius in DP
     */
    val cornerRadius get() = Tokens.radiusFull

    /**
     * All the paddings in DP
     */
    val paddings
        get() = when (size) {
            ButtonSize.SMALL -> SpacingQuad(
                start = SpacingEnum.SPACING_MD,
                end = SpacingEnum.SPACING_MD,
                top = SpacingEnum.SPACING_SM,
                bottom = SpacingEnum.SPACING_SM,
            )

            ButtonSize.MEDIUM, ButtonSize.LARGE -> SpacingQuad(
                start = SpacingEnum.SPACING_LG,
                end = SpacingEnum.SPACING_LG,
                top = SpacingEnum.SPACING_MD,
                bottom = SpacingEnum.SPACING_MD,
            )
        }

    /**
     * Button typography
     */
    val typography: TypographyEnum
        get() = when (size) {
            ButtonSize.SMALL -> TypographyEnum.BODY_XSMALL_BOLD
            ButtonSize.MEDIUM, ButtonSize.LARGE -> TypographyEnum.H6
        }

    @get:DimenRes
    val iconSize: Int
        get() = when (size) {
            ButtonSize.SMALL -> R.dimen.idnow_small_icon_size
            ButtonSize.MEDIUM -> R.dimen.idnow_icon_size
            ButtonSize.LARGE -> R.dimen.idnow_big_icon_size
        }

    /** Compute pressed color from a [baseColor]. */
    protected fun pressedColor(baseColor: Int, background: Int = Tokens.backgroundDarker, opacity: Float = pressedColorOpacity) =
        ColorUtils.blendARGB(baseColor, background, opacity)

    open fun background(context: Context): Drawable? = stateListDrawable {
        val cornerRadiusSize = cornerRadius.toDp(context).toFloat()
        val strokeWidth = strokeWidth.toDp(context)

        state(states = intArrayOf(android.R.attr.state_pressed)) {
            gradient {
                color(pressedColor(backgroundColor))
                stroke(color = pressedColor(strokeColor), width = strokeWidth)
                cornerRadius(cornerRadiusSize)
            }
        }

        state {
            gradient {
                color(backgroundColor)
                stroke(color = strokeColor, width = strokeWidth)
                cornerRadius(cornerRadiusSize)
            }
        }
    }

    data class PrimaryButton(
        override val size: ButtonSize,
    ) : ButtonStyle() {
        override val pressedColorOpacity: Float = 0.25f
        override val backgroundColor: Int get() = Tokens.primaryBackground
        override val strokeColor: Int get() = Tokens.primaryBackground
    }

    data class SecondaryButton(
        override val size: ButtonSize,
    ) : ButtonStyle() {
        override val pressedColorOpacity: Float = 0.05f
        override val backgroundColor: Int get() = Tokens.secondaryActiveBackground
        override val strokeColor: Int get() = Tokens.secondaryActiveStroke
        override val textColor: Int get() = Tokens.secondaryActiveText
    }

    data class DangerButton(
        override val size: ButtonSize,
    ) : ButtonStyle() {
        override val pressedColorOpacity: Float = 0.25f
        override val backgroundColor: Int get() = Tokens.error
        override val strokeColor: Int get() = Tokens.error
    }

    data class TriggerButton(
        override val size: ButtonSize,
    ) : ButtonStyle() {
        override val pressedColorOpacity: Float = 0.25f
        override val backgroundColor: Int get() = Tokens.primaryBackground
        override val strokeColor: Int get() = Tokens.primaryBackground

        override fun background(context: Context): Drawable = stateListDrawable {
            val strokeSize = 2.toDp(context)
            val cornerRadiusSize = cornerRadius.toDp(context).toFloat()

            fun StateEntryBuilder.layers(color: Int) = layerList {
                layer {
                    inset = LayerBuilder.Insets(4.toDp(context))
                    gradient {
                        color(argb = color)
                        cornerRadius(cornerRadiusSize - strokeSize)
                    }
                }

                layer {
                    gradient {
                        stroke(color = color, width = strokeSize)
                        cornerRadius(cornerRadiusSize)
                    }
                }
            }


            state(intArrayOf(android.R.attr.state_pressed)) {
                layers(pressedColor(backgroundColor))
            }

            state {
                layers(backgroundColor)
            }
        }
    }

    companion object {
        /** Button opacity, change if enable/disable*/
        fun opacity(enabled: Boolean) = if (enabled) 1.0f else 0.5f
    }
}
