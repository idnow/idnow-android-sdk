package io.idnow.designsystem.compose_components.lottie

import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import androidx.annotation.RawRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import com.airbnb.lottie.LottieComposition
import com.airbnb.lottie.LottieProperty
import com.airbnb.lottie.RenderMode
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieClipSpec
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.LottieDynamicProperties
import com.airbnb.lottie.compose.LottieDynamicProperty
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.airbnb.lottie.compose.rememberLottieDynamicProperties
import com.airbnb.lottie.compose.rememberLottieDynamicProperty
import io.idnow.designsystem.common.TintColorEnum

/**
 * Lottie class names recognized in the design-system animations. Mirror of the private
 * `KeyPathsClass` enum in the XML `IDnowLottieAnimationView` so both worlds tint the same layers.
 */
private const val CLASS_MAIN_BACKGROUND = ".lottie-color-main-background"
private const val CLASS_MAIN = ".lottie-color-main"
private const val CLASS_BACKGROUND = ".lottie-color-background"
private const val CLASS_ACCENT = ".lottie-color-accent"
private const val CLASS_PATTERN = ".lottie-color-pattern"
private const val CLASS_SUCCESS = ".lottie-color-success"
private const val CLASS_ERROR = ".lottie-color-error"
private const val CLASS_PROCESSING = ".lottie-color-processing"
private const val CLASS_OVERLAY = ".lottie-color-overlay"

/**
 * The design-system color overrides applied to a Lottie composition, exactly like the XML
 * `IDnowLottieAnimationView`:
 *  - `.lottie-color-main-background` → stroke = [TintColorEnum.MAIN], fill = [TintColorEnum.BACKGROUND]
 *  - every other `.lottie-color-*` class → `COLOR_FILTER` (SRC_ATOP) with its token color.
 *
 * Returned as the raw list of properties so callers can merge in their own. The `color()` reads below
 * touch the snapshot-backed `IDnowDesignSystem.primitives`, so the tint recomposes on a runtime
 * `setup()`. The raw `@ColorInt` form is required (Lottie works with android colors), so
 * [TintColorEnum.color] is used directly rather than the Compose `composeColor` extension.
 */
@Composable
fun rememberIDnowLottieColorProperties(): List<LottieDynamicProperty<*>> {
    val main = TintColorEnum.MAIN.color()
    val background = TintColorEnum.BACKGROUND.color()
    val accent = TintColorEnum.ACCENT.color()
    val pattern = TintColorEnum.PATTERN.color()
    val success = TintColorEnum.SUCCESS.color()
    val error = TintColorEnum.ERROR.color()
    val processing = TintColorEnum.PROCESSING.color()
    val overlay = TintColorEnum.OVERLAY.color()

    fun filter(color: Int) = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_ATOP)

    return listOf(
        // .lottie-color-main-background: stroke + fill handled separately.
        rememberLottieDynamicProperty(LottieProperty.STROKE_COLOR, main, "**", CLASS_MAIN_BACKGROUND, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR, background, "**", CLASS_MAIN_BACKGROUND, "**"),
        // Every other class: a SRC_ATOP color filter.
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(main), "**", CLASS_MAIN, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(background), "**", CLASS_BACKGROUND, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(accent), "**", CLASS_ACCENT, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(pattern), "**", CLASS_PATTERN, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(success), "**", CLASS_SUCCESS, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(error), "**", CLASS_ERROR, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(processing), "**", CLASS_PROCESSING, "**"),
        rememberLottieDynamicProperty(LottieProperty.COLOR_FILTER, filter(overlay), "**", CLASS_OVERLAY, "**"),
    )
}

/**
 * Design-system Lottie animation. A thin superset of [LottieAnimation]: it forwards the full
 * rendering surface (render mode, content scale, alignment, merge paths, …) and, by default, applies
 * the design-system color overrides ([rememberIDnowLottieColorProperties]) on top of any caller-supplied
 * [additionalProperties].
 *
 * This composition-based overload gives full control over playback (the caller drives [progress]).
 * For the common "load a raw resource and loop it" case, use the `@RawRes` overload below.
 *
 * @param applyDesignSystemColors when true (default) the `.lottie-color-*` layers are tinted from tokens.
 * @param additionalProperties extra Lottie dynamic properties merged after the design-system ones
 *   (build them with [rememberLottieDynamicProperty]).
 */
@Composable
fun IDnowLottieIllustration(
    composition: LottieComposition?,
    progress: () -> Float,
    modifier: Modifier = Modifier,
    applyDesignSystemColors: Boolean = true,
    additionalProperties: List<LottieDynamicProperty<*>> = emptyList(),
    outlineMasksAndMattes: Boolean = false,
    applyOpacityToLayers: Boolean = false,
    enableMergePaths: Boolean = false,
    renderMode: RenderMode = RenderMode.AUTOMATIC,
    maintainOriginalImageBounds: Boolean = false,
    contentScale: ContentScale = ContentScale.Fit,
    alignment: Alignment = Alignment.Center,
    clipToCompositionBounds: Boolean = true,
) {
    val designSystemProperties = if (applyDesignSystemColors) rememberIDnowLottieColorProperties() else emptyList()
    val allProperties = designSystemProperties + additionalProperties
    val dynamicProperties: LottieDynamicProperties? =
        if (allProperties.isEmpty()) null else rememberLottieDynamicProperties(*allProperties.toTypedArray())

    LottieAnimation(
        composition = composition,
        progress = progress,
        modifier = modifier,
        outlineMasksAndMattes = outlineMasksAndMattes,
        applyOpacityToLayers = applyOpacityToLayers,
        enableMergePaths = enableMergePaths,
        renderMode = renderMode,
        maintainOriginalImageBounds = maintainOriginalImageBounds,
        dynamicProperties = dynamicProperties,
        alignment = alignment,
        contentScale = contentScale,
        clipToCompositionBounds = clipToCompositionBounds,
    )
}

/**
 * Convenience overload that loads a `R.raw.*` Lottie resource and animates it, mirroring the XML
 * `applyAndStart` helper (infinite restart loop, auto-play) while keeping the playback knobs configurable.
 */
@Composable
fun IDnowLottieIllustration(
    @RawRes rawRes: Int,
    modifier: Modifier = Modifier,
    iterations: Int = LottieConstants.IterateForever,
    isPlaying: Boolean = true,
    restartOnPlay: Boolean = true,
    reverseOnRepeat: Boolean = false,
    speed: Float = 1f,
    clipSpec: LottieClipSpec? = null,
    applyDesignSystemColors: Boolean = true,
    additionalProperties: List<LottieDynamicProperty<*>> = emptyList(),
    contentScale: ContentScale = ContentScale.Fit,
    alignment: Alignment = Alignment.Center,
) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(rawRes))
    val progress by animateLottieCompositionAsState(
        composition = composition,
        isPlaying = isPlaying,
        restartOnPlay = restartOnPlay,
        reverseOnRepeat = reverseOnRepeat,
        clipSpec = clipSpec,
        speed = speed,
        iterations = iterations,
    )
    IDnowLottieIllustration(
        composition = composition,
        progress = { progress },
        modifier = modifier,
        applyDesignSystemColors = applyDesignSystemColors,
        additionalProperties = additionalProperties,
        contentScale = contentScale,
        alignment = alignment,
    )
}
