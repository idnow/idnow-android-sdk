package io.idnow.designsystem.xml_components.navigation.menu

import android.content.Context
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RectShape
import android.util.AttributeSet
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.core.content.withStyledAttributes
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.styles.xml.ContainerStyle
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.gradientDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp


class IDnowMenu @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : LinearLayout(context, attrs, defStyleAttr), IDnowMarginable {
    private val style = ContainerStyle.Empty

    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowMenu, defStyleAttr) {
            val margin = getInt(R.styleable.IDnowMenu_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowMenu_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowMenu_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowMenu_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowMenu_token_endMargin, -1)
            margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        }

        clipToOutline = true
        background = gradientDrawable {
            color(argb = style.backgroundColor)
            stroke(style.strokeColor, style.strokeWidth.toDp(context) * 2)
            cornerRadius(ContainerStyle.cornerRadius.toDp(context).toFloat())
        }

        orientation = VERTICAL

        showDividers = SHOW_DIVIDER_MIDDLE
        dividerDrawable = ShapeDrawable(RectShape()).apply {
            setTint(style.strokeColor)
            intrinsicHeight = style.strokeWidth.toDp(context)
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value, margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }
}