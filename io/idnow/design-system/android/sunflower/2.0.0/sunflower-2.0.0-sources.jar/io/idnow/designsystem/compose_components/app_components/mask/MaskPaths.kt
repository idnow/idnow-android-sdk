package io.idnow.designsystem.compose_components.app_components.mask

import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.PathMeasure
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad

/**
 * Compose translations of the XML mask path geometry. All coordinates are in pixels (the quad's
 * [android.graphics.Point]s), matching the drawing surface.
 */

/**
 * Rounded-rect path, mirror of the XML `RoundedRectPath`. Uses the four quad corners as-is, so it
 * follows a skewed quadrilateral. [useCompleteLines] = true draws full edges; false draws only the
 * corner brackets (the edges between corners are `moveTo` gaps).
 */
internal fun roundedRectMaskPath(
    quad: IDnowMaskQuad,
    cornerWidth: Float,
    cubicCorner: Float,
    useCompleteLines: Boolean,
): Path {
    val tl = quad.leftTop
    val tr = quad.rightTop
    val br = quad.rightBottom
    val bl = quad.leftBottom

    val tlXCorner = tl.x + cornerWidth
    val tlYCorner = tl.y + cornerWidth
    val trXCorner = tr.x - cornerWidth
    val trYCorner = tr.y + cornerWidth
    val brXCorner = br.x - cornerWidth
    val brYCorner = br.y - cornerWidth
    val blXCorner = bl.x + cornerWidth
    val blYCorner = bl.y - cornerWidth

    val tlXCubic = tl.x + cubicCorner
    val tlYCubic = tl.y + cubicCorner
    val trXCubic = tr.x - cubicCorner
    val trYCubic = tr.y + cubicCorner
    val brXCubic = br.x - cubicCorner
    val brYCubic = br.y - cubicCorner
    val blXCubic = bl.x + cubicCorner
    val blYCubic = bl.y - cubicCorner

    return Path().apply {
        fillType = PathFillType.EvenOdd
        moveTo(tl.x.toFloat(), tlYCorner)
        lineTo(tl.x.toFloat(), tlYCubic)
        cubicTo(tl.x.toFloat(), tlYCubic, tl.x.toFloat(), tl.y.toFloat(), tlXCubic, tl.y.toFloat())
        lineTo(tlXCorner, tl.y.toFloat())
        goTo(trXCorner, tr.y.toFloat(), useCompleteLines)
        lineTo(trXCubic, tr.y.toFloat())
        cubicTo(trXCubic, tr.y.toFloat(), tr.x.toFloat(), tr.y.toFloat(), tr.x.toFloat(), trYCubic)
        lineTo(tr.x.toFloat(), trYCorner)
        goTo(br.x.toFloat(), brYCorner, useCompleteLines)
        lineTo(br.x.toFloat(), brYCubic)
        cubicTo(br.x.toFloat(), brYCubic, br.x.toFloat(), br.y.toFloat(), brXCubic, br.y.toFloat())
        lineTo(brXCorner, br.y.toFloat())
        goTo(blXCorner, bl.y.toFloat(), useCompleteLines)
        lineTo(blXCubic, bl.y.toFloat())
        cubicTo(blXCubic, bl.y.toFloat(), bl.x.toFloat(), bl.y.toFloat(), bl.x.toFloat(), blYCubic)
        lineTo(bl.x.toFloat(), blYCorner)
        goTo(tl.x.toFloat(), tlYCorner, useCompleteLines)
        close()
    }
}

/** Full oval bounding the quad (leftTop → rightBottom), mirror of the XML `OvalPath`. */
internal fun ovalMaskPath(quad: IDnowMaskQuad): Path = Path().apply {
    fillType = PathFillType.EvenOdd
    // Clockwise to match the XML OvalPath (Path.Direction.CW): the winding direction sets where the
    // PathMeasure sections fall, which ovalCornersMaskPath and progressSegment rely on.
    addOval(
        Rect(quad.leftTop.x.toFloat(), quad.leftTop.y.toFloat(), quad.rightBottom.x.toFloat(), quad.rightBottom.y.toFloat()),
        Path.Direction.Clockwise,
    )
}

/** Eight corner arcs of the oval (sections 1,4,5,8,9,12,13,16 of 16), mirror of the XML `OvalCornersPath`. */
internal fun ovalCornersMaskPath(quad: IDnowMaskQuad): Path {
    val oval = ovalMaskPath(quad)
    val measure = PathMeasure().apply { setPath(oval, false) }
    val sectionLength = measure.length / 16f
    return Path().apply {
        fillType = PathFillType.EvenOdd
        intArrayOf(1, 4, 5, 8, 9, 12, 13, 16).forEach { section ->
            val segment = Path()
            measure.getSegment(sectionLength * (section - 1), sectionLength * section, segment, true)
            addPath(segment)
        }
    }
}

/** A leading fraction [progress] (0..1) of [full], mirror of the XML `ProgressPath`. */
internal fun progressSegment(full: Path, progress: Float): Path {
    val measure = PathMeasure().apply { setPath(full, true) }
    return Path().apply { measure.getSegment(0f, measure.length * progress, this, true) }
}

private fun Path.goTo(x: Float, y: Float, useCompleteLines: Boolean) {
    if (useCompleteLines) lineTo(x, y) else moveTo(x, y)
}
