package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.dp

/**
 * Fully-resolved visual values for
 * [io.idnow.designsystem.compose_components.controls.pdf.IDnowPdfLayout].
 *
 * Compose mirror of the XML [io.idnow.designsystem.xml_components.controls.pdf.IDnowPdfLayout]: the
 * PDF controls chrome (re-upload button, `current/total` page label, two zoom FABs + zoom-percent
 * label) on a secondary background. The chrome composes already-styled components
 * ([io.idnow.designsystem.compose_components.buttons.IDnowButton] /
 * [io.idnow.designsystem.compose_components.buttons.IDnowFABButton] /
 * [io.idnow.designsystem.compose_components.text_view.IDnowText]); this holder only carries the
 * container-level values so the composable reads from it rather than touching tokens/dimens directly.
 */
@Immutable
data class IDnowPdfLayoutStyle(
    /** Chrome background (XML: `Tokens.backgroundSecondary`). */
    val backgroundColor: BackgroundColorEnum,
    /** Padding around the whole chrome and the top gap above the PDF content (XML: `SPACING_SM`). */
    val contentPadding: Dp,
    /** Gap between the items of the right-hand zoom group (XML: `SPACING_SM` end margins). */
    val headerItemSpacing: Dp,
    /** `current/total` page label typography (XML: `BODY_SMALL`). */
    val pageLabelTypography: TypographyEnum,
    /** Zoom-percent label typography (XML: `BODY_XSMALL_BOLD`). */
    val zoomLabelTypography: TypographyEnum,
    /** Style of the re-upload button (XML: `SECONDARY` / `SMALL`). */
    val reuploadButtonStyle: IDnowButtonStyle,
    /** Style of the two zoom FABs (XML: `SECONDARY` / `SMALL`). */
    val zoomFabStyle: IDnowButtonStyle,
)

/** Default resolver for [IDnowPdfLayoutStyle], analogous to Material3's `XxxDefaults`. */
object IDnowPdfLayoutDefaults {

    @Composable
    fun style(): IDnowPdfLayoutStyle = IDnowPdfLayoutStyle(
        backgroundColor = BackgroundColorEnum.SECONDARY,
        contentPadding = SpacingEnum.SPACING_SM.dp,
        headerItemSpacing = SpacingEnum.SPACING_SM.dp,
        pageLabelTypography = TypographyEnum.BODY_SMALL,
        zoomLabelTypography = TypographyEnum.BODY_XSMALL_BOLD,
        reuploadButtonStyle = IDnowButtonStyle.secondary(IDnowButtonSize.SMALL),
        zoomFabStyle = IDnowButtonStyle.secondary(IDnowButtonSize.SMALL),
    )
}
