package io.idnow.designsystem.styles.xml

import android.content.Context
import androidx.constraintlayout.widget.ConstraintLayout
import io.idnow.designsystem.xml_components.extension.toDp

internal sealed class TutorialStepStyle {
    /**
     * If true the step number is inline with the title.
     * If false a large step number icon is displayed.
     */
    open val isStepNumberInline = false

    /**
     * Is the space before the lottie visible.
     */
    open val isSpaceVisible = true

    /**
     * Width of the lottie.
     * Conversion to DP is already done as the value might be something else than a size. (e.g WRAP_CONTENT)
     */
    open fun lottieWidth(context: Context) = 106.toDp(context)


    /**
     * Height of the lottie.
     * Conversion to DP is already done as the value might be something else than a size. (e.g WRAP_CONTENT)
     */
    open fun lottieHeight(context: Context) = 106.toDp(context)

    data object Large: TutorialStepStyle()

    data object Inline: TutorialStepStyle() {
        override val isStepNumberInline: Boolean = true
        override val isSpaceVisible: Boolean = false
        override fun lottieWidth(context: Context): Int = 94.toDp(context)
        override fun lottieHeight(context: Context): Int = ConstraintLayout.LayoutParams.WRAP_CONTENT
    }
}