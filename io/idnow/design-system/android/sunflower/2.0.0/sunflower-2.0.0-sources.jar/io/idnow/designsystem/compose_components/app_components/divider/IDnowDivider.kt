package io.idnow.designsystem.compose_components.app_components.divider

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import io.idnow.designsystem.styles.compose.IDnowDividerDefaults

/**
 * Tokenized divider, the Compose counterpart of the XML
 * [io.idnow.designsystem.xml_components.app_components.divider.IDnowDivider].
 *
 * A thin line (thickness resolved from the style, `borderPrimary` token color). It fills the available
 * width by default, but — like the XML view whose length comes from its layout params — the caller can
 * shrink it through [modifier] (e.g. `Modifier.fillMaxWidth(0.4f)`); spacing around it is applied the
 * same way. The caller's width/padding are applied on top of the default `fillMaxWidth()`.
 */
@Composable
fun IDnowDivider(modifier: Modifier = Modifier) {
    val style = IDnowDividerDefaults.style()
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .then(modifier)
            .height(style.thickness)
            .background(style.color),
    )
}
