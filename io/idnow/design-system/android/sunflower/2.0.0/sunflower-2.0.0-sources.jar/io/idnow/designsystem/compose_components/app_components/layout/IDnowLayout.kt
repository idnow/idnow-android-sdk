package io.idnow.designsystem.compose_components.app_components.layout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.compose_components.app_components.footer.IDnowFooter
import io.idnow.designsystem.compose_components.app_components.header.IDnowHeader
import io.idnow.designsystem.compose_components.app_components.header.IDnowHeaderIcon
import io.idnow.designsystem.compose_components.extension.composeColor

/**
 * Compose counterpart of the XML `IDnowConstraintLayout`: a full-screen container that optionally
 * shows an [IDnowHeader] at the top and an [IDnowFooter] at the bottom, with [content] filling the
 * space in between. Background is a [BackgroundColorEnum] token; system-bar and display-cutout insets
 * are always consumed as padding (like the XML view) so the background paints behind the bars.
 *
 * The header icons are exposed as [IDnowHeaderIcon] and forwarded to the embedded [IDnowHeader].
 *
 * @param showHeader / [showFooter] toggle the header / footer.
 */
@Composable
fun IDnowLayout(
    modifier: Modifier = Modifier,
    backgroundColor: BackgroundColorEnum = BackgroundColorEnum.PRIMARY,
    showHeader: Boolean = false,
    showFooter: Boolean = false,
    headerBrand: Boolean = false,
    headerStartIcon: IDnowHeaderIcon? = null,
    headerEndIcon: IDnowHeaderIcon? = null,
    headerAdditionalEndIcon: IDnowHeaderIcon? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundColor.composeColor)
            .windowInsetsPadding(WindowInsets.systemBars.union(WindowInsets.displayCutout)),
    ) {
        if (showHeader) {
            IDnowHeader(
                brand = headerBrand,
                startIcon = headerStartIcon,
                endIcon = headerEndIcon,
                additionalEndIcon = headerAdditionalEndIcon,
            )
        }
        // Content fills the space between header and footer, pinning the footer to the bottom.
        Box(modifier = Modifier.weight(1f).fillMaxWidth(), content = content)
        if (showFooter) IDnowFooter()
    }
}
