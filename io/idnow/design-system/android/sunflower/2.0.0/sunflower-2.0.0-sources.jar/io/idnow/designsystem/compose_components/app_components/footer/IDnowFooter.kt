package io.idnow.designsystem.compose_components.app_components.footer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.compose.IDnowFooterDefaults

/**
 * Compose counterpart of the XML `IDnowFooter`: a centered "powered by IDnow" logo, tinted with the
 * `main` token at reduced opacity, with a small bottom padding.
 */
@Composable
fun IDnowFooter(modifier: Modifier = Modifier) {
    val style = IDnowFooterDefaults.style()
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(R.drawable.idnow_powered_by),
            contentDescription = null,
            colorFilter = ColorFilter.tint(style.logoColor),
            alpha = style.logoOpacity,
            modifier = Modifier.padding(bottom = style.bottomPadding),
        )
    }
}
