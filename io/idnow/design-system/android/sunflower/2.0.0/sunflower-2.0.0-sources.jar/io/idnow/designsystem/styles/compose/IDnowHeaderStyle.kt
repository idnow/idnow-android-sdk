package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.Dp
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.xml.HeaderStyle

/**
 * Fully-resolved visual values for `IDnowHeader`. Compose mirror of the XML [HeaderStyle] (+ the
 * `idnow_header_icon_*` dimens). Icon tints stay per-icon inputs (resolved from `TintColorEnum`).
 */
@Immutable
data class IDnowHeaderStyle(
    /** Touch-target size of each icon (the XML `idnow_header_icon_size`). */
    val iconSize: Dp,
    /** Inner padding of each icon (the XML `idnow_header_icon_padding`). */
    val iconPadding: Dp,
    /** Opacity applied to the icons. */
    val iconOpacity: Float,
)

/** Default resolver for [IDnowHeaderStyle]. */
object IDnowHeaderDefaults {

    @Composable
    fun style(): IDnowHeaderStyle = IDnowHeaderStyle(
        iconSize = dimensionResource(R.dimen.idnow_header_icon_size),
        iconPadding = dimensionResource(R.dimen.idnow_header_icon_padding),
        iconOpacity = HeaderStyle.iconOpacity,
    )
}
