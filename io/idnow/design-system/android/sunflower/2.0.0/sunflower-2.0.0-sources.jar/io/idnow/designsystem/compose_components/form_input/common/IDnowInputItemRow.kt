package io.idnow.designsystem.compose_components.form_input.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItemData

/**
 * One row of a dropdown / spinner / country list — Compose mirror of the XML `idnow_container_item.xml`
 * (`IdnowContainerItemBinding.updateItem`): optional leading icon + text + trailing check (shown only when
 * [selected] and [showCheck]). Reuses the shared [IDnowItemData] model so the spinner ([io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItem]) and
 * the phone country list ([io.idnow.designsystem.xml_components.form_input_texts.common.IDnowCountryFlagItem]) both fit.
 *
 * @param showCheck whether a check mark is drawn for the selected item (spinner & country list: true; autocomplete: false).
 * @param contentDescription overrides the spoken label (the country list uses "name, prefix").
 * @param clickLabel custom click-action label (the country list uses "Select").
 */
@Composable
internal fun IDnowInputItemRow(
    item: IDnowItemData,
    style: IDnowFormInputStyle,
    selected: Boolean,
    showCheck: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
    clickLabel: String? = null,
) {
    val description = contentDescription ?: item.content?.toString().orEmpty()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClickLabel = clickLabel, role = Role.Button, onClick = onClick)
            .padding(horizontal = style.itemContentPadding, vertical = style.innerPadding)
            .clearAndSetSemantics {
                this.contentDescription = description
                this.selected = selected
            },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        item.icon?.let { icon ->
            Image(
                painter = painterResource(icon),
                contentDescription = null,
                modifier = Modifier
                    .size(style.itemIconSize)
            )
            Spacer(Modifier.width(style.itemContentPadding))
        }
        item.content?.let { content ->
            BasicText(
                text = content.toString(),
                style = style.itemTextStyle,
                modifier = Modifier
                    .weight(1f)
            )
        }
        if (selected && showCheck) {
            Spacer(Modifier.width(style.itemContentPadding))
            Image(
                painter = painterResource(R.drawable.sunflower_ic_check),
                contentDescription = null,
                colorFilter = ColorFilter.tint(style.popupCheckTint),
                modifier = Modifier
                    .size(style.itemIconSize)
            )
        }
    }
}
