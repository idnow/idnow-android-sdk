package io.idnow.designsystem.compose_components.image_view

import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.painter.Painter
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.compose_components.extension.composeColor

/**
 * Tokenized image, the Compose counterpart of the XML `IDnowImageView`.
 *
 * The only design-system feature is an optional [tintColor] applied as a color filter
 * ([TintColorEnum], `null` = no tint), matching the XML view. Like the other Compose components,
 * there is no `margins` parameter — spacing is applied by the caller via [modifier]
 * (e.g. `Modifier.padding(SpacingEnum.SPACING_MD.dp)`).
 *
 * Mirroring `IDnowLayout`, this component has no XML style and therefore no style holder.
 */
@Composable
fun IDnowImage(
    painter: Painter,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tintColor: TintColorEnum? = null,
) {
    Image(
        painter = painter,
        contentDescription = contentDescription,
        modifier = modifier,
        colorFilter = tintColor?.let { ColorFilter.tint(it.composeColor) },
    )
}
