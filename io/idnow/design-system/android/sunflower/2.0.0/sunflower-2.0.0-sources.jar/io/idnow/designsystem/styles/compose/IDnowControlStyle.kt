package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.controls.common.Size

/**
 * Fully-resolved visual values shared by the Compose controls (`IDnowCheckBox`, `IDnowRadioButton`,
 * `IDnowSwitch`). Compose mirror of the XML [io.idnow.designsystem.styles.xml.ControlStyle]: the only
 * thing that differs between the three controls is the checkable indicator drawing, so a single style
 * + resolver feeds all of them. All values are resolved from tokens in [IDnowControlDefaults.style].
 */
@Immutable
data class IDnowControlStyle(
    // --- Texts -----------------------------------------------------------
    /** Title typography (BODY for NORMAL, BODY_SMALL otherwise), body color. */
    val titleTextStyle: TextStyle,
    /** Description typography (always BODY_SMALL), body color at 0.83 opacity. */
    val descriptionTextStyle: TextStyle,
    /** Error message typography (BODY_SMALL, error color). */
    val errorTextStyle: TextStyle,
    // --- Colors ----------------------------------------------------------
    /** Inactive stroke (empty box / unchecked radio / off border). */
    val strokeColor: Color,
    /** Active fill/stroke (checked / indeterminate / on). */
    val activeColor: Color,
    /** Error stroke + error icon tint. */
    val errorColor: Color,
    /** Divider line color. */
    val dividerColor: Color,
    /** Tint of the check / minus glyph inside a filled checkbox. */
    val iconColor: Color,
    /** Switch track color when off. */
    val uncheckedTrackColor: Color,
    /** Switch thumb (knob) color. */
    val knobColor: Color,
    // --- Metrics ---------------------------------------------------------
    /** Stroke width of an inactive border (1dp). */
    val emptyStrokeWidth: Dp,
    /** Stroke width of an active / error border (2dp). */
    val activeStrokeWidth: Dp,
    /** Corner radius of the checkbox box and of the bordered container (size-dependent). */
    val cornerRadius: Dp,
    /** Inner padding of a bordered container (XML strokeMargin = SPACING_MD). */
    val borderPadding: Dp,
    /** Horizontal gap between the indicator and the texts (XML horItemMargin = SPACING_SM). */
    val itemSpacing: Dp,
    /** Top margin added to the texts when the content is multi-line (XML contentMargin = SPACING_XS). */
    val contentMargin: Dp,
    /** Top margin above the error row and the divider (size-dependent). */
    val verItemMargin: Dp,
    /** Error warning icon size (idnow_text_icon_size = 19dp). */
    val errorIconSize: Dp,
    /** Alpha applied to the whole control when disabled. */
    val disabledAlpha: Float,
    // --- Indicator (checkbox / radio) ------------------------------------
    /** Side of the square / circle indicator (24 / 32 / 44 dp). */
    val indicatorSize: Dp,
    // --- Indicator (switch) ----------------------------------------------
    val trackWidth: Dp,
    val trackHeight: Dp,
    val thumbSize: Dp,
    /** Inset of the thumb inside the track on each side (2dp). */
    val thumbInset: Dp,
)

/** Default resolver for [IDnowControlStyle], analogous to Material3's `XxxDefaults`. */
object IDnowControlDefaults {

    @Composable
    fun style(size: Size): IDnowControlStyle {
        val small = size == Size.SMALL
        val bodyColor = TextColorEnum.BODY.composeColor
        return IDnowControlStyle(
            titleTextStyle = (if (size == Size.NORMAL) TypographyEnum.BODY else TypographyEnum.BODY_SMALL)
                .asTextStyle(color = bodyColor),
            descriptionTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(color = bodyColor.copy(alpha = DESC_OPACITY)),
            errorTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(color = TintColorEnum.ERROR.composeColor),
            strokeColor = Color(Tokens.borderTertiary),
            activeColor = TintColorEnum.SUCCESS.composeColor,
            errorColor = TintColorEnum.ERROR.composeColor,
            dividerColor = Color(Tokens.borderPrimary),
            iconColor = TintColorEnum.OVERLAY.composeColor,
            uncheckedTrackColor = BackgroundColorEnum.TERTIARY.composeColor,
            knobColor = BackgroundColorEnum.PRIMARY.composeColor,
            emptyStrokeWidth = 1.dp,
            activeStrokeWidth = 2.dp,
            cornerRadius = (if (small) Tokens.radiusSm else Tokens.radiusMd).dp,
            borderPadding = SpacingEnum.SPACING_MD.dp,
            itemSpacing = SpacingEnum.SPACING_SM.dp,
            contentMargin = SpacingEnum.SPACING_XS.dp,
            verItemMargin = (if (small) SpacingEnum.SPACING_XS else SpacingEnum.SPACING_SM).dp,
            errorIconSize = dimensionResource(R.dimen.idnow_text_icon_size),
            disabledAlpha = DISABLED_ALPHA,
            indicatorSize = when (size) {
                Size.SMALL -> 24.dp
                Size.NORMAL -> 32.dp
                Size.BIG -> 44.dp
            },
            trackWidth = (if (small) 40 else 51).dp,
            trackHeight = (if (small) 23 else 31).dp,
            thumbSize = (if (small) 19 else 27).dp,
            thumbInset = 2.dp,
        )
    }

    /** XML ControlStyle.descOpacity. */
    private const val DESC_OPACITY = 0.83f

    /** XML ControlStyle.opacity(false). */
    private const val DISABLED_ALPHA = 0.5f
}
