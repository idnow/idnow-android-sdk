package io.idnow.designsystem.compose_components.navigation

import androidx.annotation.DrawableRes
import androidx.annotation.RawRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.lottie.IDnowLottieIllustration
import io.idnow.designsystem.compose_components.text_view.IDnowText
import io.idnow.designsystem.styles.compose.IDnowEntryButtonDefaults
import io.idnow.designsystem.styles.compose.IDnowEntryButtonStyle

/**
 * The two flavours of [IDnowEntryButton], the Compose counterpart of the XML `IDnowEntryButton.Style`
 * (`MEDIUM` / `LARGE`). Unlike the XML enum, each flavour is a data class that carries **its own**
 * leading content, so a caller can never pass a Large-only Lottie to a Medium button (or vice-versa).
 */
sealed interface IDnowEntryButtonVariant {

    /**
     * Standard list-style entry: an optional [startIcon] (tinted [startIconTint]), a `BODY` title and
     * an optional `BODY_SMALL` description, inside a fully rounded, bordered container.
     */
    data class Medium(
        @DrawableRes val startIcon: Int? = null,
        val startIconTint: TintColorEnum = TintColorEnum.MAIN,
    ) : IDnowEntryButtonVariant

    /**
     * Larger entry leading with a 96dp Lottie animation ([lottieRes]), an `H5` title and an optional
     * description. Its container is flush (square, borderless) on the left — where the Lottie sits —
     * and rounded/bordered on the top, right and bottom, mirroring the XML negative-inset background.
     */
    data class Large(
        @RawRes val lottieRes: Int,
    ) : IDnowEntryButtonVariant
}

/**
 * Tokenized navigation entry button, the Compose counterpart of the XML
 * [io.idnow.designsystem.xml_components.navigation.IDnowEntryButton].
 *
 * The look is driven by [variant] ([IDnowEntryButtonVariant.Medium] / [IDnowEntryButtonVariant.Large]);
 * both share a [title], an optional [description] and a trailing [endIcon] (default chevron, tinted
 * [endIconTint]). The whole row is clickable ([onClick]); when [onEndIconClick] is non-null the end
 * icon is additionally tappable on its own (mirroring the XML `setOnEndIconClickListener`).
 *
 * All visuals are resolved internally from [IDnowEntryButtonDefaults]; spacing around the component is
 * applied by the caller via [modifier]. For accessibility the row is exposed as a single button node
 * reading "title. description. Button.", like the XML view.
 *
 * @param endIcon trailing icon; defaults to the chevron like the XML view. Pass `null` to hide it.
 * @param onEndIconClick optional separate click on the end icon. When non-null the end icon becomes its
 *   own focusable accessibility node (a button) and [endIconContentDescription] **must** be provided;
 *   when null the end icon is decorative and part of the main button.
 * @param endIconContentDescription spoken description of the end icon, required when [onEndIconClick] is set.
 */
@Composable
fun IDnowEntryButton(
    title: String,
    variant: IDnowEntryButtonVariant,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    description: String? = null,
    @DrawableRes endIcon: Int? = R.drawable.sunflower_ic_chevron_right,
    endIconTint: TintColorEnum = TintColorEnum.ACCENT,
    onEndIconClick: (() -> Unit)? = null,
    endIconContentDescription: String? = null,
) {
    require(onEndIconClick == null || endIconContentDescription != null) {
        "endIconContentDescription must be provided when onEndIconClick is set (the end icon becomes a focusable button)."
    }
    val style = IDnowEntryButtonDefaults.style()

    val (spacing, descriptionGap) = when (variant) {
        is IDnowEntryButtonVariant.Medium -> style.mediumSpacing to style.mediumDescriptionGap
        is IDnowEntryButtonVariant.Large -> style.largeSpacing to style.largeDescriptionGap
    }
    val titleTypography = when (variant) {
        is IDnowEntryButtonVariant.Medium -> TypographyEnum.BODY
        is IDnowEntryButtonVariant.Large -> TypographyEnum.H5
    }
    val titleColor = when (variant) {
        is IDnowEntryButtonVariant.Medium -> TextColorEnum.BODY
        is IDnowEntryButtonVariant.Large -> TextColorEnum.HEADING
    }

    val buttonLabel = stringResource(R.string.sunflower_button)
    val contentDescriptionText = remember(title, description, buttonLabel) {
        buildString {
            if (title.isNotEmpty()) append("$title${if (!title.endsWith(".")) "." else ""} ")
            if (!description.isNullOrEmpty()) append("$description${if (!description.endsWith(".")) "." else ""} ")
            append(buttonLabel)
        }
    }
    val interactionSource = remember { MutableInteractionSource() }

    Row(
        modifier = modifier.entryButtonContainer(variant, style)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .semantics { contentDescription = contentDescriptionText },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Main button: leading element + texts, exposed as a single accessibility node reading
        // "title. description. Button.". The end icon is kept OUTSIDE this node so that, when
        // actionable, it can be its own focusable button.
        Row(
            modifier = Modifier
                .weight(1f)
                .padding(
                    start = spacing,
                    top = spacing,
                    bottom = spacing,
                    end = if (endIcon == null) spacing else 0.dp,
                ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(spacing),
        ) {
            when (variant) {
                is IDnowEntryButtonVariant.Medium -> variant.startIcon?.let { icon ->
                    Image(
                        painter = painterResource(icon),
                        contentDescription = null,
                        colorFilter = ColorFilter.tint(variant.startIconTint.composeColor),
                    )
                }

                is IDnowEntryButtonVariant.Large -> IDnowLottieIllustration(
                    rawRes = variant.lottieRes,
                    // This component's Lotties play once, they do not loop.
                    iterations = 1,
                    modifier = Modifier.size(style.lottieSize),
                )
            }

            Column(
                modifier = Modifier.weight(1f).clearAndSetSemantics {},
                verticalArrangement = Arrangement.spacedBy(descriptionGap),
            ) {
                IDnowText(text = title, typography = titleTypography, textColor = titleColor)
                if (!description.isNullOrEmpty()) {
                    IDnowText(
                        text = description,
                        typography = TypographyEnum.BODY_SMALL,
                        textColor = TextColorEnum.BODY,
                        modifier = Modifier.alpha(style.descriptionAlpha),
                    )
                }
            }
        }

        if (endIcon != null) {
            // When actionable, the end icon is its own focusable button and the caller supplies its
            // contentDescription; otherwise it is decorative (ignored by screen readers).
            val endIconClickable = if (onEndIconClick != null) {
                Modifier.clickable(interactionSource = interactionSource, indication = null, role = Role.Button, onClick = onEndIconClick)
            } else {
                Modifier
            }
            Image(
                painter = painterResource(endIcon),
                contentDescription = if (onEndIconClick != null) endIconContentDescription else null,
                colorFilter = ColorFilter.tint(endIconTint.composeColor),
                modifier = endIconClickable.padding(spacing),
            )
        }
    }
}

/**
 * The bordered container for each variant. Medium is a fully rounded, bordered box. Large is clipped to
 * a right-only rounded shape (square/flush on the left, where the Lottie sits) with the border painted
 * on three sides — the clean Compose equivalent of the XML Large background's negative left inset.
 */
private fun Modifier.entryButtonContainer(
    variant: IDnowEntryButtonVariant,
    style: IDnowEntryButtonStyle,
): Modifier = when (variant) {
    is IDnowEntryButtonVariant.Medium -> {
        val shape = RoundedCornerShape(style.cornerRadius)
        this
            .clip(shape)
            .border(style.strokeWidth, style.strokeColor, shape)
    }

    is IDnowEntryButtonVariant.Large -> this
        .clip(RoundedCornerShape(topEnd = style.cornerRadius, bottomEnd = style.cornerRadius))
        .rightRoundedBorder(style.strokeWidth, style.strokeColor, style.cornerRadius)
}

/**
 * Draws a border on the top, right and bottom edges only, with the two right corners rounded by
 * [radius] and the left edge left open (flush). The stroke is inset by half its width so it stays
 * fully inside the bounds.
 */
private fun Modifier.rightRoundedBorder(width: Dp, color: Color, radius: Dp): Modifier = drawWithCache {
    val strokePx = width.toPx()
    val inset = strokePx / 2f
    val w = size.width
    val h = size.height
    // Centerline corner radius so the stroke's outer edge matches `radius`, clamped to the half-height.
    val r = (radius.toPx() - inset).coerceIn(0f, (h / 2f) - inset)

    val topRightArc = Rect(left = w - inset - 2 * r, top = inset, right = w - inset, bottom = inset + 2 * r)
    val bottomRightArc = Rect(left = w - inset - 2 * r, top = h - inset - 2 * r, right = w - inset, bottom = h - inset)

    val path = Path().apply {
        moveTo(0f, inset)
        lineTo(w - inset - r, inset)
        arcTo(topRightArc, -90f, 90f, false)
        lineTo(w - inset, h - inset - r)
        arcTo(bottomRightArc, 0f, 90f, false)
        lineTo(0f, h - inset)
    }

    onDrawWithContent {
        drawContent()
        drawPath(path, color, style = Stroke(width = strokePx))
    }
}
