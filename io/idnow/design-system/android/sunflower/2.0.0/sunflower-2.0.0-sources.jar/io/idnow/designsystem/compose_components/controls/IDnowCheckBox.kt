package io.idnow.designsystem.compose_components.controls

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.triStateToggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.state.ToggleableState
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.controls.common.IDnowControlLayout
import io.idnow.designsystem.styles.compose.IDnowControlDefaults
import io.idnow.designsystem.styles.compose.IDnowControlStyle
import io.idnow.designsystem.xml_components.controls.check_box.CheckState
import io.idnow.designsystem.xml_components.controls.common.Size

/**
 * Compose counterpart of the XML `IDnowCheckBox`. A tri-state checkbox (mirrors [CheckState]:
 * CHECKED / UNCHECKED / INDETERMINATE) with an optional title, description, error and border.
 *
 * The control is one accessibility node ([Role.Checkbox]); spacing is applied by the caller through
 * [modifier]. Use [IDnowControlDefaults] only internally — the public API is the token enums.
 *
 * @param state current check state. INDETERMINATE is a display-only state (set programmatically, e.g.
 *   a "select all" parent); a user tap only ever produces checked/unchecked, hence the Boolean callback.
 * @param onCheckedChange invoked with the new checked value when tapped (CHECKED → false, UNCHECKED and
 *   INDETERMINATE → true).
 * @param errorText when non-null, shown below the box as an error message and turns the border red.
 * @param size box + typography size (BIG behaves like NORMAL for typography).
 */
@Composable
fun IDnowCheckBox(
    state: CheckState,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    text: String? = null,
    description: String? = null,
    errorText: String? = null,
    enabled: Boolean = true,
    borders: Boolean = false,
    divider: Boolean = false,
    size: Size = Size.NORMAL,
) {
    val style = IDnowControlDefaults.style(size)
    val interactionSource = remember { MutableInteractionSource() }
    // Mirror the XML `onInternalChange = { stateError = false }`: the error clears on first interaction
    // and reappears only if the caller supplies a new errorText.
    var errorVisible by rememberSaveable(errorText) { mutableStateOf(errorText != null) }
    IDnowControlLayout(
        style = style,
        text = text,
        description = description,
        errorText = errorText?.takeIf { errorVisible },
        enabled = enabled,
        borders = borders,
        divider = divider,
        isFieldOnRightSide = false,
        isActive = state != CheckState.UNCHECKED,
        controlModifier = Modifier.triStateToggleable(
            state = state.toToggleableState(),
            enabled = enabled,
            role = Role.Checkbox,
            interactionSource = interactionSource,
            indication = null,
            onClick = {
                errorVisible = false
                onCheckedChange(state != CheckState.CHECKED)
            },
        ),
        modifier = modifier,
    ) {
        CheckBoxIndicator(state, style)
    }
}

/** Rounded square: outlined when unchecked, filled with a check / minus glyph otherwise. */
@Composable
private fun CheckBoxIndicator(state: CheckState, style: IDnowControlStyle) {
    val shape = RoundedCornerShape(style.cornerRadius)
    val filled = state != CheckState.UNCHECKED
    Box(
        modifier = Modifier
            .size(style.indicatorSize)
            .then(
                if (filled) Modifier.background(style.activeColor, shape)
                else Modifier.border(style.activeStrokeWidth, style.strokeColor, shape),
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (filled) {
            val icon = if (state == CheckState.INDETERMINATE) R.drawable.sunflower_ic_minus else R.drawable.sunflower_ic_check
            Image(
                painter = painterResource(icon),
                contentDescription = null,
                colorFilter = ColorFilter.tint(style.iconColor),
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

private fun CheckState.toToggleableState(): ToggleableState = when (this) {
    CheckState.CHECKED -> ToggleableState.On
    CheckState.UNCHECKED -> ToggleableState.Off
    CheckState.INDETERMINATE -> ToggleableState.Indeterminate
}
