package io.idnow.designsystem.styles.xml

import android.content.Context
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.toDp

internal object ModalStyle {
    /** region Internal properties */
    /**
     * Background color of the modal
     */
    val backgroundColor get() = Tokens.backgroundPrimary

    /**
     * Modal's Close button tint color
     */
    val closeButtonTintColor get() = Tokens.secondaryActiveText

    /**
     * Top margin of the modal's content
     */
    val contentTopMargin get() = SpacingEnum.SPACING_LG

    /**
     * Bottom margin of the modal's content
     */
    val contentBottomMargin get() = SpacingEnum.SPACING_LG

    /**
     * Start margin of the modal's content
     */
    val contentStartMargin get() = SpacingEnum.SPACING_LG

    /**
     * End margin of the modal's content
     */
    val contentEndMargin get() = SpacingEnum.SPACING_LG

    /**
     * Margins of the modal's content
     */
    val contentMargins get() = SpacingQuad(
        start = contentStartMargin,
        top = contentTopMargin,
        end = contentEndMargin,
        bottom = contentBottomMargin
    )

    /**
     * Margins of the modal's positive button if it fills its container
     */
    val fillContainerPositiveButtonMargins get() = SpacingQuad(
        start = SpacingEnum.SPACING_LG,
        top = SpacingEnum.SPACING_MD,
        end = SpacingEnum.SPACING_LG,
        bottom = SpacingEnum.SPACING_MD
    )
    /** endregion Internal properties */

    /** region Internal methods */
    /**
     * Horizontal margin (in dp) of the modal
     */
    fun modalHorizontalMargin(context: Context) = SpacingEnum.SPACING_MD.value.toDp(context)

    /**
     * Corner radius (in dp) of the modal
     */
    fun cornerRadius(context: Context) = Tokens.radiusLg.toDp(context).toFloat()

    /**
     * Margins of the modal's title
     */
    fun titleMargins(isIconVisible: Boolean, isCloseButtonVisible: Boolean) = SpacingQuad(
        start = if(isIconVisible) SpacingEnum.SPACING_SM else SpacingEnum.SPACING_LG,
        top = SpacingEnum.SPACING_MD,
        end = if(isCloseButtonVisible) SpacingEnum.SPACING_SM else SpacingEnum.SPACING_LG
    )
    /** endregion Internal methods */
}