package io.idnow.designsystem.compose_components.form_input

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.form_input.common.ClickableInputIcon
import io.idnow.designsystem.compose_components.form_input.common.DecorIcon
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputDropdown
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputFrame
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputItemRow
import io.idnow.designsystem.compose_components.form_input.common.InputDecorationBox
import io.idnow.designsystem.compose_components.form_input.common.inputContentDescription
import io.idnow.designsystem.compose_components.form_input.common.rememberInputAccessibilityText
import io.idnow.designsystem.compose_components.form_input.common.resolveContainerState
import io.idnow.designsystem.styles.compose.IDnowFormInputDefaults
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItem

/** Filtering strategy for [IDnowAutoComplete] — mirrors the XML `AutoCompleteFilterType`. */
enum class IDnowAutoCompleteFilterType { CONTAINS, STARTS_WITH }

/**
 * Compose counterpart of the XML `IDnowAutoCompleteTextView`. A text field with a suggestions dropdown
 * filtered ([filterType]) over [suggestions]; optional leading magnifier and clear button.
 *
 * Dropdown behaviour — intentionally different from [IDnowSpinner] / [IDnowPhoneTextField], whose popups
 * are focusable:
 * - The dropdown is a **non-focusable** [IDnowInputDropdown], so the field keeps focus and the soft
 *   keyboard stays open while the user types and the list filters live (a focusable popup would close
 *   the keyboard and break type-to-filter).
 * - It stays open while the field is focused — **including after the keyboard is dismissed** (e.g. Back),
 *   so the filtered list remains visible. Consequently **Back does not close it** (a non-focusable popup
 *   cannot receive the Back key anyway); this is by design.
 * - It dismisses when: a suggestion is selected, OR focus moves elsewhere — the spinner/phone triggers
 *   request focus and other text fields take focus, so opening any of them closes this dropdown — OR the
 *   hosting screen clears focus on an outside tap. **Integrators should clear focus on background taps at
 *   the screen level** (e.g. `Modifier.pointerInput(Unit) { detectTapGestures { focusManager.clearFocus() } }`)
 *   to get tap-outside-to-dismiss, as the showcase does.
 */
@Composable
fun IDnowAutoComplete(
    value: String,
    onValueChange: (String) -> Unit,
    suggestions: List<IDnowItem>,
    onSuggestionSelected: (IDnowItem) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    hint: String? = null,
    helperText: String? = null,
    errorText: String? = null,
    isError: Boolean = false,
    enabled: Boolean = true,
    showLeadingIcon: Boolean = true,
    clearIcon: Boolean = false,
    filterType: IDnowAutoCompleteFilterType = IDnowAutoCompleteFilterType.CONTAINS,
) {
    val style = IDnowFormInputDefaults.style()
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    val focusManager = LocalFocusManager.current
    // Soft-keyboard height so the dropdown flips above the field instead of opening over the keyboard.
    val imeBottomPx = WindowInsets.ime.getBottom(LocalDensity.current)
    var anchorWidthPx by remember { mutableIntStateOf(0) }
    val containerState = resolveContainerState(focused = focused, isError = isError, enabled = enabled)
    val accessibilityText = rememberInputAccessibilityText(label, hint, errorText, isError, helperText)

    val filtered = remember(value, suggestions, filterType) {
        val query = value.trim().lowercase()
        if (query.isEmpty()) {
            suggestions
        } else {
            suggestions.filter {
                val content = it.content?.toString()?.trim()?.lowercase().orEmpty()
                when (filterType) {
                    IDnowAutoCompleteFilterType.STARTS_WITH -> content.startsWith(query)
                    IDnowAutoCompleteFilterType.CONTAINS -> content.contains(query)
                }
            }
        }
    }
    val expanded = focused && filtered.isNotEmpty()

    IDnowInputFrame(style, label, errorText, isError, helperText, modifier) {
        Box {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                singleLine = true,
                textStyle = style.fieldTextStyle,
                cursorBrush = SolidColor(style.cursorColor),
                interactionSource = interactionSource,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                modifier = Modifier
                    .onSizeChanged { anchorWidthPx = it.width }
                    .inputContentDescription(accessibilityText),
                decorationBox = { innerTextField ->
                    InputDecorationBox(
                        style = style,
                        containerState = containerState,
                        value = value,
                        hint = hint,
                        innerTextField = innerTextField,
                        leading = if (showLeadingIcon) {
                            { DecorIcon(painterResource(R.drawable.sunflower_ic_magnifying_glass), style.leadingIconTint, style.leadingIconSize) }
                        } else {
                            null
                        },
                        trailing = if (clearIcon && value.isNotEmpty()) {
                            {
                                ClickableInputIcon(
                                    painter = painterResource(R.drawable.sunflower_ic_cross_filled),
                                    tint = style.clearIconTint,
                                    size = style.clearIconSize,
                                    contentDescription = stringResource(R.string.sunflower_clear_content_description),
                                    enabled = enabled,
                                    onClick = { onValueChange("") },
                                )
                            }
                        } else {
                            null
                        },
                    )
                },
            )
            IDnowInputDropdown(
                expanded = expanded,
                onDismissRequest = { focusManager.clearFocus() },
                anchorWidthPx = anchorWidthPx,
                style = style,
                focusable = false,
                dismissOnClickOutside = false,
                occludedBottomPx = imeBottomPx,
            ) {
                items(filtered) { item ->
                    IDnowInputItemRow(
                        item = item,
                        style = style,
                        selected = false,
                        showCheck = false,
                        onClick = {
                            onSuggestionSelected(item)
                            focusManager.clearFocus()
                        },
                    )
                }
            }
        }
    }
}
