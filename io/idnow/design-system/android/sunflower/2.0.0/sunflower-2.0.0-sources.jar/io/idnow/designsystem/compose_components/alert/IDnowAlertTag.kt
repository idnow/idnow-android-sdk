package io.idnow.designsystem.compose_components.alert

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.text_view.IDnowText
import io.idnow.designsystem.styles.compose.IDnowAlertDefaults
import io.idnow.designsystem.styles.compose.IDnowAlertType

/**
 * Tokenized alert tag, the Compose counterpart of the XML `IDnowAlertTag`.
 *
 * A small pill-shaped, accent-tinted [label] with an optional leading indicator/icon. The label is
 * truncated to a single line with an ellipsis when it overflows. While pressed the background turns
 * to the solid accent color, mirroring the XML pressed `ColorStateList`. Colors, typography, corner
 * radius and paddings mirror the XML `AlertBoxAndTagStyle` 1:1.
 *
 * Spacing around the tag is applied by the caller through [modifier].
 *
 * @param label the tag text.
 * @param alertType the semantic type, driving accent color.
 * @param modifier the caller-owned modifier (spacing, width, …).
 * @param leadingIcon optional leading indicator dot / icon, rendered at its intrinsic colors.
 * @param onClick invoked when the tag is tapped.
 */
@Composable
fun IDnowAlertTag(
    modifier: Modifier = Modifier,
    label: String,
    alertType: IDnowAlertType = IDnowAlertType.INFO,
    leadingIcon: Painter? = null,
    onClick: () -> Unit = {},
) {
    val style = IDnowAlertDefaults.style(alertType)
    val typeDescription = alertType.accessibilityLabel()

    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val background = if (pressed) style.accentColor else style.tagBackgroundColor

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(style.tagCornerRadius))
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .background(background)
            .padding(style.tagItemPadding)
            .clearAndSetSemantics { contentDescription = "$typeDescription $label" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leadingIcon != null) {
            Image(
                painter = leadingIcon,
                contentDescription = null,
                modifier = Modifier.size(style.tagIconSize),
            )
            Spacer(Modifier.width(style.tagInnerItemPadding))
        }
        IDnowText(
            text = label,
            typography = TypographyEnum.BODY_XSMALL,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
