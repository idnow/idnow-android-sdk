package io.idnow.designsystem.compose_components.text_view

import android.graphics.Typeface
import android.text.style.StyleSpan
import android.text.style.URLSpan
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.core.text.HtmlCompat
import io.idnow.designsystem.common.LinkTypographyEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.linkVisitedColor
import io.idnow.designsystem.styles.compose.IDnowTextDefaults
import io.idnow.designsystem.styles.compose.IDnowTextStyle

/**
 * Tokenized text, the Compose counterpart of the XML `IDnowTextView`.
 *
 * Typography and color are expressed with the shared [TypographyEnum] / [TextColorEnum] tokens.
 * Spacing is applied by the caller via [modifier] (e.g. `Modifier.padding(SpacingEnum.SPACING_MD.dp)`).
 * `H1` is exposed as an accessibility heading, like the XML view.
 */
@Composable
fun IDnowText(
    text: String,
    modifier: Modifier = Modifier,
    typography: TypographyEnum = TypographyEnum.BODY,
    textColor: TextColorEnum = TextColorEnum.BODY,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    val style = IDnowTextDefaults.style(typography, textColor)
    BasicText(
        text = text,
        modifier = modifier.headingIfNeeded(style),
        style = style.textStyle,
        maxLines = maxLines,
        overflow = overflow,
    )
}

/** [AnnotatedString] variant, e.g. for mixed-span text. */
@Composable
fun IDnowText(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    typography: TypographyEnum = TypographyEnum.BODY,
    textColor: TextColorEnum = TextColorEnum.BODY,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    val style = IDnowTextDefaults.style(typography, textColor)
    BasicText(
        text = text,
        modifier = modifier.headingIfNeeded(style),
        style = style.textStyle,
        maxLines = maxLines,
        overflow = overflow,
    )
}

/**
 * HTML variant, the Compose counterpart of the XML `IDnowTextView.setHtmlText` + `handleUrlClicks`.
 *
 * Parses [html] (bold/italic/underline + `<a href>` links), renders links with the [linkTypography]
 * link style in the `LINK` token color, and — like the XML view — turns a link to the `linkVisited`
 * token color **once clicked** (sticky). [onLinkClick] receives the clicked URL.
 */
@Composable
fun IDnowText(
    html: String,
    onLinkClick: (String) -> Unit,
    modifier: Modifier = Modifier,
    typography: TypographyEnum = TypographyEnum.BODY,
    textColor: TextColorEnum = TextColorEnum.BODY,
    linkTypography: LinkTypographyEnum = LinkTypographyEnum.LINKS,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    val baseStyle = IDnowTextDefaults.style(typography, textColor).textStyle
    val linkStyle = linkTypography.asTextStyle(TextColorEnum.LINK.composeColor).toSpanStyle()
    val visitedColor = linkVisitedColor
    val annotated = rememberHtmlAnnotatedString(html, linkStyle, visitedColor, onLinkClick)
    BasicText(
        text = annotated,
        modifier = modifier,
        style = baseStyle,
        maxLines = maxLines,
        overflow = overflow,
    )
}

/** Convert an HTML string to an [AnnotatedString], mapping `<a>` links to clickable, visited-aware spans. */
@Composable
private fun rememberHtmlAnnotatedString(
    html: String,
    linkStyle: SpanStyle,
    visitedColor: Color,
    onLinkClick: (String) -> Unit,
): AnnotatedString {
    // rememberSaveable (not remember) so visited links survive configuration changes (rotation) and
    // process death — saved as the plain list of URLs.
    val visited = rememberSaveable(
        saver = listSaver(save = { it.toList() }, restore = { it.toMutableStateList() }),
    ) { mutableStateListOf<String>() }
    val spanned = remember(html) { HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_LEGACY) }
    return remember(spanned, linkStyle, visitedColor, visited.toList()) {
        buildAnnotatedString {
            append(spanned.toString())
            spanned.getSpans(0, spanned.length, Any::class.java).forEach { span ->
                val start = spanned.getSpanStart(span)
                val end = spanned.getSpanEnd(span)
                if (start !in 0..<end) return@forEach
                when (span) {
                    is URLSpan -> {
                        val url = span.url
                        val style = if (url in visited) linkStyle.copy(color = visitedColor) else linkStyle
                        addLink(
                            LinkAnnotation.Url(
                                url = url,
                                styles = TextLinkStyles(style = style),
                                linkInteractionListener = {
                                    if (url !in visited) visited.add(url)
                                    onLinkClick(url)
                                },
                            ),
                            start, end,
                        )
                    }

                    is StyleSpan -> when (span.style) {
                        Typeface.BOLD -> addStyle(SpanStyle(fontWeight = FontWeight.Bold), start, end)
                        Typeface.ITALIC -> addStyle(SpanStyle(fontStyle = FontStyle.Italic), start, end)
                        Typeface.BOLD_ITALIC ->
                            addStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic), start, end)
                    }
                }
            }
        }
    }
}

private fun Modifier.headingIfNeeded(style: IDnowTextStyle): Modifier = if (style.isHeading) this.semantics { heading() } else this