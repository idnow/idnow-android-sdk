package io.idnow.designsystem.compose_components.controls.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.compose.IDnowControlStyle

/**
 * Shared layout of the three Compose controls — the only thing each control adds is its checkable
 * [indicator]. Compose mirror of the XML `IDnowControls` container: a clickable row with the indicator
 * (left, or right when [isFieldOnRightSide]) and the title/description column, plus an optional bottom
 * error row and divider, an optional border, and disabled dimming.
 *
 * The whole control is a single accessibility node: [controlModifier] (provided by the caller) carries
 * the toggle/select semantics + role + click, and the spoken text is the merged [contentDescription]
 * (error prefix + title + description), mirroring the XML `accessibilityContentText()`. The caller's
 * [controlModifier] is built with `indication = null`, so there is no ripple (matching the XML view).
 *
 * @param isActive checked / indeterminate / on — drives the active border color.
 */
@Composable
internal fun IDnowControlLayout(
    style: IDnowControlStyle,
    text: String?,
    description: String?,
    errorText: String?,
    enabled: Boolean,
    borders: Boolean,
    divider: Boolean,
    isFieldOnRightSide: Boolean,
    isActive: Boolean,
    controlModifier: Modifier,
    modifier: Modifier = Modifier,
    indicator: @Composable () -> Unit,
) {
    val isError = errorText != null
    val warning = stringResource(R.string.sunflower_warning)
    val contDescription = buildString {
        if (isError && errorText.isNotEmpty()) append("$warning. ${errorText.withDot()} ")
        if (!text.isNullOrEmpty()) append("${text.withDot()} ")
        if (!description.isNullOrEmpty()) append("${description.withDot()} ")
    }.trim()

    val borderColor = when {
        isError -> style.errorColor
        isActive -> style.activeColor
        else -> style.strokeColor
    }
    val borderWidth = if (isError || isActive) style.activeStrokeWidth else style.emptyStrokeWidth
    val shape = RoundedCornerShape(style.cornerRadius)

    // Set contentDescription on the SAME node as the toggle/select semantics (controlModifier already
    // merges descendants + carries the role + checked/selected/on state), so TalkBack reads the label
    // together with the role-based state ("Checked/Not checked", "Selected/Not selected", "On/Off").
    val containerModifier = controlModifier
        .semantics { contentDescription = contDescription }
        .fillMaxWidth()
        .then(if (borders) Modifier.border(borderWidth, borderColor, shape).padding(style.borderPadding) else Modifier)
        .alpha(if (enabled) 1f else style.disabledAlpha)

    Column(modifier) {
        // Error row sits ABOVE the control (XML idn_tv_error is constraintBottom_toTopOf idn_container).
        if (isError) {
            Row(
                modifier = Modifier
                    .padding(bottom = style.verItemMargin)
                    .clearAndSetSemantics { },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(
                    painter = painterResource(R.drawable.sunflower_ic_warning),
                    contentDescription = null,
                    colorFilter = ColorFilter.tint(style.errorColor),
                    modifier = Modifier.size(style.errorIconSize),
                )
                Spacer(Modifier.width(style.itemSpacing))
                BasicText(text = errorText, style = style.errorTextStyle)
            }
        }

        // The indicator is top-aligned; the text is centered against it only when single-line, and
        // top-aligned (with a small contentMargin) when multi-line — mirroring XML updateTextConstraints.
        val bothTexts = !text.isNullOrEmpty() && !description.isNullOrEmpty()
        var multiLine by remember(text, description) { mutableStateOf(bothTexts) }
        val vAlign = if (multiLine) Alignment.Top else Alignment.CenterVertically
        Box(containerModifier) {
            Row(modifier = Modifier.fillMaxWidth()) {
                if (!isFieldOnRightSide) {
                    Box(Modifier.align(vAlign)) { indicator() }
                    Spacer(Modifier.width(style.itemSpacing))
                }
                ControlTexts(
                    text = text,
                    description = description,
                    style = style,
                    modifier = Modifier
                        .weight(1f)
                        .align(vAlign)
                        .then(if (multiLine) Modifier.padding(top = style.contentMargin) else Modifier),
                    onMultiLineChange = { wraps -> multiLine = wraps || bothTexts },
                )
                if (isFieldOnRightSide) {
                    Spacer(Modifier.width(style.itemSpacing))
                    Box(Modifier.align(vAlign)) { indicator() }
                }
            }
        }

        if (divider) {
            Box(
                modifier = Modifier
                    .padding(top = style.verItemMargin)
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(style.dividerColor),
            )
        }
    }
}

/** Title + description column. When there is no title, the description takes the title's place. */
@Composable
private fun ControlTexts(
    text: String?,
    description: String?,
    style: IDnowControlStyle,
    modifier: Modifier,
    onMultiLineChange: (Boolean) -> Unit,
) {
    val hasText = !text.isNullOrEmpty()
    val hasDescription = !description.isNullOrEmpty()
    Column(modifier) {
        when {
            hasText -> {
                BasicText(
                    text = text,
                    style = style.titleTextStyle,
                    onTextLayout = { if (!hasDescription) onMultiLineChange(it.lineCount > 1) },
                    modifier = Modifier.clearAndSetSemantics { },
                )
                if (hasDescription) {
                    BasicText(
                        text = description,
                        style = style.descriptionTextStyle,
                        modifier = Modifier.padding(top = style.itemSpacing).clearAndSetSemantics { },
                    )
                }
            }
            hasDescription -> BasicText(
                text = description,
                style = style.descriptionTextStyle,
                onTextLayout = { onMultiLineChange(it.lineCount > 1) },
                modifier = Modifier.clearAndSetSemantics { },
            )
        }
    }
}

private fun String.withDot(): String = if (endsWith(".")) this else "$this."
