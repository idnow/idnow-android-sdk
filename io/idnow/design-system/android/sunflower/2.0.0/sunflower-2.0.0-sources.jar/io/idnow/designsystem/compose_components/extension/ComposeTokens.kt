package io.idnow.designsystem.compose_components.extension

import android.annotation.SuppressLint
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.LinkTypographyEnum
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography

/**
 * Compose bridge over the shared design-system tokens. The XML world reads [io.idnow.designsystem.tokens.Tokens]
 * directly; the Compose world goes through these extensions so that every read observes the
 * snapshot-backed `IDnowDesignSystem.primitives` and recomposes when `IDnowDesignSystem.setup()` is called at runtime.
 *
 * Components must NOT read `Tokens.*` directly — always go through an enum + one of these extensions.
 */

// --- Spacing -------------------------------------------------------------

/**
 * Convert a [SpacingEnum] token to a Compose [Dp].
 *
 * [SpacingEnum.value] is a **dp magnitude** (e.g. `SPACING_MD` = 16 → 16dp), not pixels — in the XML
 * world it is turned into pixels via `Int.toDp(context)` (which is really dp→px). So here we wrap it
 * straight as `value.dp`; do NOT route it through `Density.toDp()`, which would treat it as pixels
 * and shrink the spacing by the device density.
 */
val SpacingEnum.dp: Dp @SuppressLint("ResourceType")
get() = value.dp

// --- Colors --------------------------------------------------------------

val TextColorEnum.composeColor: Color
    @Composable
    @ReadOnlyComposable
    get() = Color(color())

val TintColorEnum.composeColor: Color
    @Composable
    @ReadOnlyComposable
    get() = Color(color())

val BackgroundColorEnum.composeColor: Color
    @Composable
    @ReadOnlyComposable
    get() = Color(color())

// --- Typography ----------------------------------------------------------

/**
 * Map a [TypographyEnum] to a Compose [TextStyle], reusing the exact same resolution as the XML
 * components ([TypographyEnum.toTypography]) so font, size, line-height and underline match 1:1.
 *
 * @param color optional text color; defaults to [Color.Unspecified] (inherited).
 */
@Composable
fun TypographyEnum.asTextStyle(color: Color = Color.Unspecified): TextStyle {
    val context = LocalContext.current
    // Read the snapshot-backed primitives so a re-theme invalidates this composition, and key the
    // remember on it so the (remember-cached) typography is recomputed when primitives change.
    val primitives = IDnowDesignSystem.primitives
    return remember(this, primitives, color) { toTypography(context).toComposeTextStyle(color) }
}

/**
 * Map a [LinkTypographyEnum] to a Compose [TextStyle] (underlined link typography), reusing the same
 * resolution as the XML link handling.
 */
@Composable
fun LinkTypographyEnum.asTextStyle(color: Color = Color.Unspecified): TextStyle {
    val context = LocalContext.current
    // Read the snapshot-backed primitives so a re-theme invalidates this composition, and key the
    // remember on it so the (remember-cached) typography is recomputed when primitives change.
    val primitives = IDnowDesignSystem.primitives
    return remember(this, primitives, color) { toTypography(context).toComposeTextStyle(color) }
}

/** Token color a link turns to once visited/clicked. No enum equivalent, so bridged directly. */
val linkVisitedColor: Color
    @Composable
    @ReadOnlyComposable
    get() = Color(Tokens.linkVisited)

/** Shared builder: a tokens [Typography] → Compose [TextStyle], matching the XML rendering 1:1. */
private fun Typography.toComposeTextStyle(color: Color): TextStyle = TextStyle(
    color = color,
    fontSize = size.sp, // already in sp via applyFontUpdate()
    // lineSpacingMultiplier is relative to the font size → express line height in em.
    lineHeight = lineSpacingMultiplier.em,
    fontFamily = FontFamily(typeface),
    textDecoration = if (isUnderlined) TextDecoration.Underline else null,
    // Match the XML IDnowTextView, which keeps the platform default (font padding on).
    platformStyle = PlatformTextStyle(includeFontPadding = true),
)
