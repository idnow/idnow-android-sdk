package io.idnow.designsystem.compose_components.controls.pdf

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.buttons.IDnowButton
import io.idnow.designsystem.compose_components.buttons.IDnowButtonIconPosition
import io.idnow.designsystem.compose_components.buttons.IDnowFABButton
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.text_view.IDnowText
import io.idnow.designsystem.styles.compose.IDnowPdfLayoutDefaults
import kotlin.math.max
import kotlin.math.roundToInt

/**
 *
 * This is a re-upload button, a `current/total` page label, two
 * zoom FABs and a zoom-percent label on a secondary background — plus a [content] slot into which the
 * caller places the actual PDF view (the design system does not depend on a PDF renderer). The XML
 * `var totalPage/currentPage/zoomScale` become parameters and the `Listener` becomes the three click
 * lambdas.
 *
 * @param currentPage the current page (shown as `current/total`).
 * @param totalPage the total page count.
 * @param zoomScale the current zoom (shown as a percentage; always rendered as ≥ 0).
 * @param onReuploadClick invoked when the re-upload button is tapped.
 * @param onDecreaseZoomClick invoked when the zoom-out FAB is tapped.
 * @param onIncreaseZoomClick invoked when the zoom-in FAB is tapped.
 * @param modifier caller-applied spacing/layout (the XML margins live here).
 * @param showReupload whether the re-upload button is shown (XML `showReupload`, default true).
 * @param content the PDF view (and any overlays such as a maximize FAB) placed below the controls.
 */
@Composable
fun IDnowPdfLayout(
    currentPage: Int,
    totalPage: Int,
    zoomScale: Float,
    onReuploadClick: () -> Unit,
    onDecreaseZoomClick: () -> Unit,
    onIncreaseZoomClick: () -> Unit,
    modifier: Modifier = Modifier,
    showReupload: Boolean = true,
    content: @Composable BoxScope.() -> Unit,
) {
    val style = IDnowPdfLayoutDefaults.style()

    val safeTotal = max(0, totalPage)
    val safeCurrent = currentPage.coerceIn(0, safeTotal)
    val zoomPercent = (max(0f, zoomScale) * 100f).roundToInt()

    val pageDescription = stringResource(R.string.sunflower_pdf_accessibility_page, safeCurrent, safeTotal)
    val zoomAt = stringResource(R.string.sunflower_pdf_accessibility_zoom, zoomPercent)
    val zoomOutDescription = "$zoomAt ${stringResource(R.string.sunflower_pdf_accessibility_zoom_out)}"
    val zoomInDescription = "$zoomAt ${stringResource(R.string.sunflower_pdf_accessibility_zoom_in)}"
    val containerDescription = stringResource(R.string.sunflower_pdf_accessibility_desc)

    Column(
        modifier = modifier
            .background(style.backgroundColor.composeColor)
            .padding(style.contentPadding)
            .semantics { contentDescription = containerDescription },
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (showReupload) {
                IDnowButton(
                    text = stringResource(R.string.sunflower_pdf_upload_label),
                    onClick = onReuploadClick,
                    style = style.reuploadButtonStyle,
                    icon = painterResource(R.drawable.sunflower_ic_upload),
                    iconPosition = IDnowButtonIconPosition.START,
                )
            }

            // Page count: centered in the space between the re-upload button and the zoom controls,
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center,
            ) {
                IDnowText(
                    text = "$safeCurrent/$safeTotal",
                    typography = style.pageLabelTypography,
                    modifier = Modifier.semantics { contentDescription = pageDescription },
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(style.headerItemSpacing),
            ) {
                IDnowFABButton(
                    icon = painterResource(R.drawable.sunflower_ic_minus),
                    onClick = onDecreaseZoomClick,
                    style = style.zoomFabStyle,
                    contentDescription = zoomOutDescription,
                )
                IDnowText(
                    text = stringResource(R.string.sunflower_percent, zoomPercent),
                    typography = style.zoomLabelTypography,
                    modifier = Modifier.clearAndSetSemantics { },
                )
                IDnowFABButton(
                    icon = painterResource(R.drawable.sunflower_ic_plus),
                    onClick = onIncreaseZoomClick,
                    style = style.zoomFabStyle,
                    contentDescription = zoomInDescription,
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(top = style.contentPadding),
            content = content,
        )
    }
}
