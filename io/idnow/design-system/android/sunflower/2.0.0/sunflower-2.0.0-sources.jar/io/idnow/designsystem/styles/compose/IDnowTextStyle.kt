package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor

/**
 * Fully-resolved visual values for `IDnowText`.
 *
 * There is no dedicated XML style file for text (the XML `IDnowTextView` reads [TypographyEnum] +
 * [TextColorEnum] directly); this holder mirrors that behaviour by carrying the resolved [TextStyle]
 * plus the accessibility-heading flag (the XML view marks `H1` as a heading).
 */
@Immutable
data class IDnowTextStyle(
    /** Resolved typography + color. */
    val textStyle: TextStyle,
    /** Whether the text is exposed as an accessibility heading (XML: typography == H1). */
    val isHeading: Boolean,
)

/** Default resolver for [IDnowTextStyle], analogous to Material3's `XxxDefaults`. */
object IDnowTextDefaults {

    @Composable
    fun style(
        typography: TypographyEnum = TypographyEnum.BODY,
        textColor: TextColorEnum = TextColorEnum.BODY,
    ): IDnowTextStyle = IDnowTextStyle(
        textStyle = typography.asTextStyle(color = textColor.composeColor),
        isHeading = typography == TypographyEnum.H1,
    )
}
