package io.idnow.designsystem.xml_components.controls.radio

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatRadioButton
import io.idnow.designsystem.styles.xml.ControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.DrawableEntryBuilder
import io.idnow.designsystem.xml_components.extension.LayerBuilder
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.size
import io.idnow.designsystem.xml_components.extension.stateListDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp

internal class IDnowRadioButtonInternal : AppCompatRadioButton {
    /** Internal usage only ! Notify a control of a change. */
    var onInternalChange: (() -> Unit)? = null

    /** Size of the check box */
    var size: Size = Size.NORMAL
        set(value) {
            field = value
            setupDrawable()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    override fun toggle() {
        /* Only trigger the state changes if the radio is enabled */
        if (isEnabled) {
            isChecked = !isChecked
        }
    }

    override fun setChecked(checked: Boolean) {
        /** Notify internally */
        onInternalChange?.invoke()
        super.setChecked(checked)
    }

    private fun setupDrawable() {
        val radioSize = ControlStyle.controlSize(size).toDp(context)
        val strokeWidth = ControlStyle.strokeWidth().toDp(context)
        fun DrawableEntryBuilder.outline(color: Int) = gradient {
            shape = GradientDrawable.OVAL
            size(radioSize)
            stroke(color = color, width = strokeWidth)
        }

        buttonDrawable = stateListDrawable {
            state(states = intArrayOf(android.R.attr.state_checked)) {
                layerList {
                    layer {
                        inset = LayerBuilder.Insets(strokeWidth + 2.toDp(context))
                        gradient {
                            shape = GradientDrawable.OVAL
                            color(ControlStyle.activeColor)
                        }
                    }
                    layer { outline(ControlStyle.activeColor) }
                }
            }
            state { outline(ControlStyle.strokeColor) }
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ControlStyle.opacity(enabled)
    }
}