package io.idnow.designsystem.compose_components.controls

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import io.idnow.designsystem.compose_components.controls.common.IDnowControlLayout
import io.idnow.designsystem.styles.compose.IDnowControlDefaults
import io.idnow.designsystem.styles.compose.IDnowControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size

/**
 * Compose counterpart of the XML `IDnowSwitch`. A toggle with an optional title, description, error
 * and border. Unlike checkbox/radio, the switch sits on the **right** of the texts (XML
 * `isFieldOnRightSide = true`).
 *
 * The control is one accessibility node ([Role.Switch]); spacing is applied by the caller through
 * [modifier]. Switch supports SMALL / NORMAL sizes (BIG behaves like NORMAL).
 *
 * @param checked whether the switch is on.
 * @param onCheckedChange invoked with the new value when the control is tapped.
 * @param errorText when non-null, shown below the row as an error message and turns the border red.
 */
@Composable
fun IDnowSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    text: String? = null,
    description: String? = null,
    errorText: String? = null,
    enabled: Boolean = true,
    borders: Boolean = false,
    divider: Boolean = false,
    size: Size = Size.NORMAL,
) {
    val style = IDnowControlDefaults.style(size)
    val interactionSource = remember { MutableInteractionSource() }
    // Mirror the XML `onInternalChange = { stateError = false }`: the error clears on first interaction
    // and reappears only if the caller supplies a new errorText.
    var errorVisible by rememberSaveable(errorText) { mutableStateOf(errorText != null) }
    IDnowControlLayout(
        style = style,
        text = text,
        description = description,
        errorText = errorText?.takeIf { errorVisible },
        enabled = enabled,
        borders = borders,
        divider = divider,
        isFieldOnRightSide = true,
        isActive = checked,
        controlModifier = Modifier.toggleable(
            value = checked,
            enabled = enabled,
            role = Role.Switch,
            interactionSource = interactionSource,
            indication = null,
            onValueChange = { errorVisible = false; onCheckedChange(it) },
        ),
        modifier = modifier,
    ) {
        SwitchIndicator(checked, style)
    }
}

/** Rounded track + circular thumb that slides between the two ends, inset by [IDnowControlStyle.thumbInset]. */
@Composable
private fun SwitchIndicator(checked: Boolean, style: IDnowControlStyle) {
    val targetOffset = if (checked) style.trackWidth - style.thumbSize - style.thumbInset else style.thumbInset
    val thumbOffset by animateDpAsState(targetValue = targetOffset, label = "thumbOffset")
    Box(
        modifier = Modifier
            .size(width = style.trackWidth, height = style.trackHeight)
            .background(
                color = if (checked) style.activeColor else style.uncheckedTrackColor,
                shape = RoundedCornerShape(style.trackHeight / 2),
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier
                .offset(x = thumbOffset)
                .size(style.thumbSize)
                .background(style.knobColor, CircleShape),
        )
    }
}
