package io.idnow.designsystem.compose_components.message

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.styles.compose.IDnowMessageDefaults

/**
 * Tokenized message banner, the Compose counterpart of the XML `IDnowMessageView`.
 *
 * A rounded container (corner radius = `radiusMd`) filled with the `backgroundDarker` token at 0.8
 * alpha, holding an optional [startIcon] and a [title]. The icon tint and the title color are the
 * "foreground" (`backgroundPrimary` token). Spacing around the component is applied by the caller
 * via [modifier].
 *
 * @param title the message text.
 * @param startIcon optional leading icon, tinted with the foreground color.
 */
@Composable
fun IDnowMessage(
    title: String,
    modifier: Modifier = Modifier,
    startIcon: Painter? = null,
) {
    val style = IDnowMessageDefaults.style()
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(style.cornerRadius))
            .background(style.backgroundColor)
            .padding(style.contentPadding),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(style.iconTitleGap),
    ) {
        if (startIcon != null) {
            Image(
                painter = startIcon,
                contentDescription = null,
                contentScale = ContentScale.None,
                colorFilter = ColorFilter.tint(style.foregroundColor),
            )
        }
        BasicText(
            text = title,
            style = TypographyEnum.BODY.asTextStyle(color = style.foregroundColor),
        )
    }
}
