package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils
import io.idnow.designsystem.R
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.tokens.Tokens

/**
 * Button variant, the Compose counterpart of the XML sealed `ButtonStyle` subclasses.
 *
 * Unlike most Compose components in this design system (where the style is an internal resolver),
 * the button variant + size are an **intentional public parameter** ([IDnowButtonStyle]): the product
 * owner wants callers to pass "the style to apply".
 */
enum class IDnowButtonVariant { PRIMARY, SECONDARY, DANGER, TRIGGER }

/** Button size, mirrors the XML `ButtonSize`. */
enum class IDnowButtonSize { SMALL, MEDIUM, LARGE }

/**
 * Public style selector for [io.idnow.designsystem.compose_components.buttons.IDnowButton]: pick a
 * [variant] and a [size]. The actual colors / paddings / typography / corner radius / stroke are
 * resolved from the tokens by [IDnowButtonDefaults.resolved], producing the same values as the
 * matching XML `ButtonStyle` subclass.
 */
@Immutable
data class IDnowButtonStyle(
    val variant: IDnowButtonVariant,
    val size: IDnowButtonSize = IDnowButtonSize.MEDIUM,
) {
    companion object {
        fun primary(size: IDnowButtonSize = IDnowButtonSize.MEDIUM) = IDnowButtonStyle(IDnowButtonVariant.PRIMARY, size)
        fun secondary(size: IDnowButtonSize = IDnowButtonSize.MEDIUM) = IDnowButtonStyle(IDnowButtonVariant.SECONDARY, size)
        fun danger(size: IDnowButtonSize = IDnowButtonSize.MEDIUM) = IDnowButtonStyle(IDnowButtonVariant.DANGER, size)
        fun trigger(size: IDnowButtonSize = IDnowButtonSize.MEDIUM) = IDnowButtonStyle(IDnowButtonVariant.TRIGGER, size)    }
}

/**
 * Fully-resolved visual values the button composable reads from. Mirrors what the XML `ButtonStyle`
 * exposes (background/stroke/text colors, their pressed variants, corner radius = radiusFull, content
 * paddings, typography, stroke width, icon size + padding).
 */
@Immutable
data class IDnowResolvedButtonStyle(
    val backgroundColor: Color,
    val pressedBackgroundColor: Color,
    val strokeColor: Color,
    val pressedStrokeColor: Color,
    val textColor: Color,
    val cornerRadius: Dp,
    val strokeWidth: Dp,
    val paddingStart: Dp,
    val paddingTop: Dp,
    val paddingEnd: Dp,
    val paddingBottom: Dp,
    val textStyle: TextStyle,
    val iconSize: Dp,
    val iconPadding: Dp,
    val disabledOpacity: Float,
)

/** Default resolver for [IDnowResolvedButtonStyle], analogous to Material3's `XxxDefaults`. */
object IDnowButtonDefaults {

    /** Stroke width in dp, matching the XML `ButtonStyle.strokeWidth` (1.5dp). */
    private const val STROKE_WIDTH_DP = 1.5f

    /** Trigger inner-layer inset in dp, matching the XML `TriggerButton` layer inset (4dp). */

    /** Disabled alpha, matching XML `ButtonStyle.opacity(false)`. */
    const val DISABLED_OPACITY = 0.5f

    /**
     * Resolve a [IDnowButtonStyle] (variant + size) to the concrete visual values, reading the
     * tokens through the Compose extensions so a runtime re-theme recomposes.
     */
    @Composable
    fun resolved(style: IDnowButtonStyle): IDnowResolvedButtonStyle {
        // Read snapshot-backed primitives so token reads inside remember are observed.
        val primitives = IDnowDesignSystem.primitives

        val backgroundArgb: Int
        val strokeArgb: Int
        val textArgb: Int
        val pressedOpacity: Float
        when (style.variant) {
            IDnowButtonVariant.PRIMARY, IDnowButtonVariant.TRIGGER -> {
                backgroundArgb = Tokens.primaryBackground
                strokeArgb = Tokens.primaryBackground
                textArgb = Utils.getLuminanceTokenForPrimaryText(backgroundArgb)
                pressedOpacity = 0.25f
            }
            IDnowButtonVariant.SECONDARY -> {
                backgroundArgb = Tokens.secondaryActiveBackground
                strokeArgb = Tokens.secondaryActiveStroke
                textArgb = Tokens.secondaryActiveText
                pressedOpacity = 0.05f
            }
            IDnowButtonVariant.DANGER -> {
                backgroundArgb = Tokens.error
                strokeArgb = Tokens.error
                textArgb = Utils.getLuminanceTokenForPrimaryText(backgroundArgb)
                pressedOpacity = 0.25f
            }
        }

        // Pressed color = blend toward backgroundDarker with the variant's opacity (XML ButtonStyle.pressedColor).
        val pressedBackgroundArgb = ColorUtils.blendARGB(backgroundArgb, Tokens.backgroundDarker, pressedOpacity)
        val pressedStrokeArgb = ColorUtils.blendARGB(strokeArgb, Tokens.backgroundDarker, pressedOpacity)

        val typography = when (style.size) {
            IDnowButtonSize.SMALL -> TypographyEnum.BODY_XSMALL_BOLD
            IDnowButtonSize.MEDIUM, IDnowButtonSize.LARGE -> TypographyEnum.H6
        }
        val iconSizeRes = when (style.size) {
            IDnowButtonSize.SMALL -> R.dimen.idnow_small_icon_size
            IDnowButtonSize.MEDIUM -> R.dimen.idnow_icon_size
            IDnowButtonSize.LARGE -> R.dimen.idnow_big_icon_size
        }
        val (padH, padV) = when (style.size) {
            IDnowButtonSize.SMALL -> SpacingEnum.SPACING_MD to SpacingEnum.SPACING_SM
            IDnowButtonSize.MEDIUM, IDnowButtonSize.LARGE -> SpacingEnum.SPACING_LG to SpacingEnum.SPACING_MD
        }
        val iconPadding = when (style.size) {
            IDnowButtonSize.SMALL -> SpacingEnum.SPACING_XS
            IDnowButtonSize.MEDIUM, IDnowButtonSize.LARGE -> SpacingEnum.SPACING_SM
        }

        return IDnowResolvedButtonStyle(
            backgroundColor = Color(backgroundArgb),
            pressedBackgroundColor = Color(pressedBackgroundArgb),
            strokeColor = Color(strokeArgb),
            pressedStrokeColor = Color(pressedStrokeArgb),
            textColor = Color(textArgb),
            // radiusFull token is a dp magnitude (see ComposeTokens unit note) → wrap as .dp.
            cornerRadius = Tokens.radiusFull.dp,
            strokeWidth = STROKE_WIDTH_DP.dp,
            paddingStart = padH.dp,
            paddingTop = padV.dp,
            paddingEnd = padH.dp,
            paddingBottom = padV.dp,
            textStyle = typography.asTextStyle(Color(textArgb)),
            iconSize = dimensionResource(iconSizeRes),
            iconPadding = iconPadding.dp,
            disabledOpacity = DISABLED_OPACITY,
        )
    }
}
