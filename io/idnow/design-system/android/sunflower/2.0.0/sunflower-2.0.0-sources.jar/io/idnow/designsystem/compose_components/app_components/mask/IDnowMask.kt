package io.idnow.designsystem.compose_components.app_components.mask

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.styles.compose.IDnowMaskDefaults
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskOverlay
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskShape
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskStatus

/**
 * Compose counterpart of the XML `IDnowMaskView`: a mask drawn on top of a camera/image. It darkens
 * everything outside [quad] with [maskBackgroundColor] and cuts the [shape] out (so the camera shows
 * through), then strokes an [overlay] in the [status] color on top.
 *
 * Stack it over the camera/preview in a `Box`. The [quad] is given in **pixels** (four corners,
 * supporting a skewed quadrilateral for live document detection) — compute it from the drawing size
 * (e.g. via `Modifier.onSizeChanged`). Reuses the same model types as the XML view.
 *
 * `Progress` fills the outline once over its duration then stays full; re-assigning the overlay (or
 * changing [shape]) replays it. `Corners(isBouncing = true)` pulses the corner brackets.
 */
@Composable
fun IDnowMask(
    quad: IDnowMaskQuad,
    modifier: Modifier = Modifier,
    shape: IDnowMaskShape = IDnowMaskShape.RECT,
    overlay: IDnowMaskOverlay = IDnowMaskOverlay.None,
    status: IDnowMaskStatus = IDnowMaskStatus.ACTIVE,
    maskBackgroundColor: Color = BackgroundColorEnum.SECONDARY.composeColor,
) {
    val style = IDnowMaskDefaults.style()
    val statusColor = status.tint.composeColor

    // Bounce: pulse the corner brackets (1 → power → 1), only when requested.
    val bouncing = overlay is IDnowMaskOverlay.Corners && overlay.isBouncing
    val bounceScale = if (bouncing) {
        val transition = rememberInfiniteTransition(label = "maskBounce")
        val scale by transition.animateFloat(
            initialValue = 1f,
            targetValue = style.bouncePower,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = style.bounceDurationMillis / 2, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "maskBounceScale",
        )
        scale
    } else {
        1f
    }

    // Progress: fill the outline once, replayed when the overlay/shape changes.
    val progress = remember { Animatable(0f) }
    val progressOverlay = overlay as? IDnowMaskOverlay.Progress
    LaunchedEffect(progressOverlay, shape) {
        if (progressOverlay != null) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMillis = progressOverlay.duration, easing = LinearEasing))
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val cornerWidth = style.cornerWidth.toPx()
        val cubicCorner = style.cubicCornerWidth.toPx()

        // Shape: outer rect + cut-out shape (EvenOdd) → only the surrounding area is painted.
        val shapePath = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(0f, 0f, size.width, size.height))
            if (!quad.isEmpty()) {
                addPath(
                    if (shape == IDnowMaskShape.RECT) roundedRectMaskPath(quad, cornerWidth, cubicCorner, useCompleteLines = true)
                    else ovalMaskPath(quad),
                )
            }
        }
        drawPath(shapePath, color = maskBackgroundColor)

        if (quad.isEmpty()) return@Canvas

        // Overlay stroke.
        val overlayPath: Path? = when (overlay) {
            IDnowMaskOverlay.None -> null
            is IDnowMaskOverlay.Corners ->
                if (shape == IDnowMaskShape.RECT) roundedRectMaskPath(quad, cornerWidth, cubicCorner, useCompleteLines = false)
                else ovalCornersMaskPath(quad)

            IDnowMaskOverlay.Full ->
                if (shape == IDnowMaskShape.RECT) roundedRectMaskPath(quad, cornerWidth, cubicCorner, useCompleteLines = true)
                else ovalMaskPath(quad)

            is IDnowMaskOverlay.Progress -> {
                val full = if (shape == IDnowMaskShape.RECT) roundedRectMaskPath(quad, cornerWidth, cubicCorner, useCompleteLines = true)
                else ovalMaskPath(quad)
                progressSegment(full, progress.value)
            }
        }

        overlayPath?.let { path ->
            val stroke = Stroke(width = style.strokeWidth.toPx(), join = StrokeJoin.Round)
            if (bouncing) {
                val pivot = Offset(
                    x = (quad.leftTop.x + quad.rightTop.x) / 2f,
                    y = (quad.leftTop.y + quad.leftBottom.y) / 2f,
                )
                scale(bounceScale, pivot) { drawPath(path, color = statusColor, style = stroke) }
            } else {
                drawPath(path, color = statusColor, style = stroke)
            }
        }
    }
}

/** Map a mask status to its tint token so the overlay color re-themes. */
private val IDnowMaskStatus.tint: TintColorEnum
    get() = when (this) {
        IDnowMaskStatus.ACTIVE -> TintColorEnum.ACTIVE
        IDnowMaskStatus.PROCESSING -> TintColorEnum.PROCESSING
        IDnowMaskStatus.SUCCESS -> TintColorEnum.SUCCESS
        IDnowMaskStatus.ERROR -> TintColorEnum.ERROR
    }
