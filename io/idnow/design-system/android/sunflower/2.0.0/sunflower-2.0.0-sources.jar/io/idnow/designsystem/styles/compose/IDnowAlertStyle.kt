package io.idnow.designsystem.styles.compose

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.tokens.Tokens

/**
 * The semantic alert type, mirroring the XML `IDnowAlertType`. Drives the accent color and the
 * default leading icon of [io.idnow.designsystem.compose_components.alert.IDnowAlertBox] /
 * [io.idnow.designsystem.compose_components.alert.IDnowAlertTag].
 */
enum class IDnowAlertType(
    @DrawableRes val drawable: Int,
    internal val tint: TintColorEnum,
) {
    INFO(R.drawable.sunflower_ic_information_filled, TintColorEnum.ACTIVE),
    ERROR(R.drawable.sunflower_ic_cross_filled, TintColorEnum.ERROR),
    WARNING(R.drawable.sunflower_ic_warning_filled, TintColorEnum.PROCESSING),
    SUCCESS(R.drawable.sunflower_ic_check_filled, TintColorEnum.SUCCESS),
}

/**
 * Fully-resolved visual values shared by `IDnowAlertBox` and `IDnowAlertTag`.
 *
 * Mirrors the XML [io.idnow.designsystem.styles.xml.AlertBoxAndTagStyle] 1:1: the accent color
 * (per [IDnowAlertType]), the 20%-opacity background blend used by the box, the text color and
 * typography, the corner radii and the inner paddings/icon sizes.
 */
@Immutable
data class IDnowAlertStyle(
    /** Accent color (icon tint, tag pressed/solid color). */
    val accentColor: Color,
    /** Box background: accent blended at [bgColorOpacity] over the surface color. */
    val boxBackgroundColor: Color,
    /** Tag idle background: same blend as the box. */
    val tagBackgroundColor: Color,
    /** Text color for the message/label. */
    val textColor: Color,
    /** Box message typography. */
    val boxTextStyle: TextStyle,
    /** Tag label typography. */
    val tagTextStyle: TextStyle,
    /** Box corner radius. */
    val boxCornerRadius: Dp,
    /** Tag corner radius (full/pill). */
    val tagCornerRadius: Dp,
    /** Inner padding of the box, also the gap between the box content items. */
    val boxItemPadding: Dp,
    /** Inner padding of the tag. */
    val tagItemPadding: Dp,
    /** Gap between the tag leading icon and the label. */
    val tagInnerItemPadding: Dp,
    /** Leading icon size of a tag. */
    val tagIconSize: Dp,
    /** The default leading icon for the [IDnowAlertType]. */
    @DrawableRes val typeDrawable: Int,
)

/** Default resolver for [IDnowAlertStyle], analogous to Material3's `XxxDefaults`. */
object IDnowAlertDefaults {

    /** Background opacity of the accent blend, matching the XML `AlertBoxAndTagStyle.bgColorOpacity`. */
    private const val BG_COLOR_OPACITY = 0.2f

    /** Tag leading-icon size in dp, matching the XML `AlertBoxAndTagStyle.alertIconSize`. */
    private const val TAG_ICON_SIZE_DP = 10

    @Composable
    fun style(alertType: IDnowAlertType): IDnowAlertStyle {
        val accent = alertType.tint.composeColor
        // XML blends the accent over Tokens.background (grey100/grey900) keeping (1 - opacity) of it,
        // i.e. fraction = bgColorOpacity towards the accent.
        val surface = BackgroundColorEnum.PRIMARY.composeColor
        val blended = lerp(surface, accent, BG_COLOR_OPACITY)
        val text = TextColorEnum.BODY.composeColor
        return IDnowAlertStyle(
            accentColor = accent,
            boxBackgroundColor = blended,
            tagBackgroundColor = blended,
            textColor = text,
            boxTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(text),
            tagTextStyle = TypographyEnum.BODY_XSMALL.asTextStyle(text),
            boxCornerRadius = Tokens.radiusMd.dp,
            tagCornerRadius = Tokens.radiusFull.dp,
            boxItemPadding = SpacingEnum.SPACING_MD.dp,
            tagItemPadding = SpacingEnum.SPACING_SM.dp,
            tagInnerItemPadding = SpacingEnum.SPACING_XS.dp,
            tagIconSize = TAG_ICON_SIZE_DP.dp,
            typeDrawable = alertType.drawable,
        )
    }
}
