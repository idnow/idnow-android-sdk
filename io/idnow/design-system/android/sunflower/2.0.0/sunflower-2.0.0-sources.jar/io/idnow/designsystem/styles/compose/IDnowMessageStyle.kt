package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp as spacingDp
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values for `IDnowMessage`, mirroring the XML
 * [io.idnow.designsystem.styles.xml.MessageViewStyle] and the `idnow_message_view.xml` layout.
 *
 * The message is a rounded container ([cornerRadius] = `radiusMd`) filled with [backgroundColor]
 * (`backgroundDarker` token at [MessageViewStyle backgroundOpacity] 0.8 alpha). The optional start
 * icon and the title share the [foregroundColor] (`backgroundPrimary` token).
 */
@Immutable
data class IDnowMessageStyle(
    /** Color of the start icon tint and the title text (XML: `Tokens.backgroundPrimary`). */
    val foregroundColor: Color,
    /** Container background: `backgroundDarker` token at 0.8 alpha (XML: `backgroundOpacity`). */
    val backgroundColor: Color,
    /** Container corner radius (XML: `Tokens.radiusMd`). */
    val cornerRadius: Dp,
    /** Inner padding around the content (XML: the icon/title `SPACING_MD` margins). */
    val contentPadding: Dp,
    /** Gap between the start icon and the title (XML: title `SPACING_MD` start margin). */
    val iconTitleGap: Dp,
)

/** Default resolver for [IDnowMessageStyle], analogous to Material3's `XxxDefaults`. */
object IDnowMessageDefaults {

    /** Background alpha applied to the `backgroundDarker` token, matching `MessageViewStyle.backgroundOpacity`. */
    private const val BACKGROUND_OPACITY = 0.8f

    @Composable
    fun style(): IDnowMessageStyle = IDnowMessageStyle(
        foregroundColor = BackgroundColorEnum.PRIMARY.composeColor,
        backgroundColor = BackgroundColorEnum.DARKER.composeColor.copy(alpha = BACKGROUND_OPACITY),
        // No enum exists for the radius token, so read it straight from Tokens here (allowed only
        // in the Defaults resolver) and wrap the dp-magnitude int as `Int.dp`.
        cornerRadius = Tokens.radiusMd.dp,
        contentPadding = SpacingEnum.SPACING_MD.spacingDp,
        iconTitleGap = SpacingEnum.SPACING_MD.spacingDp,
    )
}
