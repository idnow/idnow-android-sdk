package io.idnow.designsystem.compose_components.buttons

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.styles.compose.IDnowButtonDefaults
import io.idnow.designsystem.styles.compose.IDnowButtonStyle
import io.idnow.designsystem.styles.compose.IDnowResolvedButtonStyle
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.unit.Dp

/** Where the optional [IDnowButton] icon is laid out relative to the text. */
enum class IDnowButtonIconPosition { START, END }

/**
 * Tokenized button, the Compose counterpart of the XML `IDnowButton`.
 *
 * The [style] (variant + size) is a **public** parameter — the product owner wants callers to pass
 * "the style to apply". All visuals (background + stroke, pressed blend, text color, corner radius =
 * radiusFull, content paddings, typography, icon size + padding, disabled opacity = 0.5)
 * * are resolved from the tokens via [IDnowButtonDefaults.resolved], matching the
 * XML `ButtonStyle`.
 *
 * Built from foundation primitives only (no Material3): a [Box]/[Row] + [Modifier.clickable].
 * Spacing around the button is applied by the caller through [modifier].
 *
 * @param loading when true, the label/icon are hidden and a small circular spinner is shown in place,
 *   reproducing the XML loading state.
 */
@Composable
fun IDnowButton(
    text: String,
    onClick: () -> Unit,
    style: IDnowButtonStyle,
    modifier: Modifier = Modifier,
    icon: Painter? = null,
    iconPosition: IDnowButtonIconPosition = IDnowButtonIconPosition.START,
    enabled: Boolean = true,
    loading: Boolean = false,
) {
    val resolved = IDnowButtonDefaults.resolved(style)
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val backgroundColor = if (pressed) resolved.pressedBackgroundColor else resolved.backgroundColor
    val strokeColor = if (pressed) resolved.pressedStrokeColor else resolved.strokeColor
    val shape = RoundedCornerShape(resolved.cornerRadius)

    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else resolved.disabledOpacity)
            .clip(shape)
            .background(color = backgroundColor, shape = shape)
            .border(BorderStroke(resolved.strokeWidth, strokeColor), shape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled && !loading,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(
                start = resolved.paddingStart,
                top = resolved.paddingTop,
                end = resolved.paddingEnd,
                bottom = resolved.paddingBottom,
            ),
        contentAlignment = Alignment.Center,
    ) {
        // Keep the laid-out content but make it invisible while loading (like the XML INVISIBLE state),
        // so the button keeps its intrinsic size and the spinner overlays it.
        ButtonContent(
            text = text,
            icon = icon,
            iconPosition = iconPosition,
            resolved = resolved,
            modifier = Modifier.graphicsLayer { alpha = if (loading) 0f else 1f },
        )
        if (loading) {
            CircularSpinner(
                color = resolved.textColor,
                size = resolved.iconSize,
                strokeWidth = 2.dp,
            )
        }
    }
}

@Composable
private fun ButtonContent(
    text: String,
    icon: Painter?,
    iconPosition: IDnowButtonIconPosition,
    resolved: IDnowResolvedButtonStyle,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null && iconPosition == IDnowButtonIconPosition.START) {
            ButtonIcon(icon, resolved)
            if (text.isNotEmpty()) Spacer(Modifier.size(resolved.iconPadding))
        }
        if (text.isNotEmpty()) {
            // Render with the resolved TextStyle directly: it already carries the correct button text
            // color (luminance token for primary/danger, secondaryActiveText for secondary),
            // which has no TextColorEnum equivalent, so we bypass IDnowText's token enums here.
            BasicText(text = text, style = resolved.textStyle)
        }
        if (icon != null && iconPosition == IDnowButtonIconPosition.END) {
            if (text.isNotEmpty()) Spacer(Modifier.size(resolved.iconPadding))
            ButtonIcon(icon, resolved)
        }
    }
}

@Composable
private fun ButtonIcon(icon: Painter, resolved: IDnowResolvedButtonStyle) {
    Image(
        painter = icon,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(resolved.iconSize),
        colorFilter = ColorFilter.tint(resolved.textColor),
    )
}

/** A simple foundation-only indeterminate circular spinner (no Material). */
@Composable
private fun CircularSpinner(
    color: Color,
    size: Dp,
    strokeWidth: Dp,
) {
    val transition = rememberInfiniteTransition(label = "buttonSpinner")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "buttonSpinnerAngle",
    )
    Canvas(modifier = Modifier.size(size).alpha(0.5f)) {
        val stroke = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
        val inset = stroke.width / 2f
        drawArc(
            color = color,
            startAngle = angle,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = Size(this.size.width - stroke.width, this.size.height - stroke.width),
            style = stroke,
        )
    }
}
