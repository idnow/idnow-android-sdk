package io.idnow.designsystem.compose_components.form_input.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle
import io.idnow.designsystem.styles.compose.IDnowInputContainerState

/**
 * The shared bordered row of a text-entry field — Compose mirror of the XML `IDnowContainer` contents:
 * `[leading?] [field + hint placeholder] [trailing?]`, all inside the state border with inner padding.
 * Used as the `decorationBox` of the `BasicTextField` in `IDnowTextField`, `IDnowPhoneTextField` and
 * `IDnowAutoComplete`. The [trailing] slot holds the variant's clear / password / chevron icons.
 */
@Composable
internal fun InputDecorationBox(
    style: IDnowFormInputStyle,
    containerState: IDnowInputContainerState,
    value: String,
    hint: String?,
    innerTextField: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .idnowInputContainer(containerState, style)
            .padding(style.innerPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(style.innerPadding))
        }
        InputFieldWithHint(style, value, hint) { innerTextField() }
        if (trailing != null) {
            Spacer(Modifier.width(style.innerPadding))
            trailing()
        }
    }
}

/**
 * The field cell: a weighted box overlaying the [field] with a hint placeholder shown while [value] is
 * empty. Shared by [InputDecorationBox] and `IDnowPhoneTextField` (which lays the flag selector and the
 * field out as siblings, so it can't use the full [InputDecorationBox]).
 */
@Composable
internal fun RowScope.InputFieldWithHint(
    style: IDnowFormInputStyle,
    value: String,
    hint: String?,
    field: @Composable () -> Unit,
) {
    Box(Modifier.weight(1f)) {
        if (value.isEmpty() && !hint.isNullOrEmpty()) {
            BasicText(
                text = hint,
                style = style.fieldTextStyle.copy(color = style.hintColor),
                maxLines = 1,
                modifier = Modifier.clearAndSetSemantics { },
            )
        }
        field()
    }
}

/**
 * Set `contentDescription` only when [description] is non-empty. An empty contentDescription on an
 * editable field would suppress its native editable semantics and make TalkBack skip it, so for a
 * field with no label/hint/error we leave the natural semantics in place.
 */
fun Modifier.inputContentDescription(description: String): Modifier =
    if (description.isNotEmpty()) this.semantics { contentDescription = description } else this

/** Decorative (non-interactive) input icon. */
@Composable
internal fun DecorIcon(painter: Painter, tint: Color, size: Dp) {
    Image(
        painter = painter,
        contentDescription = null,
        colorFilter = ColorFilter.tint(tint),
        modifier = Modifier.size(size),
    )
}

/** Interactive input icon with its own a11y node and no ripple (clear button, etc.). */
@Composable
internal fun ClickableInputIcon(
    painter: Painter,
    tint: Color,
    size: Dp,
    contentDescription: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Image(
        painter = painter,
        contentDescription = contentDescription,
        colorFilter = ColorFilter.tint(tint),
        modifier = Modifier
            .size(size)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            ),
    )
}
