package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.styles.xml.HeaderStyle

/**
 * Fully-resolved visual values for `IDnowFooter` ("powered by IDnow" logo). Compose mirror of the
 * XML [HeaderStyle] (`iconColor` = [TintColorEnum.MAIN], `poweredByOpacity`) + the `spacingXs` bottom margin.
 */
@Immutable
data class IDnowFooterStyle(
    /** Tint applied to the logo. */
    val logoColor: Color,
    /** Opacity applied to the logo. */
    val logoOpacity: Float,
    /** Bottom padding under the logo. */
    val bottomPadding: Dp,
)

/** Default resolver for [IDnowFooterStyle]. */
object IDnowFooterDefaults {

    @Composable
    fun style(): IDnowFooterStyle = IDnowFooterStyle(
        logoColor = TintColorEnum.MAIN.composeColor,
        logoOpacity = HeaderStyle.poweredByOpacity,
        bottomPadding = SpacingEnum.SPACING_XS.dp,
    )
}
