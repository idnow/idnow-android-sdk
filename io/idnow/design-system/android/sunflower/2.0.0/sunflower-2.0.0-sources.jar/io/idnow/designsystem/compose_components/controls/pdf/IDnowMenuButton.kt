package io.idnow.designsystem.compose_components.controls.pdf

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.isSpecified
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.text_view.IDnowText
import io.idnow.designsystem.styles.compose.IDnowMenuButtonDefaults

/**
 *
 * A clickable row with an optional start icon and a bold-small label, used to switch between PDF
 * documents. It has two visual modes via [lightUi] and an [active] state, mirroring the XML view:
 * - **`lightUi = false`, the default**: tertiary background, secondary when active, plus a
 *   top stroke (`Tokens.active`) when active or pressed.
 * - **`lightUi = true`**: transparent background, secondary while pressed, plus a bottom
 *   stroke (`primaryBackground`) when active or pressed.
 *
 * Only the top corners are rounded (`Tokens.radiusSm`). Visuals are resolved internally from
 * [IDnowMenuButtonDefaults]; spacing is applied by the caller via [modifier].
 *
 * @param text the label.
 * @param active whether this tab is the selected one.
 * @param onClick invoked when the button is tapped.
 * @param modifier caller-applied spacing/layout (the XML margins live here).
 * @param lightUi switches between the dark (default) and light visual modes.
 * @param startIcon optional leading icon resource; defaults to `sunflower_ic_document`. Pass `null` to hide it.
 */
@Composable
fun IDnowMenuButton(
    text: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    lightUi: Boolean = false,
    @DrawableRes startIcon: Int? = R.drawable.sunflower_ic_document,
) {
    val style = IDnowMenuButtonDefaults.style(lightUi = lightUi, active = active)
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // The stroke layer is transparent unless the button is activated OR pressed.
    val showStroke = active || isPressed
    val shape = RoundedCornerShape(topStart = style.cornerRadius, topEnd = style.cornerRadius)
    val backgroundColor = if (isPressed) style.pressedBackgroundColor else style.backgroundColor

    Row(
        modifier = modifier
            .defaultMinSize(minHeight = style.minHeight)
            // Merge the label into this node so TalkBack announces "<label>, Tab" instead of an empty tab.
            .semantics(mergeDescendants = true) {}
            .clip(shape)
            .background(color = backgroundColor, shape = shape)
            .drawBehind {
                if (!showStroke) return@drawBehind
                // `lightUi = false`: rounded-top filled bar flush with the top edge (MenuButtonTopStrokeDrawable).
                if (style.topStrokeColor.isSpecified) {
                    val h = style.topStrokeHeight.toPx()
                    val r = style.cornerRadius.toPx()
                    val path = Path().apply {
                        addRoundRect(
                            RoundRect(
                                rect = Rect(Offset.Zero, Size(size.width, h)),
                                topLeft = CornerRadius(r, r),
                                topRight = CornerRadius(r, r),
                                bottomLeft = CornerRadius.Zero,
                                bottomRight = CornerRadius.Zero,
                            ),
                        )
                    }
                    drawPath(path, style.topStrokeColor)
                }
                // `lightUi = true`: thin line flush with the bottom edge (MenuButtonBottomStrokeDrawable).
                if (style.bottomStrokeColor.isSpecified) {
                    val w = style.bottomStrokeWidth.toPx()
                    drawRect(
                        color = style.bottomStrokeColor,
                        topLeft = Offset(0f, size.height - w),
                        size = Size(size.width, w),
                    )
                }
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Tab,
                onClick = onClick,
            )
            .padding(style.contentPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (startIcon != null) {
            Image(
                painter = painterResource(startIcon),
                contentDescription = null,
                colorFilter = ColorFilter.tint(style.iconTint),
                modifier = Modifier
                    .padding(end = style.iconEndSpacing)
                    .size(style.iconSize),
            )
        }

        IDnowText(
            text = text,
            typography = style.textTypography,
            textColor = style.contentTextColor,
        )
    }
}
