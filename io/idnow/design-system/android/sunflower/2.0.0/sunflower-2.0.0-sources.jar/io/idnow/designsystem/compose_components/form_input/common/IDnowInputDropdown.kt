package io.idnow.designsystem.compose_components.form_input.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle

/**
 * Shared anchored dropdown for the spinner, autocomplete and phone country list — a foundation
 * [Popup] (no Material3) sized to the anchor's width, that opens below the anchor and **flips above**
 * when there isn't enough room below (mirrors the XML `IDnowCountrySearchPopup`/spinner positioning).
 * `focusable = true` so an outside tap dismisses it and an optional [header] search field can type.
 *
 * @param anchorWidthPx the container width captured via `Modifier.onSizeChanged` on the anchor.
 * @param header optional content above the list (e.g. the country search field).
 */
@Composable
internal fun IDnowInputDropdown(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    anchorWidthPx: Int,
    style: IDnowFormInputStyle,
    modifier: Modifier = Modifier,
    focusable: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    occludedBottomPx: Int = 0,
    maxHeight: Dp = 280.dp,
    header: (@Composable () -> Unit)? = null,
    content: LazyListScope.() -> Unit,
) {
    if (!expanded) return
    val anchorWidth = with(LocalDensity.current) { anchorWidthPx.toDp() }
    val shape = RoundedCornerShape(style.cornerRadius)
    Popup(
        popupPositionProvider = remember(occludedBottomPx) { DropdownPositionProvider(occludedBottomPx) },
        onDismissRequest = onDismissRequest,
        // focusable=false for autocomplete so the text field keeps focus + keyboard while suggestions show;
        // focusable=true for spinner / phone search so outside taps dismiss and the search field can type.
        // dismissOnClickOutside must be false when non-focusable: otherwise FLAG_WATCH_OUTSIDE_TOUCH turns
        // each soft-keyboard keypress into an ACTION_OUTSIDE → onDismissRequest, which would close the
        // keyboard + dropdown and swallow the keystroke.
        properties = PopupProperties(focusable = focusable, dismissOnClickOutside = dismissOnClickOutside),
    ) {
        Column(
            modifier = modifier
                .width(anchorWidth)
                .clip(shape)
                .background(style.popupBackground, shape)
                .border(style.popupStrokeWidth, style.popupStrokeColor, shape),
        ) {
            header?.invoke()
            LazyColumn(modifier = Modifier.heightIn(max = maxHeight), content = content)
        }
    }
}

/**
 * Places the popup left-aligned under the anchor; flips above when the space below — minus any area
 * occluded by the soft keyboard ([occludedBottomPx]) — is insufficient.
 */
private class DropdownPositionProvider(private val occludedBottomPx: Int) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        val x = anchorBounds.left
        val below = anchorBounds.bottom
        val usableBottom = windowSize.height - occludedBottomPx
        val fitsBelow = below + popupContentSize.height <= usableBottom
        val above = anchorBounds.top - popupContentSize.height
        val y = if (fitsBelow || above < 0) below else above
        return IntOffset(x, y)
    }
}
