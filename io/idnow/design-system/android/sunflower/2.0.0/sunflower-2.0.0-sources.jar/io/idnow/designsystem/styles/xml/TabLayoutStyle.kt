package io.idnow.designsystem.styles.xml

import android.content.Context
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography

internal object TabLayoutStyle {
    /**
     * Selected tab color
     */
    val selectedTabColor get() = Tokens.backgroundPrimary
    /**
     * Background color
     */
    val backgroundColor get() = Tokens.backgroundSecondary
    /**
     * Selected tab text color
     */
    val selectedTabTextColor get() = Tokens.secondaryActiveText
    /**
     * Default tab text color
     */
    val defaultTabTextColor get() = Tokens.body
    /**
     * Item margin
     */
    val itemMargin = 8
    /**
     * Tab corner radius
     */
    val cornerRadius get() = Tokens.radiusFull
    /**
     * Tab text typography
     */
    fun font(context: Context) = Typography.H6(context)
}