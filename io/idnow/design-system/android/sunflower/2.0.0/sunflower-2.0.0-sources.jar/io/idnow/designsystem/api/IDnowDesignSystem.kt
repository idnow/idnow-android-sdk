package io.idnow.designsystem.api

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.idnow.designsystem.customization.IDnowPrimitives

/**
 * Static object used to store and retrieve the primitives set for the design system.
 * Only the init is visible for integrator.
 */
object IDnowDesignSystem {
    /**
     * Used by the tokens to adapt the colors for the wanted ui mode.
     */
    internal var isLightMode = true

    /**
     * Used by the tokens to associate a functional colors to a primitive ones.
     *
     * Backed by snapshot state so that any composition reading it (directly, or transitively through
     * the token extensions / [LocalPrimitives] / [Theme]) is invalidated and recomposes when [setup]
     * writes a new value. This works across every `ComposeView` in the app because they all subscribe
     * to the same global snapshot state — no top-level `setContent` required.
     */
    internal var primitives: IDnowPrimitives by mutableStateOf(IDnowPrimitives().applyFontUpdate())
        private set

    /**
     * Update the primitives with the given ones.
     * @param primitives the custom primitives
     * @param isLightMode choose between light and dark mode.
     */
    fun setup(primitives: IDnowPrimitives, isLightMode: Boolean = true) {
        this.isLightMode = isLightMode
        this.primitives = primitives.applyFontUpdate()
    }

    /** CompositionLocal exposing the current primitives; defaults to the global snapshot value. */
    internal val LocalPrimitives = compositionLocalOf { primitives }

    /** Provides the current primitives to [content] via [LocalPrimitives]. */
    @Composable
    fun Theme(content: @Composable () -> Unit) {
        CompositionLocalProvider(LocalPrimitives provides primitives, content = content)
    }
}
