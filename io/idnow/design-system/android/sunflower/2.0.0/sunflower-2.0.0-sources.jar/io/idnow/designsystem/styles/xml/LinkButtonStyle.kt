package io.idnow.designsystem.styles.xml

import androidx.annotation.Dimension
import io.idnow.designsystem.tokens.Tokens

internal object LinkButtonStyle {
    /**
     * Item margin
     */
    val itemMargin get() = Tokens.spacingMd

    /**
     * End icon color
     **/
    val endIconColor get() = Tokens.secondaryActiveText

    /**
     * Opacity of the pressed background.
     */
    const val pressedBackgroundOpacity = 0.07f

    /**
     * Opacity of the pressed background.
     */
    val pressedBackgroundColor get() = Tokens.secondaryActiveText

    /**
     * Corner radius of the button.
     */
    val cornerRadius get() = Tokens.radiusMd

    /**
     * Container stroke width
     */
    @Dimension(unit = Dimension.DP)
    val strokeWidth = 2

    /**
     * Container stroke color
     */
    val strokeColor get() = Tokens.secondaryActiveStroke
}