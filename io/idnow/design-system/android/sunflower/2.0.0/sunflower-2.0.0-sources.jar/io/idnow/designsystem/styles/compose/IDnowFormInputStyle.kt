package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.tokens.Tokens

/** Visual state of the input container — mirrors the four XML `ContainerStyle` objects. */
enum class IDnowInputContainerState { Empty, Filling, Error, Disabled }

/**
 * Fully-resolved visual values shared by every Compose form input (`IDnowTextField`, `IDnowSpinner`,
 * `IDnowPhoneTextField`, `IDnowAutoComplete`). Compose mirror of the XML
 * [io.idnow.designsystem.styles.xml.FormInputsStyle] + [io.idnow.designsystem.styles.xml.ContainerStyle]:
 * the frame (label/error/helper) and the bordered container are identical across variants, so one
 * resolved style feeds them all. Resolved in [IDnowFormInputDefaults.style].
 */
@Immutable
data class IDnowFormInputStyle(
    // Texts
    val labelTextStyle: TextStyle,
    val errorTextStyle: TextStyle,
    val helperTextStyle: TextStyle,
    val fieldTextStyle: TextStyle,
    val itemTextStyle: TextStyle,
    val hintColor: Color,
    val cursorColor: Color,
    // Container border per state
    val emptyStrokeColor: Color,
    val fillingStrokeColor: Color,
    val errorStrokeColor: Color,
    val disabledStrokeColor: Color,
    val thinStrokeWidth: Dp,
    val thickStrokeWidth: Dp,
    val fillBackground: Color,
    val disabledBackground: Color,
    // Icon tints
    val leadingIconTint: Color,
    val clearIconTint: Color,
    val trailingIconTint: Color,
    val errorIconTint: Color,
    val popupCheckTint: Color,
    // Popup chrome
    val popupBackground: Color,
    val popupStrokeColor: Color,
    val popupStrokeWidth: Dp,
    // Metrics
    val cornerRadius: Dp,
    val itemSpacing: Dp,
    val innerPadding: Dp,
    /** Horizontal padding + icon/text gap inside a dropdown item row (XML item margins = SPACING_MD). */
    val itemContentPadding: Dp,
    val flagGroupSpacing: Dp,
    val leadingIconSize: Dp,
    val clearIconSize: Dp,
    val trailingIconSize: Dp,
    val errorIconSize: Dp,
    val itemIconSize: Dp,
) {
    /** Stroke color for a given container state. */
    fun strokeColorFor(state: IDnowInputContainerState): Color = when (state) {
        IDnowInputContainerState.Empty -> emptyStrokeColor
        IDnowInputContainerState.Filling -> fillingStrokeColor
        IDnowInputContainerState.Error -> errorStrokeColor
        IDnowInputContainerState.Disabled -> disabledStrokeColor
    }

    /** Stroke width: 2dp for focused/error (active), 1dp otherwise — like the XML ContainerStyle. */
    fun strokeWidthFor(state: IDnowInputContainerState): Dp =
        if (state == IDnowInputContainerState.Filling || state == IDnowInputContainerState.Error) thickStrokeWidth else thinStrokeWidth

    /** Container background: secondary when disabled, primary otherwise. */
    fun backgroundFor(state: IDnowInputContainerState): Color =
        if (state == IDnowInputContainerState.Disabled) disabledBackground else fillBackground
}

/** Default resolver for [IDnowFormInputStyle], analogous to Material3's `XxxDefaults`. */
object IDnowFormInputDefaults {

    /** XML ContainerStyle.hintOpacity. */
    private const val HINT_OPACITY = 0.35f

    @Composable
    fun style(): IDnowFormInputStyle {
        val bodyColor = TextColorEnum.BODY.composeColor
        return IDnowFormInputStyle(
            labelTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(bodyColor),
            errorTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(TintColorEnum.ERROR.composeColor),
            helperTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(TintColorEnum.MAIN.composeColor),
            fieldTextStyle = TypographyEnum.BODY_LARGE.asTextStyle(TextColorEnum.INPUT_TEXT.composeColor),
            itemTextStyle = TypographyEnum.BODY.asTextStyle(bodyColor),
            hintColor = Color(Utils.adjustAlpha(Tokens.inputText, HINT_OPACITY)),
            cursorColor = TintColorEnum.ACTIVE.composeColor,
            emptyStrokeColor = Color(Tokens.borderSecondary),
            fillingStrokeColor = TintColorEnum.ACTIVE.composeColor,
            errorStrokeColor = TintColorEnum.ERROR.composeColor,
            disabledStrokeColor = BackgroundColorEnum.SECONDARY.composeColor,
            thinStrokeWidth = 1.dp,
            thickStrokeWidth = 2.dp,
            fillBackground = BackgroundColorEnum.PRIMARY.composeColor,
            disabledBackground = BackgroundColorEnum.SECONDARY.composeColor,
            leadingIconTint = TintColorEnum.MAIN.composeColor,
            clearIconTint = TintColorEnum.MAIN.composeColor,
            trailingIconTint = Color(Tokens.primaryBackground),
            errorIconTint = TintColorEnum.ERROR.composeColor,
            popupCheckTint = Color(Tokens.borderTertiary),
            popupBackground = BackgroundColorEnum.SECONDARY.composeColor,
            popupStrokeColor = BackgroundColorEnum.SECONDARY.composeColor,
            popupStrokeWidth = 1.dp,
            cornerRadius = Tokens.radiusMd.dp,
            itemSpacing = SpacingEnum.SPACING_SM.dp,
            innerPadding = SpacingEnum.SPACING_SM.dp,
            itemContentPadding = SpacingEnum.SPACING_MD.dp,
            flagGroupSpacing = SpacingEnum.SPACING_XS.dp,
            leadingIconSize = dimensionResource(R.dimen.idnow_icon_size),
            clearIconSize = dimensionResource(R.dimen.idnow_small_icon_size),
            trailingIconSize = dimensionResource(R.dimen.idnow_icon_size),
            errorIconSize = dimensionResource(R.dimen.idnow_text_icon_size),
            itemIconSize = dimensionResource(R.dimen.idnow_item_size),
        )
    }
}
