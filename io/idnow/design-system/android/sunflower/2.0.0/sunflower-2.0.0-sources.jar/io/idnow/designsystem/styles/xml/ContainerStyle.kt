package io.idnow.designsystem.styles.xml

import android.content.Context
import androidx.annotation.Dimension
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography

internal sealed class ContainerStyle {
    /**
     * Container stroke color
     */
    open val strokeColor get() = Tokens.borderSecondary

    /**
     * Container stroke width
     */
    @Dimension(unit = Dimension.DP)
    open val strokeWidth = 1

    /**
     * Container background color
     */
    open val backgroundColor get() = Tokens.backgroundPrimary

    data object Empty: ContainerStyle()

    data object Filling: ContainerStyle() {
        override val strokeColor: Int get() = Tokens.active
        override val strokeWidth: Int = 2
    }

    data object Disabled: ContainerStyle() {
        override val strokeColor: Int get() = Tokens.backgroundSecondary
        override val backgroundColor: Int get() = Tokens.backgroundSecondary
    }

    data object Error: ContainerStyle() {
        override val strokeColor: Int get() = Tokens.error
        override val strokeWidth: Int = 2
    }

    companion object {
        /** Container typography */
        fun font(context: Context) = Typography.BodyLarge(context)

        /**
         * For hint add an opacity to the text color
         */
        const val hintOpacity: Float = 0.35f

        /**
         * Container text color
         */
        val textColor get() = Tokens.inputText

        /**
         * Container radius
         */
        val cornerRadius get() = Tokens.radiusMd
    }
}