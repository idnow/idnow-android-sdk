package io.idnow.designsystem.xml_components.form_input_texts.common

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.xml.ContainerStyle
import io.idnow.designsystem.xml_components.extension.StateEntryBuilder
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.stateListDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp


class IDnowContainer : ConstraintLayout {
    /** The custom error state reference */
    private val stateError = intArrayOf(R.attr.state_error)

    /** Custom state to show an error background */
    var isError: Boolean = false
        set(value) {
            field = value
            refreshDrawableState()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowContainer) {
            isEnabled = getBoolean(R.styleable.IDnowContainer_android_enabled, true)
            isError = getBoolean(R.styleable.IDnowContainer_state_error, false)
        }
        initialize()
    }

    private fun initialize() {
        /** To trigger focused state, we must be focusable */
        isFocusable = true
        isFocusableInTouchMode = true

        /** First setup the background */
        setupBackground()
    }

    private fun setupBackground() {
        fun StateEntryBuilder.background(style: ContainerStyle, fill: Boolean = false) = gradient {
            if (fill) color(style.backgroundColor)
            stroke(style.strokeColor, style.strokeWidth.toDp(context))
            cornerRadius(ContainerStyle.cornerRadius.toDp(context).toFloat())
        }

        background = stateListDrawable {
            state(states = intArrayOf(-android.R.attr.state_enabled)) {
                background(
                    ContainerStyle.Disabled,
                    fill = true
                )
            }
            state(states = intArrayOf(android.R.attr.state_focused)) { background(ContainerStyle.Filling) }
            state(states = intArrayOf(R.attr.state_error)) { background(ContainerStyle.Error) }
            state { background(ContainerStyle.Empty) }
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        /**
         * To be focused at the same time than the edittext, we need to inherit from children state.
         * BUT, to be able to enter the disable state we need to stop listening at child state.
         * Once done also disable the edittext.
         */
        setAddStatesFromChildren(enabled)
    }

    /** Override to apply the error state when the error boolean is triggered */
    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        val drawableState = super.onCreateDrawableState(extraSpace + 1)
        return if (isError) mergeDrawableStates(drawableState, stateError) else drawableState
    }
}