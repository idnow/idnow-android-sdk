package io.idnow.designsystem.xml_components.form_input_texts.spinner

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.ArrayAdapter
import androidx.core.view.isVisible
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.databinding.IdnowContainerItemBinding
import io.idnow.designsystem.styles.xml.ContainerStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItem
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItemData
import io.idnow.designsystem.xml_components.form_input_texts.common.updateItem

open class IDnowAdapter(private val context: Context, private val itemList: List<IDnowItemData>, private val hint: IDnowItemData? = null) :
    ArrayAdapter<IDnowItemData>(context, 0, if (hint == null) itemList else itemList + hint) {

    var selection: Int = if (hint == null) 0 else itemList.size

    override fun getItem(position: Int): IDnowItemData? = if (hint != null && position == itemList.size) null else itemList[position]

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding: IdnowContainerItemBinding
        var row = convertView
        if (row == null) {
            val layoutInflater = LayoutInflater.from(context)
            binding = IdnowContainerItemBinding.inflate(layoutInflater, parent, false)
            row = binding.root
        } else {
            binding = IdnowContainerItemBinding.bind(row)
        }

        if (position == itemList.size && hint != null) updateHint(hint, binding)
        else binding.updateItem(itemList[position], smallText = false, position == selection)

        return row
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding: IdnowContainerItemBinding
        var row = convertView

        if (hint != null && position == itemList.size) return View(context).apply { layoutParams = AbsListView.LayoutParams(0, 1) }

        if (row == null) {
            val layoutInflater = LayoutInflater.from(context)
            binding = IdnowContainerItemBinding.inflate(layoutInflater, parent, false)
            row = binding.root
        } else {
            binding = IdnowContainerItemBinding.bind(row)
        }
        binding.updateItem(itemList[position], smallText = true, position == selection)
        return row
    }

    /**
     * Update item content with the given item hint.
     * @param item the item to use to draw the cell
     * @param binding the view to update
     */
    private fun updateHint(item: IDnowItemData, binding: IdnowContainerItemBinding) {
        item.content?.let {
            binding.idnowItemText.apply {
                layoutParams.applyMargin(context = context, start = Tokens.spacingMd, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
                setText(it)
                setTypography(ContainerStyle.font(context))
                setTextColor(Utils.adjustAlpha(ContainerStyle.textColor, ContainerStyle.hintOpacity))
                isVisible = true
            }
        }
    }

    /**
     * Find the position if the given item
     * @param iDnowItem the item to found
     * return the position of the item or -1 if not found.
     */
    fun findPositionForItem(iDnowItem: IDnowItem): Int {
        return itemList.indexOf(iDnowItem)
    }
}