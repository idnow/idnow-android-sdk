package io.idnow.designsystem.compose_components.form_input

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputDropdown
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputFrame
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputItemRow
import io.idnow.designsystem.compose_components.form_input.common.InputFieldWithHint
import io.idnow.designsystem.compose_components.form_input.common.idnowInputContainer
import io.idnow.designsystem.compose_components.form_input.common.inputContentDescription
import io.idnow.designsystem.compose_components.form_input.common.rememberInputAccessibilityText
import io.idnow.designsystem.compose_components.form_input.common.resolveContainerState
import io.idnow.designsystem.styles.compose.IDnowFormInputDefaults
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowCountryFlagItem

/**
 * Compose counterpart of the XML `IDnowPhoneTextField`. A phone-number field with a leading country
 * selector (flag + chevron + dial prefix) opening a (optionally [searchable]) country dropdown.
 *
 * The dial prefix is only displayed — it is NOT prepended to [value] (the consumer owns formatting,
 * exactly like the XML). Country list + selection are hoisted by the caller.
 */
@Composable
fun IDnowPhoneTextField(
    value: String,
    onValueChange: (String) -> Unit,
    countries: List<IDnowCountryFlagItem>,
    selectedCountry: IDnowCountryFlagItem?,
    onCountrySelected: (IDnowCountryFlagItem) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    hint: String? = null,
    helperText: String? = null,
    errorText: String? = null,
    isError: Boolean = false,
    enabled: Boolean = true,
    searchable: Boolean = false,
) {
    val style = IDnowFormInputDefaults.style()
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    var expanded by remember { mutableStateOf(false) }
    var anchorWidthPx by remember { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    val containerState = resolveContainerState(focused = focused || expanded, isError = isError, enabled = enabled)
    val accessibilityText = rememberInputAccessibilityText(label, hint, errorText, isError, helperText)

    val filteredCountries = remember(query, countries) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) countries else countries.filter {
            it.content.lowercase().contains(q) || it.prefix.lowercase().contains(q)
        }
    }

    IDnowInputFrame(style, label, errorText, isError, helperText, modifier) {
        Box {
            // Flag selector and the number field are SIBLINGS in the container row (not flag-in-decoration)
            // so TalkBack focuses the country selector first, then the text field.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .onSizeChanged { anchorWidthPx = it.width }
                    .idnowInputContainer(containerState, style)
                    .padding(style.innerPadding),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FlagArea(
                    style = style,
                    country = selectedCountry,
                    expanded = expanded,
                    enabled = enabled,
                    onClick = { expanded = !expanded },
                )
                Spacer(Modifier.width(style.innerPadding))
                InputFieldWithHint(style, value, hint) {
                    BasicTextField(
                        value = value,
                        onValueChange = onValueChange,
                        enabled = enabled,
                        singleLine = true,
                        textStyle = style.fieldTextStyle,
                        cursorBrush = SolidColor(style.cursorColor),
                        interactionSource = interactionSource,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .inputContentDescription(accessibilityText),
                    )
                }
            }
            IDnowInputDropdown(
                expanded = expanded,
                onDismissRequest = { expanded = false; query = "" },
                anchorWidthPx = anchorWidthPx,
                style = style,
                focusable = true,
                header = if (searchable) {
                    { CountrySearchField(query = query, onQueryChange = { query = it }) }
                } else {
                    null
                },
            ) {
                items(filteredCountries) { country ->
                    IDnowInputItemRow(
                        item = country,
                        style = style,
                        selected = country == selectedCountry,
                        showCheck = true,
                        contentDescription = "${country.content}, ${country.prefix}",
                        clickLabel = stringResource(R.string.sunflower_action_select),
                        onClick = {
                            onCountrySelected(country)
                            expanded = false
                            query = ""
                        },
                    )
                }
            }
        }
    }
}

/** Leading country selector: flag + chevron + dial prefix, announced as a dropdown (XML Spinner role). */
@Composable
private fun FlagArea(
    style: IDnowFormInputStyle,
    country: IDnowCountryFlagItem?,
    expanded: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val flagDescription = stringResource(R.string.sunflower_flag_content_description)
    val interactionSource = remember { MutableInteractionSource() }
    val focusRequester = remember { FocusRequester() }
    Row(
        modifier = Modifier
            .focusRequester(focusRequester)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.DropdownList,
                // Take focus on click so the phone number field's keyboard and any other open
                // dropdown dismiss, and Back returns focus to the flag selector. Guard requestFocus:
                // it throws if the node is momentarily detached (e.g. rapid re-tap during dismissal).
                onClick = { runCatching { focusRequester.requestFocus() }; onClick() },
            )
            .clearAndSetSemantics {
                contentDescription = flagDescription
                if (country != null) stateDescription = "${country.content}, ${country.prefix}"
            },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        country?.icon?.let { flag ->
            Image(
                painter = painterResource(flag),
                contentDescription = null,
                modifier = Modifier.size(style.leadingIconSize),
            )
            Spacer(Modifier.width(style.flagGroupSpacing))
        }
        Image(
            painter = painterResource(
                if (expanded) R.drawable.sunflower_ic_chevron_up else R.drawable.sunflower_ic_chevron_down,
            ),
            contentDescription = null,
            colorFilter = ColorFilter.tint(style.trailingIconTint),
            // Flag-area chevron is the small icon size (XML idnow_small_icon_size), not the 24dp trailing size.
            modifier = Modifier.size(style.clearIconSize),
        )
        country?.prefix?.let { prefix ->
            Spacer(Modifier.width(style.flagGroupSpacing))
            BasicText(text = prefix, style = style.fieldTextStyle)
        }
    }
}

/** The search field shown at the top of the country dropdown when `searchable`. */
@Composable
private fun CountrySearchField(query: String, onQueryChange: (String) -> Unit) {
    IDnowTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier.padding(8.dp),
        leadingIcon = painterResource(R.drawable.sunflower_ic_magnifying_glass),
    )
}
