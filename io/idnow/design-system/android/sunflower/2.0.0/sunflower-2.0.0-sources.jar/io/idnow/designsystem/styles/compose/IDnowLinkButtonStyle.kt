package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values for [io.idnow.designsystem.compose_components.navigation.IDnowLinkButton].
 *
 * Compose mirror of the XML [io.idnow.designsystem.styles.xml.LinkButtonStyle] (+ the
 * `idnow_link_button_background` drawable and `idnow_item_size` dimen): a rounded, bordered
 * link-style button with a start icon (tinted `MAIN`), a link-colored label and an end icon
 * (tinted from `secondaryActiveText`). All values resolve from tokens in
 * [IDnowLinkButtonDefaults.style] so the two worlds stay in sync.
 */
@Immutable
data class IDnowLinkButtonStyle(
    /** Label typography (XML: `BODY_BOLD_SMALL`). */
    val textTypography: TypographyEnum,
    /** Label color (XML: `LINK`). */
    val textColor: TextColorEnum,
    /** Start-icon tint (XML: `token_tintColor="MAIN"` on the start image, alpha 0.9). */
    val startIconColor: Color,
    /** Start-icon alpha (XML: `android:alpha="0.9"`). */
    val startIconAlpha: Float,
    /** End-icon tint (XML: `Tokens.secondaryActiveText`). */
    val endIconColor: Color,
    /** Square icon size (XML dimen `idnow_item_size`). */
    val iconSize: Dp,
    /** Stroke / border color (XML: `Tokens.secondaryActiveStroke`). */
    val strokeColor: Color,
    /** Stroke / border width (XML: 2dp). */
    val strokeWidth: Dp,
    /** Corner radius (XML: `Tokens.radiusMd`). */
    val cornerRadius: Dp,
    /** Solid fill shown while pressed (XML: `secondaryActiveText` @ 0.07 alpha). */
    val pressedBackgroundColor: Color,
    /** Margin around the icons (XML: `Tokens.spacingMd`). */
    val itemMargin: Dp,
    /** Gap between the start icon and the label (XML text `SPACING_SM` start margin). */
    val textStartSpacing: Dp,
    /** Gap between the label and the end icon (XML text `SPACING_MD` end margin). */
    val textEndSpacing: Dp,
)

/** Default resolver for [IDnowLinkButtonStyle], analogous to Material3's `XxxDefaults`. */
object IDnowLinkButtonDefaults {

    /** Opacity of the pressed background (XML: [io.idnow.designsystem.styles.xml.LinkButtonStyle]). */
    private const val PRESSED_BACKGROUND_OPACITY = 0.07f

    /** Start-icon alpha, matching the XML `android:alpha="0.9"`. */
    private const val START_ICON_ALPHA = 0.9f

    @Composable
    fun style(): IDnowLinkButtonStyle {
        // secondaryActiveText / secondaryActiveStroke / radiusMd have no enum, so they are read
        // here — only allowed in a Defaults resolver. These reads transitively touch the
        // snapshot-backed IDnowDesignSystem.primitives, so a runtime re-theme recomposes the caller.
        val endIconColor = Color(Tokens.secondaryActiveText)
        val strokeColor = Color(Tokens.secondaryActiveStroke)
        val cornerRadius = Tokens.radiusMd.dp

        return IDnowLinkButtonStyle(
            textTypography = TypographyEnum.BODY_BOLD_SMALL,
            textColor = TextColorEnum.LINK,
            startIconColor = TintColorEnum.MAIN.composeColor,
            startIconAlpha = START_ICON_ALPHA,
            endIconColor = endIconColor,
            iconSize = dimensionResource(R.dimen.idnow_item_size),
            strokeColor = strokeColor,
            strokeWidth = 2.dp,
            cornerRadius = cornerRadius,
            pressedBackgroundColor = endIconColor.copy(alpha = PRESSED_BACKGROUND_OPACITY),
            itemMargin = SpacingEnum.SPACING_MD.dp,
            textStartSpacing = SpacingEnum.SPACING_SM.dp,
            textEndSpacing = SpacingEnum.SPACING_MD.dp,
        )
    }
}
