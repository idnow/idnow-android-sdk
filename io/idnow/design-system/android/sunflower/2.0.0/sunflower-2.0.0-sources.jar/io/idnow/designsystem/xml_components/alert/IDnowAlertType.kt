package io.idnow.designsystem.xml_components.alert

import androidx.annotation.DrawableRes
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.xml.AlertBoxAndTagStyle

enum class IDnowAlertType(@DrawableRes val drawable: Int) {
    INFO(R.drawable.sunflower_ic_information_filled),
    ERROR(R.drawable.sunflower_ic_cross_filled),
    WARNING(R.drawable.sunflower_ic_warning_filled),
    SUCCESS(R.drawable.sunflower_ic_check_filled);

    /**
     * Retrieve the token associated to this enum.
     * return @ColorInt
     */
    fun color(): Int {
        return when(this) {
            INFO -> AlertBoxAndTagStyle.infoColor
            ERROR -> AlertBoxAndTagStyle.errorColor
            WARNING -> AlertBoxAndTagStyle.warningColor
            SUCCESS -> AlertBoxAndTagStyle.successColor
        }
    }
}