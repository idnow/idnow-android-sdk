package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.xml_components.tutorial_step.TutorialStepIndicator

/**
 * Fully-resolved visual values for [IDnowTutorialStep].
 *
 * Compose mirror of the XML [io.idnow.designsystem.styles.xml.TutorialStepStyle] sealed class
 * (+ the `idnow_tutorial_step_*` dimens and the step-number/accent token colors). All values
 * are resolved from tokens in [IDnowTutorialStepDefaults.style] so the two worlds stay in sync.
 */
@Immutable
data class IDnowTutorialStepStyle(
    /** When true the step number is shown inline as a colored title prefix instead of a large glyph. */
    val isStepNumberInline: Boolean,
    /** Illustration (Lottie) width. */
    val illustrationWidth: Dp,
    /** Illustration height; `null` means wrap content (inline mode). */
    val illustrationHeight: Dp?,
    /** Horizontal gap reserved before the illustration in large mode (the XML `idn_space`). */
    val numberGap: Dp,
    /** Text style of the large step-number glyph. */
    val stepNumberTextStyle: TextStyle,
    /** Color of the inline `"$n."` title prefix. */
    val accentColor: Color,
    /** Title text style. */
    val titleTextStyle: TextStyle,
    /** Description text style. */
    val descriptionTextStyle: TextStyle,
    /** Spacing between the illustration cluster and the text column (XML title `SPACING_MD` start margin). */
    val contentSpacing: Dp,
    /** Spacing between title and description (XML description `SPACING_SM` top margin). */
    val descriptionSpacing: Dp,
) {
    /** Large mode shows the big step-number glyph. */
    val showStepNumber: Boolean get() = !isStepNumberInline
}

/** Default resolver for [IDnowTutorialStepStyle], analogous to Material3's `XxxDefaults`. */
object IDnowTutorialStepDefaults {

    @Composable
    fun style(indicator: TutorialStepIndicator): IDnowTutorialStepStyle {
        val inline = indicator == TutorialStepIndicator.INLINE
        val largeIconSize = dimensionResource(R.dimen.idnow_tutorial_step_large_icon_size)
        val inlineIconSize = dimensionResource(R.dimen.idnow_tutorial_step_inline_icon_size)
        val largeIconMargin = dimensionResource(R.dimen.idnow_tutorial_step_large_icon_margin)

        return IDnowTutorialStepStyle(
            isStepNumberInline = inline,
            illustrationWidth = if (inline) inlineIconSize else largeIconSize,
            illustrationHeight = if (inline) null else largeIconSize,
            numberGap = if (inline) 0.dp else largeIconMargin,
            stepNumberTextStyle = TypographyEnum.H1
                .asTextStyle(color = TintColorEnum.ACCENT_VARIANT.composeColor)
                // dimen idnow_tutorial_step_large_text_size = 120sp; the XML number sets includeFontPadding=false.
                .copy(
                    fontSize = 120.sp,
                    lineHeight = 120.sp,
                    platformStyle = PlatformTextStyle(includeFontPadding = false),
                ),
            accentColor = TintColorEnum.ACCENT.composeColor,
            titleTextStyle = TypographyEnum.H5.asTextStyle(color = TextColorEnum.HEADING.composeColor),
            descriptionTextStyle = TypographyEnum.BODY.asTextStyle(color = TextColorEnum.BODY.composeColor),
            contentSpacing = SpacingEnum.SPACING_MD.dp,
            descriptionSpacing = SpacingEnum.SPACING_SM.dp,
        )
    }
}
