package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values for
 * [io.idnow.designsystem.compose_components.controls.pdf.IDnowMenuButton].
 *
 * Compose mirror of the XML [io.idnow.designsystem.xml_components.controls.pdf.IDnowMenuButton]: a
 * tabbed button (optional start icon + bold-small label) with two visual modes (`lightUi`) and an
 * `active` state. The custom `MenuButtonTopStrokeDrawable` / `MenuButtonBottomStrokeDrawable` are
 * reproduced by [topStrokeColor] / [bottomStrokeColor] painted by the composable when the button is
 * active or pressed. All values resolve from tokens in [IDnowMenuButtonDefaults.style] so the two
 * worlds stay in sync.
 */
@Immutable
data class IDnowMenuButtonStyle(
    /** Resting background (XML: dark → tertiary/secondary by `active`; light → transparent). */
    val backgroundColor: Color,
    /** Background while pressed (XML: light → secondary; dark reuses the resting color). */
    val pressedBackgroundColor: Color,
    /** Label color token (XML: `active ? HEADING : BODY`). */
    val contentTextColor: TextColorEnum,
    /** Start-icon tint, matching [contentTextColor] (XML: `Tokens.heading` / `Tokens.body`). */
    val iconTint: Color,
    /** Top stroke color, dark UI only (XML `MenuButtonTopStrokeDrawable`, `Tokens.active`). */
    val topStrokeColor: Color,
    /** Bottom stroke color, light UI only (XML `MenuButtonBottomStrokeDrawable`, `primaryBackground`). */
    val bottomStrokeColor: Color,
    /** Top-corner radius (XML: `Tokens.radiusSm`). Only the top corners are rounded. */
    val cornerRadius: Dp,
    /** Height of the painted top stroke (XML uses the corner size as the rect height). */
    val topStrokeHeight: Dp,
    /** Thickness of the painted bottom stroke (XML: 3dp). */
    val bottomStrokeWidth: Dp,
    /** Content padding around icon + label (XML: `SPACING_SM`). */
    val contentPadding: Dp,
    /** Gap between the start icon and the label (XML: `SPACING_SM` end margin on the icon). */
    val iconEndSpacing: Dp,
    /** Square icon size (XML dimen `idnow_icon_size`). */
    val iconSize: Dp,
    /** Minimum height (XML: icon size + 2 × content padding). */
    val minHeight: Dp,
    /** Label typography (XML: `BODY_BOLD_SMALL`). */
    val textTypography: TypographyEnum,
)

/** Default resolver for [IDnowMenuButtonStyle], analogous to Material3's `XxxDefaults`. */
object IDnowMenuButtonDefaults {

    /** Bottom-stroke thickness for the light UI (XML: `3.toDp(context)`). */
    private val BOTTOM_STROKE_WIDTH = 3.dp

    /**
     * Resolve the menu-button visuals for the given mode.
     *
     * `Tokens.*` are read here (no enum equivalent for `backgroundTertiary` / `active` /
     * `primaryBackground` / `heading` / `body`) — only allowed inside a Defaults resolver. These
     * reads transitively touch the snapshot-backed `IDnowDesignSystem.primitives`, so a runtime
     * re-theme recomposes the caller.
     *
     * @param lightUi the XML `lightUi` flag (false = dark UI, the default).
     * @param active the XML `active` flag.
     */
    @Composable
    fun style(lightUi: Boolean, active: Boolean): IDnowMenuButtonStyle {
        val contentPadding = SpacingEnum.SPACING_SM.dp
        val iconSize = dimensionResource(R.dimen.idnow_icon_size)
        val cornerRadius = Tokens.radiusSm.dp

        val resting: Color
        val pressed: Color
        if (lightUi) {
            resting = Color.Transparent
            pressed = Color(Tokens.backgroundSecondary)
        } else {
            resting = if (active) Color(Tokens.backgroundSecondary) else Color(Tokens.backgroundTertiary)
            pressed = resting // XML dark UI has no dedicated pressed color.
        }

        return IDnowMenuButtonStyle(
            backgroundColor = resting,
            pressedBackgroundColor = pressed,
            contentTextColor = if (active) TextColorEnum.HEADING else TextColorEnum.BODY,
            iconTint = Color(if (active) Tokens.heading else Tokens.body),
            topStrokeColor = if (!lightUi) Color(Tokens.active) else Color.Unspecified,
            bottomStrokeColor = if (lightUi) Color(Tokens.primaryBackground) else Color.Unspecified,
            cornerRadius = cornerRadius,
            topStrokeHeight = cornerRadius,
            bottomStrokeWidth = BOTTOM_STROKE_WIDTH,
            contentPadding = contentPadding,
            iconEndSpacing = SpacingEnum.SPACING_SM.dp,
            iconSize = iconSize,
            minHeight = iconSize + contentPadding * 2,
            textTypography = TypographyEnum.BODY_BOLD_SMALL,
        )
    }
}
