package io.idnow.designsystem.compose_components.buttons

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.styles.compose.IDnowButtonDefaults
import io.idnow.designsystem.styles.compose.IDnowButtonSize
import io.idnow.designsystem.styles.compose.IDnowButtonStyle
import io.idnow.designsystem.styles.compose.IDnowButtonVariant

/**
 * Circular floating action button, the Compose counterpart of the XML `IDnowFABButton`.
 *
 * Supports the same 4 variants as [IDnowButton]:
 * - **PRIMARY / SECONDARY / DANGER**: a filled circle + stroke (matching the regular button look
 *   but circular).
 * - **TRIGGER**: the double-layer look (outer ring 2dp + gap 4dp + inner filled circle).
 *
 * The [style] also carries the **size** (SMALL / MEDIUM / LARGE) which governs the icon size and the
 * inner padding (via [IDnowButtonDefaults.resolved]) — so the FAB scales with size. The icon is forced
 * to match `iconSize` via the size modifier.
 */
@Composable
fun IDnowFABButton(
    modifier: Modifier = Modifier,
    icon: Painter,
    onClick: () -> Unit,
    style: IDnowButtonStyle = IDnowButtonStyle.primary(),
    contentDescription: String? = null,
    enabled: Boolean = true,
) {
    val resolved = IDnowButtonDefaults.resolved(style)
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val fillColor = if (pressed) resolved.pressedBackgroundColor else resolved.backgroundColor
    val ringColor = if (pressed) resolved.pressedStrokeColor else resolved.strokeColor
    val isTrigger = style.variant == IDnowButtonVariant.TRIGGER
    val triggerInset = 4.dp
    val ringStroke = 2.dp
    // Per Figma, FAB padding by size (same total diameter regardless of variant).
    val fabPadding = when (style.size) {
        IDnowButtonSize.SMALL -> 8.dp
        IDnowButtonSize.MEDIUM -> 14.dp
        IDnowButtonSize.LARGE -> 16.dp
    }
    // For trigger, the ring+inset eat into the padding budget so the total size stays the same.
    val innerPadding = if (isTrigger) (fabPadding - triggerInset).coerceAtLeast(0.dp) else fabPadding

    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else resolved.disabledOpacity)
            .clip(CircleShape)
            .then(
                if (isTrigger) {
                    // Trigger look: outer ring only (no fill on the outer), then inset then inner fill.
                    Modifier
                        .border(BorderStroke(ringStroke, ringColor), CircleShape)
                } else {
                    // Normal look: filled circle + stroke.
                    Modifier
                        .background(color = fillColor, shape = CircleShape)
                        .border(BorderStroke(resolved.strokeWidth, ringColor), CircleShape)
                },
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .then(
                if (isTrigger) {
                    // Inner filled circle after the gap.
                    Modifier
                        .padding(triggerInset)
                        .background(color = fillColor, shape = CircleShape)
                } else {
                    Modifier
                },
            )
            .padding(innerPadding),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = icon,
            contentDescription = contentDescription,
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(resolved.iconSize),
            colorFilter = ColorFilter.tint(resolved.textColor),
        )
    }
}
