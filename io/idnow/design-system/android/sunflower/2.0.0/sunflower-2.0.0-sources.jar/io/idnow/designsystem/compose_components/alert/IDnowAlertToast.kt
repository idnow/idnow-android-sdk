package io.idnow.designsystem.compose_components.alert

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.styles.compose.IDnowAlertType
import kotlinx.coroutines.delay

/** Slide/fade animation duration of the toast, in milliseconds (mirrors the XML 300ms popup anim). */
private const val ANIMATION_DURATION_MS = 300

/**
 * Shows an [IDnowAlertBox] as a transient "toast" anchored to the TOP of the screen (the Compose
 * equivalent of the XML `IDnowAlertBox.showAsToastPopup`): it renders in a top-aligned [Popup] and
 * slides in/out from above.
 *
 * Visibility is **caller-driven** — the caller owns the state (e.g. `var visible by remember { … }`)
 * and toggles [visible]; the toast notifies [onDismiss] when it should be hidden (close tap or, if
 * [durationMs] is set, after that delay). Keep this composable in the tree while toggling [visible]
 * so the exit animation can play.
 *
 * @param visible whether the toast is shown.
 * @param message the alert text.
 * @param onDismiss invoked when the toast requests dismissal (close tap or auto-dismiss).
 * @param durationMs optional auto-dismiss delay in ms; `null` (default) keeps it until dismissed.
 * @param margins padding from the screen edges; defaults to `SPACING_MD` on every side.
 */
@Composable
fun IDnowAlertToast(
    modifier: Modifier = Modifier,
    visible: Boolean,
    message: String,
    onDismiss: () -> Unit,
    alertType: IDnowAlertType = IDnowAlertType.INFO,
    showStartIcon: Boolean = true,
    startIcon: Painter? = null,
    showCloseIcon: Boolean = true,
    durationMs: Long? = null,
    margins: PaddingValues = PaddingValues(SpacingEnum.SPACING_MD.dp),
) {
    // Drive the enter/exit transition; keep the Popup mounted while visible OR animating out.
    val transitionState = remember { MutableTransitionState(false) }
    transitionState.targetState = visible
    val focusRequester = remember { FocusRequester() }

    if (durationMs != null) {
        LaunchedEffect(visible, durationMs) {
            if (visible) {
                delay(durationMs)
                onDismiss()
            }
        }
    }

    // Move accessibility focus onto the alert once it has appeared, so it is read out and the user
    // can then swipe to the close action. Requested after the slide-in so the node is laid out.
    LaunchedEffect(visible) {
        if (visible) {
            delay(ANIMATION_DURATION_MS.toLong())
            runCatching { focusRequester.requestFocus() }
        }
    }

    if (transitionState.currentState || transitionState.targetState) {
        // focusable so the popup window can hold accessibility/input focus; back/outside dismisses it.
        Popup(
            alignment = Alignment.TopCenter,
            onDismissRequest = onDismiss,
            properties = PopupProperties(focusable = true),
        ) {
            AnimatedVisibility(
                visibleState = transitionState,
                enter = slideInVertically(tween(ANIMATION_DURATION_MS)) { height -> -height } + fadeIn(tween(ANIMATION_DURATION_MS)),
                exit = slideOutVertically(tween(ANIMATION_DURATION_MS)) { height -> -height } + fadeOut(tween(ANIMATION_DURATION_MS)),
            ) {
                IDnowAlertBox(
                    message = message,
                    alertType = alertType,
                    modifier = modifier.fillMaxWidth().padding(margins),
                    showStartIcon = showStartIcon,
                    startIcon = startIcon,
                    showCloseIcon = showCloseIcon,
                    onCloseClick = onDismiss
                )
            }
        }
    }
}
