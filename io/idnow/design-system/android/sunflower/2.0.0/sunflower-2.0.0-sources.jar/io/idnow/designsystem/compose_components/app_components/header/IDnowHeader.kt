package io.idnow.designsystem.compose_components.app_components.header

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import io.idnow.designsystem.R
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.styles.compose.IDnowHeaderDefaults
import io.idnow.designsystem.styles.compose.IDnowHeaderStyle

/**
 * One header action icon. Groups the per-icon inputs so [IDnowHeader] takes a few of these instead
 * of many parallel parameters.
 *
 * @param iconRes the icon drawable resource.
 * @param contentDescription accessibility label; `null` marks the icon as decorative.
 * @param tint token tint applied to the icon.
 * @param onClick optional click callback; the icon is clickable only when provided.
 */
@Immutable
data class IDnowHeaderIcon(
    @DrawableRes val iconRes: Int,
    val contentDescription: String? = null,
    val tint: TintColorEnum = TintColorEnum.MAIN,
    val onClick: (() -> Unit)? = null,
)

/**
 * Compose counterpart of the XML `IDnowHeader`: an app bar with up to three icons (start, end,
 * additional-end) and an optional centered brand logo. Each icon is shown only when provided.
 *
 * @param brand when true, shows the centered IDnow brand logo (decorative, no content description).
 */
@Composable
fun IDnowHeader(
    modifier: Modifier = Modifier,
    brand: Boolean = false,
    startIcon: IDnowHeaderIcon? = null,
    endIcon: IDnowHeaderIcon? = null,
    additionalEndIcon: IDnowHeaderIcon? = null,
) {
    val style = IDnowHeaderDefaults.style()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = style.iconSize),
    ) {
        startIcon?.let { HeaderIcon(it, style, Modifier.align(Alignment.CenterStart)) }
        if (brand) {
            Image(
                painter = painterResource(R.drawable.idnow_logo_blue),
                contentDescription = null,
                modifier = Modifier.align(Alignment.Center),
            )
        }
        // additional-end sits to the left of end, both anchored to the end (XML constraint chain).
        Row(modifier = Modifier.align(Alignment.CenterEnd)) {
            additionalEndIcon?.let { HeaderIcon(it, style) }
            endIcon?.let { HeaderIcon(it, style) }
        }
    }
}

@Composable
private fun HeaderIcon(
    icon: IDnowHeaderIcon,
    style: IDnowHeaderStyle,
    modifier: Modifier = Modifier,
) {
    val onClick = icon.onClick
    val interactionSource = remember { MutableInteractionSource() }
    Image(
        painter = painterResource(icon.iconRes),
        contentDescription = icon.contentDescription,
        colorFilter = ColorFilter.tint(icon.tint.composeColor),
        alpha = style.iconOpacity,
        modifier = modifier
            .size(style.iconSize)
            .then(
                if (onClick != null) {
                    // No ripple: header icons are flat actions (matches the XML ImageView, which has
                    // no foreground selectable-item-background).
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick,
                    )
                } else {
                    Modifier
                },
            )
            .padding(style.iconPadding),
    )
}
