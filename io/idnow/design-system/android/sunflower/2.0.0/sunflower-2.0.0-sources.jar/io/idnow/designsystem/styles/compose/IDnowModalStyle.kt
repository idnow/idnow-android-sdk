package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values the [io.idnow.designsystem.compose_components.modal.IDnowModal] reads
 * from. Mirrors the XML `styles.xml.ModalStyle` + `idnow_modal.xml`: the modal surface background,
 * the close-button tint, the divider color, the surface corner radius and the header icon size.
 *
 * Only token/dimension-derived values live here; layout spacings (`SPACING_MD/LG/SM`) are applied
 * inline in the composable through `SpacingEnum.*.dp`, the design-system's Compose spacing convention.
 */
@Immutable
data class IDnowModalStyle(
    val backgroundColor: Color,
    val closeButtonTint: Color,
    val dividerColor: Color,
    val cornerRadius: Dp,
    val iconSize: Dp,
)

/** Default resolver for [IDnowModalStyle], analogous to Material3's `XxxDefaults`. */
object IDnowModalDefaults {

    /**
     * Resolve the modal style from the current tokens, mapping the same tokens the XML `ModalStyle`
     * uses to their Compose types. The `Tokens.*` reads below happen directly during composition (not
     * inside a `remember`), so each transitively reads the snapshot-backed `IDnowDesignSystem.primitives`
     * and a runtime re-theme recomposes any open modal automatically.
     */
    @Composable
    fun style(): IDnowModalStyle {
        return IDnowModalStyle(
            backgroundColor = Color(Tokens.backgroundPrimary),
            closeButtonTint = Color(Tokens.secondaryActiveText),
            dividerColor = Color(Tokens.borderPrimary),
            // radiusLg is a dp magnitude (see ComposeTokens unit note) → wrap as .dp.
            cornerRadius = Tokens.radiusLg.dp,
            iconSize = dimensionResource(R.dimen.idnow_icon_size),
        )
    }
}
