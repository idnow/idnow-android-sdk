package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values for [io.idnow.designsystem.compose_components.app_components.divider.IDnowDivider],
 * the Compose mirror of the XML [io.idnow.designsystem.xml_components.app_components.divider.IDnowDivider]
 * (a `View` whose background is `Tokens.borderPrimary`, height driven by the layout).
 *
 * The divider is simply a 1dp line filled with [color]; its length is controlled by the caller's modifier.
 */
@Immutable
data class IDnowDividerStyle(
    /** Line color (XML: `Tokens.borderPrimary`). */
    val color: Color,
    /** Line thickness (XML: the `1dp` layout height used everywhere). */
    val thickness: Dp,
)

/** Default resolver for [IDnowDividerStyle], analogous to Material3's `XxxDefaults`. */
object IDnowDividerDefaults {

    /** Divider thickness in dp, matching the 1dp height the XML dividers are laid out with. */
    private const val THICKNESS_DP = 1f

    @Composable
    fun style(): IDnowDividerStyle = IDnowDividerStyle(
        // borderPrimary has no enum, so it is read straight from Tokens here — only allowed in a
        // Defaults resolver. The read transitively touches the snapshot-backed IDnowDesignSystem.primitives,
        // so a runtime re-theme recomposes the caller.
        color = Color(Tokens.borderPrimary),
        thickness = THICKNESS_DP.dp,
    )
}
