package io.idnow.designsystem.xml_components.form_input_texts.common

import android.content.res.ColorStateList
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowContainerItemBinding
import io.idnow.designsystem.styles.xml.ContainerStyle
import io.idnow.designsystem.styles.xml.FormInputsStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTypography

/**
 * Update item content visibility, values and constraint (with token)
 * @param item the item to use to draw the cell
 * @param smallText item is smaller in dropdown
 * @param isSelected is this item the selected one
 */
internal fun IdnowContainerItemBinding.updateItem(item: IDnowItemData, smallText: Boolean, isSelected: Boolean) {
    item.icon?.let {
        idnowItemIcon.apply {
            val resIconSize = if (smallText) R.dimen.idnow_item_size else R.dimen.idnow_icon_size
            val iconSize = resources.getDimension(resIconSize).toInt()
            layoutParams.applyMargin(context = context, start = Tokens.spacingMd, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
            layoutParams.width = iconSize
            layoutParams.height = iconSize
            setImageResource(it)
            isVisible = true
        }
    }
    item.content?.let {
        idnowItemText.apply {
            layoutParams.applyMargin(context = context, start = Tokens.spacingMd, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
            text = it
            val font = if (smallText) FormInputsStyle.fontItem(context) else ContainerStyle.font(context)
            setTypography(font)
            setTextColor(FormInputsStyle.popupTextColor)
            isVisible = true
        }
    }
    if (isSelected && smallText) {
        idnowItemCheck.apply {
            layoutParams.applyMargin(context = context, end = Tokens.spacingMd)
            isVisible = true
            imageTintList = ColorStateList.valueOf(FormInputsStyle.popupCheckColor)
        }
    } else {
        idnowItemCheck.isVisible = false
    }
}