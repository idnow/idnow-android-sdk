package io.idnow.designsystem.styles.xml

import android.content.Context
import androidx.annotation.Dimension
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography

internal object AlertBoxAndTagStyle {

    /**
     * For container bg color
     */
    val bgColorOpacity: Float = 0.2f

    /**
     * INFO color
     */
    val infoColor get() = Tokens.active

    /**
     * WARNING color
     */
    val warningColor get() = Tokens.processing

    /**
     * ERROR color
     */
    val errorColor get() = Tokens.error

    /**
     * SUCCESS  color
     */
    val successColor get() = Tokens.success

    /**
     * Alert Box Background corner radius
     */
    val cornerRadiusBox get() = Tokens.radiusMd

    /**
     * Alert Tag Background corner radius
     */
    val cornerRadiusTag get() = Tokens.radiusFull

    /**
     * Box item margin
     */
    val boxItemMargin get() = Tokens.spacingMd

    /**
     * Tag item margin
     */
    val tagItemMargin get() = Tokens.spacingSm

    /**
     * Tag indicator item margin
     */
    val tagInnerItemMargin get() = Tokens.spacingXs

    /**
     * Container text color
     */
    val textColor get() = Tokens.body

    /**
     * Container solid color without alpha so the box color with alpha will render properly
     */
    val containerBgColor get() = Tokens.background

    /**
     * Icon size of a tag.
     */
    @Dimension(Dimension.DP)
    val alertIconSize = 10

    /** Box container typography */
    fun boxTextFont(context: Context) = Typography.BodySmall(context)

    /** Tag container typography */
    fun tagTextFont(context: Context) = Typography.BodyXSmall(context)
}