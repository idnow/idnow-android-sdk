package io.idnow.designsystem.compose_components.navigation

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.text_view.IDnowText
import io.idnow.designsystem.styles.compose.IDnowLinkButtonDefaults

/**
 * Tokenized link button, the Compose counterpart of the XML
 * [io.idnow.designsystem.xml_components.navigation.IDnowLinkButton].
 *
 * A clickable, rounded, bordered row with an optional start icon (tinted `MAIN`), a link-colored
 * label and an optional end icon (the "external link" glyph, tinted from `secondaryActiveText`).
 * Visuals are resolved internally from [IDnowLinkButtonDefaults]; spacing is applied by the caller
 * via [modifier]. Pressing the button shows the tokenized pressed fill, mirroring the XML
 * `idnow_link_button_background` state-list drawable.
 *
 * @param text the label.
 * @param onClick invoked when the button is tapped.
 * @param modifier caller-applied spacing/layout (the XML margins live here).
 * @param startIcon optional leading icon; defaults to `sunflower_ic_documents` like the XML view.
 *   Pass `null` to hide it.
 * @param endIcon optional trailing icon; defaults to `sunflower_ic_external_link` like the XML view.
 *   Pass `null` to hide it.
 */
@Composable
fun IDnowLinkButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    @DrawableRes startIcon: Int? = R.drawable.sunflower_ic_documents,
    @DrawableRes endIcon: Int? = R.drawable.sunflower_ic_external_link,
) {
    val style = IDnowLinkButtonDefaults.style()
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val linkLabel = stringResource(R.string.sunflower_link)
    val description = remember(text, linkLabel) {
        "${text}${if (!text.endsWith(".")) "." else ""} $linkLabel"
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(style.cornerRadius))
            .background(if (isPressed) style.pressedBackgroundColor else Color.Transparent)
            .border(style.strokeWidth, style.strokeColor, RoundedCornerShape(style.cornerRadius))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            )
            .clearAndSetSemantics { contentDescription = description },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (startIcon != null) {
            Image(
                painter = painterResource(startIcon),
                contentDescription = null,
                colorFilter = ColorFilter.tint(style.startIconColor),
                modifier = Modifier
                    .padding(start = style.itemMargin, top = style.itemMargin, bottom = style.itemMargin)
                    .size(style.iconSize)
                    .alpha(style.startIconAlpha),
            )
        }

        IDnowText(
            text = text,
            modifier = Modifier
                .weight(1f)
                .padding(
                    // When startIcon is absent, use the same margin the icon would have (itemMargin)
                    // so the text sits at the same indent.
                    start = if (startIcon != null) style.textStartSpacing else style.itemMargin,
                    end = if (endIcon != null) style.textEndSpacing else style.itemMargin,
                ),
            typography = style.textTypography,
            textColor = style.textColor,
        )

        if (endIcon != null) {
            Image(
                painter = painterResource(endIcon),
                contentDescription = null,
                colorFilter = ColorFilter.tint(style.endIconColor),
                modifier = Modifier
                    .padding(top = style.itemMargin, bottom = style.itemMargin, end = style.itemMargin)
                    .size(style.iconSize),
            )
        }
    }
}

