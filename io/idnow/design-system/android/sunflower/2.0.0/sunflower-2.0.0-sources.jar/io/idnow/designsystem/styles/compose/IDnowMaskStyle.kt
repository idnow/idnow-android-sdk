package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.styles.xml.MaskStyle

/**
 * Fully-resolved visual values for `IDnowMask`. Compose mirror of the XML [MaskStyle].
 */
@Immutable
data class IDnowMaskStyle(
    /** Length of the corner brackets (RECT shape). */
    val cornerWidth: Dp,
    /** Radius of the rounded (cubic) corners (RECT shape). */
    val cubicCornerWidth: Dp,
    /** Width of the overlay stroke. */
    val strokeWidth: Dp,
    /** Peak scale of the bounce animation. */
    val bouncePower: Float,
    /** Full duration of one bounce cycle (1 → power → 1), in ms. */
    val bounceDurationMillis: Int,
)

/** Default resolver for [IDnowMaskStyle]. */
object IDnowMaskDefaults {

    @Composable
    fun style(): IDnowMaskStyle = IDnowMaskStyle(
        cornerWidth = MaskStyle.cornerWidth.dp,
        cubicCornerWidth = MaskStyle.cubicCornerWidth.dp,
        strokeWidth = MaskStyle.strokeWidth.dp,
        bouncePower = MaskStyle.bouncePower,
        bounceDurationMillis = MaskStyle.bounceDuration.toInt(),
    )
}
