package io.idnow.designsystem.styles.xml

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.annotation.Dimension
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.LayerBuilder
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.gradientDrawable
import io.idnow.designsystem.xml_components.extension.layerDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.navigation.IDnowEntryButton

internal sealed interface EntryButtonStyle {

    /**
     * Corner radius of the button.
     */
    val cornerRadius get() = Tokens.radiusMd

    /**
     * Container stroke width
     */
    @get:Dimension(unit = Dimension.DP)
    val strokeWidth get() = 1

    /**
     * Container stroke color
     */
    val strokeColor get() = Tokens.borderSecondary

    fun background(context: Context): Drawable

    data object Medium : EntryButtonStyle {
        override fun background(context: Context): Drawable = gradientDrawable {
            stroke(strokeColor, strokeWidth.toDp(context))
            cornerRadius(this@Medium.cornerRadius.toDp(context).toFloat())
        }
    }

    data object Large : EntryButtonStyle {
        override fun background(context: Context): Drawable = layerDrawable {
            val strokeWidthDp = strokeWidth.toDp(context)
            val cornerRadiusDp = cornerRadius.toDp(context)
            layer {
                inset = LayerBuilder.Insets(left = -(strokeWidthDp + cornerRadiusDp))
                gradient {
                    stroke(strokeColor, strokeWidthDp)
                    cornerRadius(cornerRadiusDp.toFloat())
                }
            }
        }
    }

    companion object {
        /**
         * Opacity of the description.
         */
        val descOpacity get() = 0.83f

        fun IDnowEntryButton.Style.toStyle() = when (this) {
            IDnowEntryButton.Style.MEDIUM -> Medium
            IDnowEntryButton.Style.LARGE -> Large
        }
    }
}