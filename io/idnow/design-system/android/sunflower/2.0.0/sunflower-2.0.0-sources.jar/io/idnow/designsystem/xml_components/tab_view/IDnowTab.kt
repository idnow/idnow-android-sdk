package io.idnow.designsystem.xml_components.tab_view

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import com.google.android.material.tabs.TabLayout
import io.idnow.designsystem.databinding.IdnowTabItemBinding
import io.idnow.designsystem.styles.xml.TabLayoutStyle
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTextColor
import io.idnow.designsystem.xml_components.extension.setTypography

internal class IDnowTab(private val context: Context): TabLayout.Tab() {

    private val tabItemBinding = IdnowTabItemBinding.inflate(LayoutInflater.from(context), null, false)

    init {
        tabItemBinding.text1.apply {
            setTypography(TabLayoutStyle.font(context))
            setTextColor(TabLayoutStyle.selectedTabTextColor, TabLayoutStyle.defaultTabTextColor)
        }
        super.setCustomView(tabItemBinding.tabItemView)
    }

    override fun setIcon(icon: Drawable?): TabLayout.Tab {
        applyGapBetweenTitleAndIcon(icon, text)
        return super.setIcon(icon)
    }

    override fun setIcon(resId: Int): TabLayout.Tab {
        applyGapBetweenTitleAndIcon(AppCompatResources.getDrawable(context, resId), text)
        return super.setIcon(resId)
    }

    override fun setText(text: CharSequence?): TabLayout.Tab {
        applyGapBetweenTitleAndIcon(icon, text)
        return super.setText(text)
    }

    override fun setText(resId: Int): TabLayout.Tab {
        applyGapBetweenTitleAndIcon(icon, context.getString(resId))
        return super.setText(resId)
    }

    /** Apply icon end margin only if we have icon and title set */
    private fun applyGapBetweenTitleAndIcon(icon: Drawable?, text: CharSequence?) {
        //apply fixed 8dp gap between text and icon if both visible
        val iconEndMargin = if (icon != null && text.isNullOrEmpty().not()) TabLayoutStyle.itemMargin else 0
        tabItemBinding.icon.apply {
            layoutParams = layoutParams.applyMargin(context, end = iconEndMargin)
        }
    }

    /** Do not allow setting custom view */
    override fun setCustomView(view: View?): TabLayout.Tab {
        throw IllegalAccessException("IDnowTab does not support setting custom views.")
    }

    /** Do not allow setting custom view */
    override fun setCustomView(resId: Int): TabLayout.Tab {
        throw IllegalAccessException("IDnowTab does not support setting custom views.")
    }
}