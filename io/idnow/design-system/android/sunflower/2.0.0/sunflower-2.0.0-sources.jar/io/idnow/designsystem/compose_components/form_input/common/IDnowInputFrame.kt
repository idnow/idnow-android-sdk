package io.idnow.designsystem.compose_components.form_input.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle

/**
 * Shared layout of every form input — Compose mirror of the XML `idnow_form_inputs.xml`: a vertical
 * stack of **label → error row → bordered container → helper**, spaced by [IDnowFormInputStyle.itemSpacing].
 * Only the [container] slot differs per variant (text field, spinner, phone, autocomplete).
 *
 * The visual label/error/helper texts are silenced for accessibility ([clearAndSetSemantics]) exactly
 * like the XML (`importantForAccessibility="no"`); the spoken description is carried by the field node
 * inside [container] (see [rememberInputAccessibilityText]).
 */
@Composable
internal fun IDnowInputFrame(
    style: IDnowFormInputStyle,
    label: String?,
    errorText: String?,
    isError: Boolean,
    helperText: String?,
    modifier: Modifier = Modifier,
    container: @Composable () -> Unit,
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(style.itemSpacing)) {
        if (!label.isNullOrEmpty()) {
            BasicText(text = label, style = style.labelTextStyle, modifier = Modifier.clearAndSetSemantics { })
        }
        if (isError && !errorText.isNullOrEmpty()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clearAndSetSemantics { },
            ) {
                Image(
                    painter = painterResource(R.drawable.sunflower_ic_warning),
                    contentDescription = null,
                    colorFilter = ColorFilter.tint(style.errorIconTint),
                    modifier = Modifier.size(style.errorIconSize),
                )
                Spacer(Modifier.width(style.itemSpacing))
                BasicText(text = errorText, style = style.errorTextStyle)
            }
        }
        container()
        if (!helperText.isNullOrEmpty()) {
            BasicText(text = helperText, style = style.helperTextStyle, modifier = Modifier.clearAndSetSemantics { })
        }
    }
}

/**
 * The spoken description attached to the field node, in the order **`Warning. errorText. label.
 * helperText. hint.`** (error-first, per the team's a11y decision — this is NOT the XML order). Each
 * part is omitted when empty. The current field value is intentionally NOT included here: editable
 * fields announce their text natively via `editableText` (adding it would double-read), and the
 * spinner passes its selected content through [hint].
 *
 * The error is prefixed with the localized `sunflower_warning` string ("Warning.") rather than
 * Compose's `error()` semantics, which TalkBack reads as "Error:".
 */
@Composable
internal fun rememberInputAccessibilityText(
    label: String?,
    hint: String?,
    errorText: String?,
    isError: Boolean,
    helperText: String?,
): String {
    val warning = stringResource(R.string.sunflower_warning)
    return remember(label, hint, errorText, isError, helperText, warning) {
        buildString {
            if (isError && !errorText.isNullOrEmpty()) append("$warning ${errorText.withDot()} ")
            if (!label.isNullOrEmpty()) append("${label.withDot()} ")
            if (!helperText.isNullOrEmpty()) append("${helperText.withDot()} ")
            if (!hint.isNullOrEmpty()) append("${hint.withDot()} ")
        }.trim()
    }
}

private fun String.withDot(): String = if (endsWith(".")) this else "$this."
