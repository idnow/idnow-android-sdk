package io.idnow.designsystem.styles

import android.content.Context
import androidx.annotation.ColorInt
import androidx.annotation.Dimension
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography


internal sealed class ButtonStyle {
    /**
     * Border width in DP
     */
    @Dimension(unit = Dimension.DP)
    val strokeWidth = 1.5f

    /**
     * Max width in DP
     */
    @Dimension(unit = Dimension.DP)
    val maxWidth = 343

    /**
     * IDnowFABButton size
     */
    @Dimension(unit = Dimension.DP)
    val fabButtonSize = 64

    /**
     * Icon padding in DP
     */
    val iconPadding get() = Tokens.spacingSm

    /**
     * Corner radius in DP
     */
    val cornerRadius get() = Tokens.radiusFull

    /**
     * All the paddings in DP
     */
    val paddings = SpacingQuad(start = SpacingEnum.SPACING_LG, end = SpacingEnum.SPACING_LG, top = SpacingEnum.SPACING_MD, bottom = SpacingEnum.SPACING_MD)

    /**
     * All the margins in DP
     */
    val margins = SpacingQuad()

    /**
     * Pressed color opacity
     */
    abstract val pressedColorOpacity: Float

    /**
     * Background color [ColorInt]
     */
    abstract val backgroundColor: Int

    /**
     * Border color [ColorInt]
     */
    abstract val strokeColor: Int

    /**
     * Text color [ColorInt]
     */
    abstract val textColor: Int

    /**
     * Pressed color [ColorInt]
     */
    val pressedColor: Int get() = Tokens.backgroundDarker

    /**
     * Button typography
     */
    abstract val typography: Typography

    data class PrimaryButton(val context: Context) : ButtonStyle() {
        override val pressedColorOpacity: Float = 0.25f
        override val backgroundColor: Int get() = Tokens.primaryBackground
        override val strokeColor: Int get() = Tokens.primaryBackground
        override val textColor: Int get() = Utils.getLuminanceTokenForPrimaryText(Tokens.primaryBackground)
        override val typography: Typography get() = Typography.H6(context)
    }

    data class SecondaryButton(val context: Context) : ButtonStyle() {
        override val pressedColorOpacity: Float = 0.05f
        override val backgroundColor: Int get() = Tokens.secondaryActiveBackground
        override val strokeColor: Int get() = Tokens.secondaryActiveStroke
        override val textColor: Int get() = Tokens.secondaryActiveText
        override val typography: Typography get() = Typography.H6(context)
    }

    data class DangerButton(val context: Context) : ButtonStyle() {
        override val pressedColorOpacity: Float = 0.25f
        override val backgroundColor: Int get() = Tokens.error
        override val strokeColor: Int get() = Tokens.error
        override val textColor: Int get() = Utils.getLuminanceTokenForPrimaryText(Tokens.primaryBackground)
        override val typography: Typography get() = Typography.H6(context)
    }

    companion object {
        /** Button opacity, change if enable/disable*/
        fun opacity(enabled: Boolean) = if(enabled) 1.0f else 0.5f
    }
}
