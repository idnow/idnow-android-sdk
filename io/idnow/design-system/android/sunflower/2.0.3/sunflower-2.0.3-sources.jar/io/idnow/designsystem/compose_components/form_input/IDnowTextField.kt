package io.idnow.designsystem.compose_components.form_input

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.form_input.common.ClickableInputIcon
import io.idnow.designsystem.compose_components.form_input.common.DecorIcon
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputFrame
import io.idnow.designsystem.compose_components.form_input.common.InputDecorationBox
import io.idnow.designsystem.compose_components.form_input.common.inputContentDescription
import io.idnow.designsystem.compose_components.form_input.common.rememberContainerState
import io.idnow.designsystem.compose_components.form_input.common.rememberInputAccessibilityText
import io.idnow.designsystem.styles.compose.IDnowFormInputDefaults
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle

/**
 * Compose counterpart of the XML `IDnowTextField`. A single-line (by default) text field inside the
 * shared form-input frame: label, error, helper, bordered container with optional leading icon,
 * clear button, trailing icon and password toggle.
 *
 * Stateless: hoist [value] and react via [onValueChange]. Style is resolved internally
 * ([IDnowFormInputDefaults]); the public API is the value + token-driven flags.
 *
 * @param errorText shown above the field as an error message; combined with [isError] turns the border red.
 * @param clearIcon shows a clear (✕) button while the field is non-empty.
 * @param passwordToggle shows an eye icon that toggles password masking (occupies the trailing slot).
 */
@Composable
fun IDnowTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    hint: String? = null,
    helperText: String? = null,
    errorText: String? = null,
    isError: Boolean = false,
    enabled: Boolean = true,
    leadingIcon: Painter? = null,
    trailingIcon: Painter? = null,
    clearIcon: Boolean = false,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    passwordToggle: Boolean = false,
    singleLine: Boolean = true,
) {
    var fieldValueState by remember { mutableStateOf(TextFieldValue(text = value)) }
    val fieldValue = fieldValueState.copy(text = value)
    SideEffect {
        if (fieldValue.selection != fieldValueState.selection ||
            fieldValue.composition != fieldValueState.composition
        ) {
            fieldValueState = fieldValue
        }
    }
    var lastReportedText by remember(value) { mutableStateOf(value) }

    IDnowTextField(
        value = fieldValue,
        onValueChange = { newValue ->
            fieldValueState = newValue
            if (lastReportedText != newValue.text) {
                lastReportedText = newValue.text
                onValueChange(newValue.text)
            }
        },
        modifier = modifier,
        label = label,
        hint = hint,
        helperText = helperText,
        errorText = errorText,
        isError = isError,
        enabled = enabled,
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        clearIcon = clearIcon,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        passwordToggle = passwordToggle,
        singleLine = singleLine,
    )
}

/**
 * Caret-aware variant of [IDnowTextField] backed by [TextFieldValue]. Use this instead of the
 * [String] overload when the caller reformats the text as the user types (e.g. inserting `-`
 * separators) and therefore needs to preserve or control the caret/selection: the [TextFieldValue]
 * carries the [androidx.compose.ui.text.TextRange] which round-trips through [onValueChange], so the
 * cursor stays put across external value changes.
 *
 * This is the single underlying implementation; the [String] overload delegates to it.
 *
 * @param errorText shown above the field as an error message; combined with [isError] turns the border red.
 * @param clearIcon shows a clear (✕) button while the field is non-empty.
 * @param passwordToggle shows an eye icon that toggles password masking (occupies the trailing slot).
 */
@Composable
fun IDnowTextField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    hint: String? = null,
    helperText: String? = null,
    errorText: String? = null,
    isError: Boolean = false,
    enabled: Boolean = true,
    leadingIcon: Painter? = null,
    trailingIcon: Painter? = null,
    clearIcon: Boolean = false,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    passwordToggle: Boolean = false,
    singleLine: Boolean = true,
) {
    val style = IDnowFormInputDefaults.style()
    val interactionSource = remember { MutableInteractionSource() }
    val containerState = rememberContainerState(interactionSource, isError, enabled)
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    val accessibilityText = rememberInputAccessibilityText(label, hint, errorText, isError, helperText)

    val visualTransformation = if (passwordToggle && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None
    val effectiveKeyboardOptions = if (passwordToggle && keyboardOptions == KeyboardOptions.Default) {
        KeyboardOptions(keyboardType = KeyboardType.Password)
    } else {
        keyboardOptions
    }

    IDnowInputFrame(
        style = style,
        label = label,
        errorText = errorText,
        isError = isError,
        helperText = helperText,
        modifier = modifier,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            enabled = enabled,
            singleLine = singleLine,
            textStyle = style.fieldTextStyle,
            cursorBrush = SolidColor(style.cursorColor),
            visualTransformation = visualTransformation,
            keyboardOptions = effectiveKeyboardOptions,
            keyboardActions = keyboardActions,
            interactionSource = interactionSource,
            modifier = Modifier.inputContentDescription(accessibilityText),
            decorationBox = { innerTextField ->
                InputDecorationBox(
                    style = style,
                    containerState = containerState,
                    value = value.text,
                    hint = hint,
                    innerTextField = innerTextField,
                    leading = leadingIcon?.let { { DecorIcon(it, style.leadingIconTint, style.leadingIconSize) } },
                    trailing = trailingSlot(
                        style = style,
                        value = value.text,
                        enabled = enabled,
                        clearIcon = clearIcon,
                        passwordToggle = passwordToggle,
                        passwordVisible = passwordVisible,
                        trailingIcon = trailingIcon,
                        onClear = { onValueChange(TextFieldValue("")) },
                        onTogglePassword = { passwordVisible = !passwordVisible },
                    ),
                )
            },
        )
    }
}

/** Builds the trailing slot content (clear + password eye / static trailing icon), or null when empty. */
private fun trailingSlot(
    style: IDnowFormInputStyle,
    value: String,
    enabled: Boolean,
    clearIcon: Boolean,
    passwordToggle: Boolean,
    passwordVisible: Boolean,
    trailingIcon: Painter?,
    onClear: () -> Unit,
    onTogglePassword: () -> Unit,
): (@Composable () -> Unit)? {
    val showClear = clearIcon && value.isNotEmpty()
    if (!showClear && !passwordToggle && trailingIcon == null) return null
    return {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showClear) {
                ClickableInputIcon(
                    painter = painterResource(R.drawable.sunflower_ic_cross_filled),
                    tint = style.clearIconTint,
                    size = style.clearIconSize,
                    contentDescription = stringResource(R.string.sunflower_clear_content_description),
                    enabled = enabled,
                    onClick = onClear,
                )
            }
            if (passwordToggle) {
                if (showClear) Spacer(Modifier.width(style.innerPadding))
                PasswordToggleIcon(style, passwordVisible, enabled, onTogglePassword)
            } else if (trailingIcon != null) {
                if (showClear) Spacer(Modifier.width(style.innerPadding))
                DecorIcon(trailingIcon, style.trailingIconTint, style.trailingIconSize)
            }
        }
    }
}

/** The eye icon toggling password visibility, announcing the new state (no ripple). */
@Composable
private fun PasswordToggleIcon(
    style: IDnowFormInputStyle,
    passwordVisible: Boolean,
    enabled: Boolean,
    onToggle: () -> Unit,
) {
    val icon = if (passwordVisible) R.drawable.sunflower_ic_eye_off else R.drawable.sunflower_ic_eye_on
    val description = stringResource(
        if (passwordVisible) R.string.sunflower_hide_password_content_description else R.string.sunflower_show_password_content_description,
    )
    ClickableInputIcon(
        painter = painterResource(icon),
        tint = style.trailingIconTint,
        size = style.trailingIconSize,
        contentDescription = description,
        enabled = enabled,
        onClick = onToggle,
    )
}
