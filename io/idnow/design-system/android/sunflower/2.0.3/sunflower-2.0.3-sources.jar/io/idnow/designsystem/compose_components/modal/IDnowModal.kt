package io.idnow.designsystem.compose_components.modal

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.buttons.IDnowButton
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.compose_components.image_view.IDnowImage
import io.idnow.designsystem.compose_components.text_view.IDnowText
import io.idnow.designsystem.styles.compose.IDnowButtonStyle
import io.idnow.designsystem.styles.compose.IDnowModalDefaults

/** Width behavior of a footer button, the Compose counterpart of the XML `IDnowModal.ButtonFillType`. */
enum class IDnowModalButtonFillType { WRAP, FILL }

/**
 * One modal footer button. Groups the per-button inputs so [IDnowModal] takes one of these per side
 * instead of many parallel parameters.
 *
 * @param text button label; the button is shown only when this is non-empty.
 * @param icon optional leading icon, laid out before the text.
 * @param fillType [IDnowModalButtonFillType.FILL] (shares the row width) or [IDnowModalButtonFillType.WRAP]
 *   (hugs its content).
 * @param enabled when `false`, the button is greyed out (disabled opacity) and non-clickable,
 *   like [IDnowButton]'s `enabled`. Use it to gate an action on a condition (validation, consent…).
 * @param onClick click callback; `null` (default) dismisses the modal (matches the XML default listener).
 */
@Immutable
data class IDnowModalButton(
    val text: String,
    val icon: Painter? = null,
    val fillType: IDnowModalButtonFillType = IDnowModalButtonFillType.FILL,
    val enabled: Boolean = true,
    val onClick: (() -> Unit)? = null,
)

/**
 * Tokenized modal dialog.
 *
 * - an optional **header** (icon + title + close button), each part toggleable;
 * - an optional custom **content** slot between the header and the footer;
 * - an optional **footer** with a SECONDARY [negativeButton] and a PRIMARY [positiveButton], each
 *   passed as an [IDnowModalButton] (hidden when absent or its text is empty);
 * - smart dividers that appear only between populated sections.
 *
 * Visibility is **caller-driven** — the caller owns the state (e.g. `var visible by remember { … }`)
 * and toggles [visible]; the modal calls [onDismiss] when a button/close requests dismissal.
 *
 * @param visible whether the modal is shown.
 * @param onDismiss invoked when the modal should be hidden (default action for close / buttons).
 * @param title header title; `null`/empty leaves it blank.
 * @param icon optional header icon, tinted with the `MAIN` token.
 * @param isCloseButtonVisible show the header close (✕) button.
 * @param onCloseClick close-button action; `null` (default) dismisses.
 * @param isHeaderVisible show the whole header section.
 * @param isFooterVisible show the whole footer section.
 * @param negativeButton the SECONDARY footer button, or `null` to hide it.
 * @param positiveButton the PRIMARY footer button, or `null` to hide it.
 * @param content optional custom content rendered between the dividers.
 */
@Composable
fun IDnowModal(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    title: String? = null,
    icon: Painter? = null,
    isCloseButtonVisible: Boolean = true,
    onCloseClick: (() -> Unit)? = null,
    isHeaderVisible: Boolean = true,
    isFooterVisible: Boolean = true,
    negativeButton: IDnowModalButton? = null,
    positiveButton: IDnowModalButton? = null,
    content: (@Composable ColumnScope.() -> Unit)? = null,
) {
    if (!visible) return

    val style = IDnowModalDefaults.style()

    // Divider visibility
    val firstDividerVisible = isHeaderVisible && (content != null || isFooterVisible)
    val secondDividerVisible = content != null && isFooterVisible

    // A button is rendered only when present, non-empty, and the footer is shown.
    val negative = negativeButton?.takeIf { isFooterVisible && it.text.isNotEmpty() }
    val positive = positiveButton?.takeIf { isFooterVisible && it.text.isNotEmpty() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false,
        ),
    ) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingEnum.SPACING_MD.dp)
                .clip(RoundedCornerShape(style.cornerRadius))
                .background(style.backgroundColor),
        ) {
            if (isHeaderVisible) {
                ModalHeader(
                    title = title,
                    icon = icon,
                    isCloseButtonVisible = isCloseButtonVisible,
                    closeButtonTint = style.closeButtonTint,
                    iconSize = style.iconSize,
                    onClose = onCloseClick ?: onDismiss,
                )
            }

            if (firstDividerVisible) ModalDivider(color = style.dividerColor, topGap = SpacingEnum.SPACING_MD.dp)

            if (content != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            start = SpacingEnum.SPACING_LG.dp,
                            end = SpacingEnum.SPACING_LG.dp,
                            top = SpacingEnum.SPACING_LG.dp,
                            // When a second divider follows, it owns the gap below the content (its topGap)
                            bottom = if (secondDividerVisible) 0.dp else SpacingEnum.SPACING_LG.dp,
                        ),
                    content = content,
                )
            }

            if (secondDividerVisible) ModalDivider(color = style.dividerColor, topGap = SpacingEnum.SPACING_LG.dp)

            if (negative != null || positive != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = SpacingEnum.SPACING_LG.dp, vertical = SpacingEnum.SPACING_MD.dp),
                    horizontalArrangement = Arrangement.spacedBy(SpacingEnum.SPACING_MD.dp, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    negative?.let { ModalFooterButton(it, IDnowButtonStyle.secondary(), onDismiss) }
                    positive?.let { ModalFooterButton(it, IDnowButtonStyle.primary(), onDismiss) }
                }
            }
        }
    }
}

/** One footer button: resolves the per-button fill width and the `null`-listener-dismisses rule. */
@Composable
private fun RowScope.ModalFooterButton(
    button: IDnowModalButton,
    style: IDnowButtonStyle,
    onDismiss: () -> Unit,
) {
    IDnowButton(
        text = button.text,
        onClick = button.onClick ?: onDismiss,
        style = style,
        icon = button.icon,
        enabled = button.enabled,
        modifier = if (button.fillType == IDnowModalButtonFillType.FILL) {
            Modifier.weight(1f)
        } else {
            Modifier.wrapContentWidth()
        },
    )
}

@Composable
private fun ModalHeader(
    title: String?,
    icon: Painter?,
    isCloseButtonVisible: Boolean,
    closeButtonTint: Color,
    iconSize: Dp,
    onClose: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = SpacingEnum.SPACING_MD.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (icon != null) {
            IDnowImage(
                painter = icon,
                contentDescription = null,
                tintColor = TintColorEnum.MAIN,
                modifier = Modifier
                    .padding(start = SpacingEnum.SPACING_LG.dp)
                    .size(iconSize),
            )
        }
        IDnowText(
            text = title.orEmpty(),
            typography = TypographyEnum.H6,
            textColor = TextColorEnum.HEADING,
            modifier = Modifier
                .weight(1f)
                .padding(
                    start = if (icon != null) SpacingEnum.SPACING_SM.dp else SpacingEnum.SPACING_LG.dp,
                    end = if (isCloseButtonVisible) SpacingEnum.SPACING_SM.dp else SpacingEnum.SPACING_LG.dp,
                ),
        )
        if (isCloseButtonVisible) {
            Image(
                painter = painterResource(R.drawable.sunflower_ic_cross),
                contentDescription = stringResource(R.string.sunflower_close_popup),
                colorFilter = ColorFilter.tint(closeButtonTint),
                modifier = Modifier
                    .padding(end = SpacingEnum.SPACING_LG.dp)
                    .size(iconSize)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onClose,
                    ),
            )
        }
    }
}

/** Full-width 1dp divider with a top gap, drawn from the `borderPrimary` token. */
@Composable
private fun ModalDivider(
    color: Color,
    topGap: Dp,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = topGap)
            .height(1.dp)
            .background(color),
    )
}
