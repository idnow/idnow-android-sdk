package io.idnow.designsystem.compose_components.tutorial_step

import androidx.annotation.RawRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import io.idnow.designsystem.compose_components.lottie.IDnowLottieIllustration
import io.idnow.designsystem.styles.compose.IDnowTutorialStepDefaults
import io.idnow.designsystem.styles.compose.IDnowTutorialStepStyle
import io.idnow.designsystem.xml_components.tutorial_step.TutorialStepIndicator

/**
 * Compose counterpart of the XML `IDnowTutorialStep`.
 *
 * Shows a tutorial step: a leading Lottie illustration plus a title and optional description. Two
 * layouts, driven by [indicator]:
 *  - [TutorialStepIndicator.LARGE]: a big step-number glyph sits behind/left of the illustration.
 *  - [TutorialStepIndicator.INLINE]: no big glyph; the step number is a colored `"$n."` title prefix.
 *
 * This overload takes any [LottieCompositionSpec], so the illustration can come from a `R.raw.*`
 * resource, but also a URL, an asset, a file, a JSON string, … (mirrors the flexibility the XML
 * `IDnowTutorialStep` gets from its exposed `lottie()` view). For the common raw-resource case, the
 * `@RawRes` overload below is more convenient.
 *
 * @param lottieSpec the Lottie source of the step illustration.
 * @param iterations how many times the illustration plays; defaults to once. Use
 *   [LottieConstants.IterateForever] to loop.
 */
@Composable
fun IDnowTutorialStep(
    title: String,
    stepNumber: Int,
    lottieSpec: LottieCompositionSpec,
    modifier: Modifier = Modifier,
    description: String? = null,
    indicator: TutorialStepIndicator = TutorialStepIndicator.LARGE,
    iterations: Int = 1,
) {
    val style = IDnowTutorialStepDefaults.style(indicator)
    val composition by rememberLottieComposition(lottieSpec)
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = iterations,
    )
    TutorialStepContent(
        title = title,
        stepNumber = stepNumber,
        description = description,
        style = style,
        modifier = modifier,
    ) {
        IDnowLottieIllustration(
            composition = composition,
            progress = { progress },
            modifier = Modifier.illustrationSize(style),
        )
    }
}

/**
 * Convenience overload for the common case where the step illustration is a `R.raw.*` Lottie
 * resource. Delegates to the [LottieCompositionSpec] overload above.
 *
 * @param lottieRes the `R.raw.*` Lottie illustration of the step.
 * @param iterations how many times the illustration plays; defaults to once. Use
 *   [LottieConstants.IterateForever] to loop.
 */
@Composable
fun IDnowTutorialStep(
    title: String,
    stepNumber: Int,
    @RawRes lottieRes: Int,
    modifier: Modifier = Modifier,
    description: String? = null,
    indicator: TutorialStepIndicator = TutorialStepIndicator.LARGE,
    iterations: Int = 1,
) = IDnowTutorialStep(
    title = title,
    stepNumber = stepNumber,
    lottieSpec = LottieCompositionSpec.RawRes(lottieRes),
    modifier = modifier,
    description = description,
    indicator = indicator,
    iterations = iterations,
)

/**
 * Layout core, shared by the public composable and previews. Kept slot-based only so previews can
 * stand in a placeholder for the Lottie (the library has no raw Lottie resource of its own).
 */
@Composable
private fun TutorialStepContent(
    title: String,
    stepNumber: Int,
    description: String?,
    style: IDnowTutorialStepStyle,
    modifier: Modifier = Modifier,
    illustration: @Composable () -> Unit,
) {
    val contentDesc = remember(stepNumber, title, description) {
        buildString {
            append("$stepNumber. ")
            if (title.isNotEmpty()) append("$title${if (!title.endsWith(".")) "." else ""} ")
            description?.takeIf { it.isNotEmpty() }
                ?.let { append("$it${if (!it.endsWith(".")) "." else ""} ") }
        }
    }

    Row(
        modifier = modifier.clearAndSetSemantics { contentDescription = contentDesc }
    ) {
        // Leading cluster: in large mode the big number sits at the start and the illustration is
        // pushed right by `numberGap`, so the two overlap exactly like the XML (idn_space + idn_lottie).
        // It stays top-anchored (Row default) so a taller text block doesn't drag the illustration down.
        Box {
            if (style.showStepNumber) {
                // The 120sp glyph has a taller line box than the 106dp illustration. Clamp the number's
                // layout to the illustration height and clip the line-box overflow, so its bounds match
                // the illustration exactly — mirrors the XML fixed-height (106dp) number view.
                BasicText(
                    text = stepNumber.toString(),
                    modifier = style.illustrationHeight
                        ?.let { Modifier.height(it).clipToBounds() }
                        ?: Modifier,
                    style = style.stepNumberTextStyle,
                )
            }
            Box(modifier = Modifier.padding(start = style.numberGap)) {
                illustration()
            }
        }

        Spacer(Modifier.width(style.contentSpacing))

        // Text block is vertically centered within the row height, mirroring the XML packed chain.
        Column(
            modifier = Modifier
                .weight(1f)
                .align(Alignment.CenterVertically),
        ) {
            BasicText(
                text = if (style.isStepNumberInline) inlineTitle(stepNumber, title, style.accentColor)
                else AnnotatedString(title),
                style = style.titleTextStyle,
            )
            if (!description.isNullOrEmpty()) {
                Spacer(Modifier.height(style.descriptionSpacing))
                BasicText(text = description, style = style.descriptionTextStyle)
            }
        }
    }
}

/** Apply the illustration size carried by [style] (width + optional fixed height). */
private fun Modifier.illustrationSize(style: IDnowTutorialStepStyle): Modifier {
    val sized = width(style.illustrationWidth)
    return style.illustrationHeight?.let { sized.height(it) } ?: sized
}

/** Reproduce the XML SpannableString: colored `"$n."` prefix + plain title. */
private fun inlineTitle(stepNumber: Int, title: CharSequence, accent: Color): AnnotatedString =
    buildAnnotatedString {
        withStyle(SpanStyle(color = accent)) { append("$stepNumber.") }
        append(" ")
        append(title.toString())
    }

// ---------------------------------------------------------------------------
// Previews (no Lottie dependency — gray placeholder for the illustration).
// ---------------------------------------------------------------------------

@Preview(name = "Large", showBackground = true)
@Composable
private fun PreviewLarge() {
    TutorialStepContent(
        title = "Take a video selfie",
        stepNumber = 1,
        description = "We need to verify it's really you.",
        style = IDnowTutorialStepDefaults.style(TutorialStepIndicator.LARGE),
    ) { Box(Modifier.size(106.dp).background(Color.Gray)) }
}

@Preview(name = "Inline", showBackground = true)
@Composable
private fun PreviewInline() {
    TutorialStepContent(
        title = "Take a video selfie",
        stepNumber = 2,
        description = "We need to verify it's really you.",
        style = IDnowTutorialStepDefaults.style(TutorialStepIndicator.INLINE),
    ) { Box(Modifier.size(94.dp).background(Color.Gray)) }
}
