package io.idnow.designsystem.compose_components.app_components.layout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.isTraversalGroup
import androidx.compose.ui.semantics.semantics
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.compose_components.app_components.footer.IDnowFooter
import io.idnow.designsystem.compose_components.app_components.header.IDnowHeader
import io.idnow.designsystem.compose_components.app_components.header.IDnowHeaderIcon
import io.idnow.designsystem.compose_components.extension.composeColor

/**
 * Compose counterpart of the XML `IDnowConstraintLayout`: a full-screen container that optionally
 * shows an [IDnowHeader] at the top and an [IDnowFooter] at the bottom, with [content] filling the
 * space in between. Background is a [BackgroundColorEnum] token; system-bar and display-cutout insets
 * are always consumed as padding (like the XML view) so the background paints behind the bars.
 *
 * The header icons are exposed as [IDnowHeaderIcon] and forwarded to the embedded [IDnowHeader].
 *
 * Accessibility — `traversalAfter`-style ordering of the close (✕): the layout is one traversal group
 * and the header is dropped out of its own group (`isTraversalGroup = false`), so a header icon's
 * [IDnowHeaderIcon.readingOrder] is sorted against the page content rather than only against the other
 * header icons. Give the ✕ a [IDnowHeaderIcon.readingOrder] above the content's default `0` (e.g.
 * `1f`) and a screen reader announces it **last**, while a back/menu icon left at `null` is still read
 * first. This mirrors XML `android:accessibilityTraversalAfter` for a single element. The content is
 * sealed in its own traversal group so it sorts as one self-contained block in the outer group.
 * (Link-bearing [io.idnow.designsystem.compose_components.text_view.IDnowText] handles its own
 * traversal safety internally.)
 *
 * @param showHeader / [showFooter] toggle the header / footer.
 */
@Composable
fun IDnowLayout(
    modifier: Modifier = Modifier,
    backgroundColor: BackgroundColorEnum = BackgroundColorEnum.PRIMARY,
    showHeader: Boolean = false,
    showFooter: Boolean = false,
    headerBrand: Boolean = false,
    headerStartIcon: IDnowHeaderIcon? = null,
    headerEndIcon: IDnowHeaderIcon? = null,
    headerAdditionalEndIcon: IDnowHeaderIcon? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundColor.composeColor)
            .windowInsetsPadding(WindowInsets.systemBars.union(WindowInsets.displayCutout))
            // Outer group: scopes the header ✕'s readingOrder so it sorts against the content below.
            .semantics { isTraversalGroup = true },
    ) {
        if (showHeader) {
            IDnowHeader(
                // Drop the header out of its own group so the close ✕'s readingOrder is sorted against
                // the content in the outer group, not just within the bar (traversalAfter-style).
                isTraversalGroup = false,
                brand = headerBrand,
                startIcon = headerStartIcon,
                endIcon = headerEndIcon,
                additionalEndIcon = headerAdditionalEndIcon,
            )
        }
        // Content fills the space between header and footer, pinning the footer to the bottom.
        // Sealed as its own traversal group so it sorts as one block before the ✕ in the outer group.
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .semantics { isTraversalGroup = true },
            content = content,
        )
        if (showFooter) IDnowFooter()
    }
}
