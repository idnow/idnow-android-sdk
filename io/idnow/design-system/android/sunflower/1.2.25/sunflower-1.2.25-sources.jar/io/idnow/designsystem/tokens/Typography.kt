package io.idnow.designsystem.tokens

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.customization.DefaultPrimitives

/**
 * Tokens that can be used by all the text based component.
 */
sealed class Typography {
    /**
     * Typeface to apply to the text.
     */
    abstract val typeface: Typeface

    /**
     * Size of the text.
     */
    abstract val size: Float

    /**
     * Is underlined ?
     */
    open val isUnderlined: Boolean = false

    /**
     * Line height multiplier
     */
    abstract val lineSpacingMultiplier: Float

    data class H1(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.heading, DefaultPrimitives.heading, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize6
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightHeading
    }

    data class H2(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.heading, DefaultPrimitives.heading, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize5
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightHeading
    }

    data class H3(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.heading, DefaultPrimitives.heading, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize4
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightHeading
    }

    data class H4(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.heading, DefaultPrimitives.heading, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize3
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightHeading
    }

    data class H5(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.heading, DefaultPrimitives.heading, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize2
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightHeading
    }

    data class H6(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.heading, DefaultPrimitives.heading, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize1
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightHeading
    }

    data class LinksLarge(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.regular, context)
        override val size: Float = font.fontSize.fontSize3
        override val isUnderlined: Boolean = true
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class Links(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.regular, context)
        override val size: Float = font.fontSize.fontSize1
        override val isUnderlined: Boolean = true
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class LinksSmall(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.regular, context)
        override val size: Float = font.fontSize.fontSize0
        override val isUnderlined: Boolean = true
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class BodyLarge(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.regular, context)
        override val size: Float = font.fontSize.fontSize3
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class Body(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.regular, context)
        override val size: Float = font.fontSize.fontSize1
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class BodySmall(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.regular, context)
        override val size: Float = font.fontSize.fontSize0
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class BodyXSmall(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.regular, context)
        override val size: Float = font.fontSize.fontSize00
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class BodyBoldLarge(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize3
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class BodyBold(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize1
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    data class BodyBoldSmall(val context: Context) : Typography() {
        private val font = IDnowDesignSystem.primitives.font
        override val typeface: Typeface = getTypeface(font.fontFamily.content, DefaultPrimitives.content, font.fontWeight.medium, context)
        override val size: Float = font.fontSize.fontSize0
        override val lineSpacingMultiplier: Float = DefaultPrimitives.lineHeightContent
    }

    /**
     * Retrieve the typeface given by the customer or the default one using the context.
     * Once the font retrieve, get the wanted typeface using the font weight.
     * @param primitives the customer's font (can be empty)
     * @param defaultValue the default font
     * @param fontWeight to font weight used to choose which font file will be used
     * @param context context used to retrieve the typeface from the default value
     * @return the typeface to set to the text.
     * @exception IllegalArgumentException Throw an exception is the configuration is not well defined and that we can't find a font associated to the given weight.
     */
    protected fun getTypeface(primitives: Map<Int, Typeface>?, defaultValue: Map<Int, Int>, fontWeight: Int, context: Context): Typeface {
        val fontMap = primitives ?: defaultValue.mapValues { ResourcesCompat.getFont(context, it.value)!! }
        return fontMap[fontWeight] ?: throw IllegalArgumentException("No font associated to the weight $fontWeight, " +
                "verify the design system configuration and make sure you have a font file associated to the weight you have set.")
    }
}
