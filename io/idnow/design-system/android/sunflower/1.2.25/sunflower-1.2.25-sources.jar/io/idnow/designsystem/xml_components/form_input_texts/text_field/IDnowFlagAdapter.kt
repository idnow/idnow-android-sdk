package io.idnow.designsystem.xml_components.form_input_texts.text_field

import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowFlagItemSelectionItemBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowCountryFlagItem
import io.idnow.designsystem.xml_components.form_input_texts.spinner.IDnowAdapter

class IDnowFlagAdapter(
    private val context: Context,
    private val itemList: List<IDnowCountryFlagItem>
) : IDnowAdapter(context, itemList) {

    override fun getItem(position: Int): IDnowCountryFlagItem = itemList[position]

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding: IdnowFlagItemSelectionItemBinding
        var row = convertView
        if(row == null) {
            val layoutInflater = LayoutInflater.from(context)
            binding = IdnowFlagItemSelectionItemBinding.inflate(layoutInflater, parent, false)
            row = binding.root
        } else {
            binding = IdnowFlagItemSelectionItemBinding.bind(row)
        }
        itemList[position].let { flagItem ->
            flagItem.icon.let {
                binding.idnowItemIcon.apply {
                    val iconSize = resources.getDimension(R.dimen.idnow_icon_size).toInt()
                    layoutParams.applyMargin(context = context, start = Tokens.spacingSm, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
                    layoutParams.width = iconSize
                    layoutParams.height = iconSize
                    setImageResource(it)
                }
            }
            binding.idnContChevron.apply {
                val drawable = ResourcesCompat.getDrawable(resources, R.drawable.sunflower_ic_chevron_up_down, null)
                layoutParams = layoutParams.applyMargin(context, start = FormInputsStyle.flagGroupMargin)
                imageTintList = ColorStateList.valueOf(Tokens.primaryBackground)
                val iconSize = resources.getDimension(R.dimen.idnow_icon_size).toInt()
                drawable?.setBounds(0, 0, iconSize, iconSize)
                setImageDrawable(drawable)
            }
            binding.idnContPhonePrefix.apply {
                layoutParams.applyMargin(context = context, start = FormInputsStyle.flagGroupMargin, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
                text = flagItem.prefix
                val font = ContainerStyle.font(context)
                setTypography(font)
                setTextColor(FormInputsStyle.popupTextColor)
            }
        }

        return row
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = super.getDropDownView(position, convertView, parent)
        itemList[position].let { flagItem ->
            row.contentDescription = "${flagItem.content}, ${flagItem.prefix}"
        }
        return row
    }

    /**
     * Returns the selected item
     */
    fun getSelectedItem(): IDnowCountryFlagItem = itemList[selection]
}