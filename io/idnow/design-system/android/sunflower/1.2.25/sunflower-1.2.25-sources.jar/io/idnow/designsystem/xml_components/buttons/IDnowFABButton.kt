package io.idnow.designsystem.xml_components.buttons

import android.content.Context
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.styles.ButtonStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp

class IDnowFABButton : AppCompatImageButton, IDnowMarginable {
    /** Style, always primary for FAB button */
    private val style: ButtonStyle
    /** Margins */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        style = ButtonStyle.PrimaryButton(context)
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowFABButton)
        /** Handle the component margin. */
        val margin = customArray.getInt(R.styleable.IDnowFABButton_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowFABButton_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowFABButton_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowFABButton_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowFABButton_token_endMargin, -1)
        margins = style.margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        isEnabled = customArray.getBoolean(R.styleable.IDnowFABButton_android_enabled, true)

        customArray.recycle()
        initialize()
    }

    private fun initialize() {
        setupBackground()

        /** Default padding */
        setPadding(Tokens.spacingMd.toDp(context))

        /** Color the drawable */
        drawable.setTint(style.textColor)
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Set a default margin. Update it only if no margin have been already set. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    private fun setupBackground() {
        setBackgroundResource(R.drawable.idnow_button_background)
        (background as StateListDrawable).apply {
            /** Update colors of pressed state */
            customize(solidColor = style.backgroundColor,
                strokeColor = style.strokeColor,
                strokeWidth = style.strokeWidth.toDp(context),
                cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                indexChild = 0,
                innerChild = 0,
                multipleItem = true)
            /** Pressed over view */
            customize(solidColor = Utils.adjustAlpha(style.pressedColor, style.pressedColorOpacity),
                cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                indexChild = 0,
                innerChild = 1,
                multipleItem = true)
            /** Update colors of classic state */
            customize(solidColor = style.backgroundColor,
                strokeColor = style.strokeColor,
                strokeWidth = style.strokeWidth.toDp(context),
                cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                indexChild = 1)
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ButtonStyle.opacity(enabled)
    }
}