package io.idnow.designsystem.xml_components.form_input_texts.text_field

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.util.AttributeSet
import android.view.View
import android.view.ViewTreeObserver
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.AdapterView
import android.widget.EditText
import android.widget.ImageView
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.doOnDetach
import androidx.core.view.doOnLayout
import androidx.core.view.doOnNextLayout
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.databinding.IdnowEdittextBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.xml_components.extension.getMaxLength
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowCountryFlagItem
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowFormInputs


class IDnowTextField : IDnowFormInputs {
    /** Stub binding, replace the view stub with an edit text. */
    private val textBinding: IdnowEdittextBinding = IdnowEdittextBinding.bind(binding.idnField.inflate())
    /** Direct access to the underlying inflated [EditText] */
    private val editText: EditText = textBinding.root

    /** Display or hide the leading icon. */
    var leadingIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(binding.idnContLeadingIcon, value)
        }

    /** Display or hide the trailing icon. */
    var trailingIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(binding.idnContTrailingIcon, value)
        }

    /** Display or hide the flag area. */
    var flagArea: Boolean = false
        set(value) {
            field = value
            binding.idnPhoneSpinner.isVisible = value
            if (value) {
                setupFlagArea()
            }
        }

    /** Set the countries item list to display in the spinner. */
    var countriesFlagList: List<IDnowCountryFlagItem> = emptyList()
        set(value) {
            field = value
            binding.idnPhoneSpinner.adapter = IDnowFlagAdapter(context, value)
        }

    /** Display or hide the clear icon. */
    var clearIcon: Boolean = false
        set(value) {
            field = value
            binding.idnContClear.isVisible = value
        }

    /** Change the edittext text */
    var text: String
        get() = editText.text.toString()
        set(value) = editText.setText(value)

    /** Add an optional tooltip text for accessibility. */
    var tooltipText: String? = null

    /** Change the edittext hint */
    var hint: String
        get() = editText.hint.toString()
        set(value) {
            editText.hint = value
        }

    /** Set this value to receive callback on phone number country prefix change. */
    var onIDnowCountryPrefixChange: (IDnowCountryFlagItem) -> Unit = {}

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowTextField)

        leadingIcon = customArray.getDrawable(R.styleable.IDnowTextField_leadingIcon)
        val inputType = customArray.getInt(R.styleable.IDnowTextField_android_inputType, InputType.TYPE_CLASS_TEXT)
        val passwordToggleEnabled = customArray.getBoolean(R.styleable.IDnowTextField_passwordToggleEnabled, false)
        flagArea = customArray.getBoolean(R.styleable.IDnowTextField_flagArea, false)
        clearIcon = customArray.getBoolean(R.styleable.IDnowTextField_clearIcon, false)
        isEnabled = customArray.getBoolean(R.styleable.IDnowTextField_android_enabled, true)
        text = customArray.getString(R.styleable.IDnowTextField_text) ?: ""
        tooltipText = customArray.getString(R.styleable.IDnowTextField_tooltipText)
        hint = customArray.getString(R.styleable.IDnowTextField_hint) ?: ""

        customArray.recycle()
        initialize(passwordToggleEnabled, inputType)
    }

    private fun initialize(passwordToggleEnabled: Boolean, inputType: Int) {
        /** To apply the token to all the constraints, we need to update them all with the tokens here. */
        doOnLayout { updateConstraints() }

        /** Set the input type to the edit text. */
        editText.inputType = inputType

        /** Add a trailing icon to show/hide the password is necessary */
        if(passwordToggleEnabled) {
            trailingIcon = ResourcesCompat.getDrawable(resources, R.drawable.sunflower_ic_eye_on, null)
            binding.idnContTrailingIcon.apply {
                togglePassword(false)
                setOnClickListener {
                    isSelected = !isSelected
                    togglePassword(isSelected)
                }
            }
        }

        /** Set a clear action */
        binding.idnContClear.apply {
            contentDescription = context.getString(R.string.sunflower_clear_content_description)
            setOnClickListener {
                editText.text.clear()
            }
        }

        /** Set content description if needed */
        setContentDescription()
    }

    /** Change the transformation method of the text to show/hide the text */
    private fun togglePassword(isSelected: Boolean) {
        with(editText) {
            // Save cursor position
            val selectionStart = selectionStart
            val selectionEnd = selectionEnd
            // Show/Hide the text content
            transformationMethod = if (isSelected) {
                null
            } else {
                PasswordTransformationMethod()
            }
            // Restore the cursor position to have a better UX.
            setSelection(selectionStart, selectionEnd)
            // Update accessibility
            setPasswordContentDescription(isSelected)
        }
    }

    /** Update password content description for Accessibility */
    private fun setPasswordContentDescription(isSelected: Boolean) {
        val (contentDescription, announce) = if(isSelected) {
            context.getString(R.string.sunflower_hide_password_content_description) to context.getString(R.string.sunflower_password_visible)
        } else {
            context.getString(R.string.sunflower_show_password_content_description) to context.getString(R.string.sunflower_password_hidden)
        }
        binding.idnContTrailingIcon.announceForAccessibility(announce)
        binding.idnContTrailingIcon.contentDescription = contentDescription
    }

    private fun updateConstraints() {
        with(FormInputsStyle) {
            editText.apply {
                // Set top and bottom as padding to have more space to click (recommended by Android for accessibility)
                setPadding(itemMargin.toDp(context))
                setTypography(ContainerStyle.font(context))
                setTextColor(ContainerStyle.textColor)
                setHintTextColor(Utils.adjustAlpha(ContainerStyle.textColor, ContainerStyle.hintOpacity))
                // It is not possible to update (without reflection) the cursor color below API 29.
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    textCursorDrawable?.setTint(ContainerStyle.Filling.strokeColor)
                }
            }
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        editText.isEnabled = enabled
        binding.idnPhoneSpinner.isEnabled = enabled
    }

    /** Expose the edittext to allow the use of specific edittext callbacks. */
    fun editText(): EditText = editText

    /** Expose the selected country prefix to be retrieved without callback */
    fun getSelectedCountry(): IDnowCountryFlagItem = (binding.idnPhoneSpinner.adapter as IDnowFlagAdapter).getSelectedItem()

    fun setSelectedItem(flagItem: IDnowCountryFlagItem) {
        // We can select an item only if their is a flag area.
        if(!flagArea) return
        val index = countriesFlagList.indexOf(flagItem).takeIf { it != -1 } ?: 0
        binding.idnPhoneSpinner.setSelection(index)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFlagArea() {
        with(FormInputsStyle) {
            binding.idnPhoneSpinner.apply {
                /** Prepare the focus of the view by registering it to be focus on newt windows focus change if it was pressed*/
                setOnTouchListener { _, _ ->
                    binding.idnContainer.requestFocus()
                    findViewById<ImageView>(R.id.idn_cont_chevron)?.isSelected = true
                    false
                }

                val phoneSpinnerFocusObserver = ViewTreeObserver.OnWindowFocusChangeListener { isWindowFocus ->
                    if(isWindowFocus) {
                        findViewById<ImageView>(R.id.idn_cont_chevron)?.isSelected = false
                    }
                }
                viewTreeObserver.addOnWindowFocusChangeListener(phoneSpinnerFocusObserver)
                doOnDetach { viewTreeObserver.removeOnWindowFocusChangeListener(phoneSpinnerFocusObserver) }

                /** Update the drop down style */
                (popupBackground as GradientDrawable).apply {
                    cornerRadius = ContainerStyle.cornerRadius.toDp(context).toFloat()
                    setStroke(strokeWidth.toDp(context), popupBackgroundColor)
                    setColor(popupBackgroundColor)
                }
                /** Transmit the on item selected callback and update the adapter to show a check in the dropdown */
                onItemSelectedListener =  object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        (adapter as IDnowFlagAdapter).apply {
                            selection = position
                            /** Send callback of text changed if prefix was updated */
                            onIDnowCountryPrefixChange(getSelectedItem())
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) { /* Do nothing here */ }
                }
                doOnNextLayout {
                    dropDownWidth = binding.idnContainer.width
                    // TODO We may improve this to make it work also when displayed on top.
                    dropDownVerticalOffset = binding.idnContainer.height
                }
                accessibilityDelegate = object : AccessibilityDelegate() {
                    override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfo) {
                        super.onInitializeAccessibilityNodeInfo(host, info)
                        val selected = getSelectedCountry()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            info.hintText = "${selected.content}, ${selected.prefix}"
                        } else {
                            info.contentDescription = "${context.getString(R.string.sunflower_flag_content_description)} " +
                                    "${selected.content}, ${selected.prefix}"
                        }
                    }
                }
            }
        }
    }


    override fun setContentDescription() {
        @Suppress("SENSELESS_COMPARISON") // Wrong it will be null when first called and in some other cases.
        if (editText == null) return
        ViewCompat.setAccessibilityDelegate(editText, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.text = getAccessibilityContentText() + info.text
                editText.getMaxLength()?.let {
                    info.maxTextLength = getAccessibilityContentText().length + it
                }
                tooltipText?.let { info.tooltipText = it }
            }
        })
    }

    override fun onDetachedFromWindow() {
        onIDnowCountryPrefixChange = {}
        super.onDetachedFromWindow()
    }
}