package io.idnow.designsystem.common

import android.graphics.Color
import androidx.annotation.ColorInt
import kotlin.math.roundToInt

internal object Utils {

    @ColorInt
    internal fun adjustAlpha(@ColorInt color: Int, factor: Float): Int {
        val alpha = (Color.alpha(color) * factor).roundToInt()
        val red = Color.red(color)
        val green = Color.green(color)
        val blue = Color.blue(color)
        return Color.argb(alpha, red, green, blue)
    }
}