package io.idnow.designsystem.xml_components.buttons

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.ProgressBar
import androidx.appcompat.widget.AppCompatButton
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.doOnLayout
import androidx.core.view.doOnNextLayout
import androidx.core.view.updatePaddingRelative
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.styles.ButtonStyle
import io.idnow.designsystem.xml_components.extension.allParents
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp
import kotlin.math.ceil
import kotlin.math.max

class IDnowButton : AppCompatButton, IDnowMarginable {
    /** Button style */
    private var style: ButtonStyle
    /** Store a progress bar to remove it when loading is done */
    private var progress: ProgressBar? = null
    /** Change button state to loading state. */
    var isLoading: Boolean = false
        set(value) {
            field = value
            doOnLayout { changeLoadingState(value) }
        }
    /** Keep a loading state to only change the button visibility when loading is done. */
    private var loadingState = LoadingState.IDLE

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /**
     * Should request focus on loading.
     * This must set before called before setting a view to loading.
     */
    var requestFocusOnLoading = false

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowButton)
        val drawableStart = customArray.getDrawable(R.styleable.IDnowButton_android_drawableStart)
        val drawableEnd = customArray.getDrawable(R.styleable.IDnowButton_android_drawableEnd)
        val loading = customArray.getBoolean(R.styleable.IDnowButton_loading, false)
        val attrStyle = ButtonType.entries[customArray.getInt(R.styleable.IDnowButton_style, ButtonType.PRIMARY.ordinal)]
        style = when(attrStyle) {
            ButtonType.PRIMARY -> ButtonStyle.PrimaryButton(context)
            ButtonType.SECONDARY -> ButtonStyle.SecondaryButton(context)
            ButtonType.DANGER -> ButtonStyle.DangerButton(context)
        }

        /** Handle the component margin. */
        val margin = customArray.getInt(R.styleable.IDnowButton_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowButton_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowButton_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowButton_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowButton_token_endMargin, -1)
        margins = style.margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)

        customArray.recycle()
        val compoundDrawable = drawableStart ?: drawableEnd
        initialize(compoundDrawable, drawableEnd == null , loading)
    }

    private fun initialize(compoundDrawable: Drawable?, isStart: Boolean, loading: Boolean) {
        /** Set and customize the background */
        setupBackground()

        /** Customize the text */
        setupTextStyle()

        /** Default padding */
        val padding = style.paddings
        setPaddingRelative(padding.start.value.toDp(context), padding.top.value.toDp(context), padding.end.value.toDp(context), padding.bottom.value.toDp(context))

        /** Add padding to center the compound drawable */
        compoundDrawable?.let {

            setCompoundDrawablesRelative(if(isStart) it else null, null, if(!isStart) it else null, null)
        }

        /** Switch view to loading mode */
        if(loading) isLoading = true
    }

    private fun setupBackground() {
        setBackgroundResource(R.drawable.idnow_button_background)
        (background as StateListDrawable).apply {
            /** Update colors of pressed state */
            customize(solidColor = style.backgroundColor,
                strokeColor = style.strokeColor,
                strokeWidth = style.strokeWidth.toDp(context),
                cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                indexChild = 0,
                innerChild = 0,
                multipleItem = true)
            /** Pressed over view */
            customize(solidColor = Utils.adjustAlpha(style.pressedColor, style.pressedColorOpacity),
                cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                indexChild = 0,
                innerChild = 1,
                multipleItem = true)
            /** Update colors of classic state*/
            customize(solidColor = style.backgroundColor,
                strokeColor = style.strokeColor,
                strokeWidth = style.strokeWidth.toDp(context),
                cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                indexChild = 1)
        }
    }

    private fun setupTextStyle() {
        textAlignment = TEXT_ALIGNMENT_CENTER
        gravity = Gravity.CENTER
        setTextColor(style.textColor)
        setTypography(style.typography)
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    fun setStyle(style: ButtonType) {
        if(style == ButtonType.PRIMARY) {
            this.style = ButtonStyle.PrimaryButton(context)
        } else {
            this.style = ButtonStyle.SecondaryButton(context)
        }
        /** Set and customize the background */
        setupBackground()
        /** Customize the text */
        setupTextStyle()
        /** Add padding to center the compound drawable */
        setCompoundDrawablesRelative(compoundDrawables[0], compoundDrawables[1], compoundDrawables[2], compoundDrawables[3])
    }

    override fun getMaxWidth(): Int {
        return style.maxWidth.toDp(context)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ButtonStyle.opacity(enabled)
    }

    private fun getTextLayoutWidth(singleLine: Boolean = false): Int {
        var maxWidth = 0f
        for (line in 0 until lineCount) {
            if(singleLine) {
                maxWidth += layout.getLineWidth(line)
            } else {
                maxWidth = max(maxWidth, layout.getLineWidth(line))
            }
        }
        return ceil(maxWidth).toInt()
    }

    override fun setCompoundDrawables(left: Drawable?, top: Drawable?, right: Drawable?, bottom: Drawable?) {
        /** Do nothing. Please use the relatives drawable. */
    }

    override fun setCompoundDrawablesRelative(start: Drawable?, top: Drawable?, end: Drawable?, bottom: Drawable?) {
        start?.resize()
        end?.resize()
        super.setCompoundDrawablesRelative(start, top, end, bottom)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        packedDrawable()
    }

    private fun packedDrawable() {
        if(measuredWidth == 0 || getTextLayoutWidth(singleLine = true) == 0) return
        val drawable = compoundDrawablesRelative[0] ?: compoundDrawablesRelative[2] ?: return
        // First update the drawable color
        drawable.setTint(style.textColor)
        // Then place it on the next layout iteration
        val iconSize = drawable.intrinsicWidth
        val iconPadding = if(text.isEmpty()) 0 else style.iconPadding.toDp(context)
        var textWidth = getTextLayoutWidth(singleLine = true)
        if(measuredWidth - iconSize - iconPadding < textWidth) {
            textWidth = getTextLayoutWidth(singleLine = false)
        }
        val emptyWidth = (measuredWidth - textWidth - iconSize - iconPadding)
        val padding = emptyWidth / 2
        updatePaddingRelative(padding, style.paddings.top.value.toDp(context), padding, style.paddings.bottom.value.toDp(context))
    }

    /**
     * Add a loading view in top of the button and temporarily hide the button.
     * The button is shown again when the loading state is removed.
     * @param isLoading to show/hide the loading view.
     */
    private fun changeLoadingState(isLoading: Boolean) {
        when(loadingState) {
            LoadingState.IDLE -> if(isLoading) {
                visibility = View.INVISIBLE
                loadingState = LoadingState.LOADING
                progress = ProgressBar(context).apply {
                    id = R.id.idn_loading_id
                    background = this@IDnowButton.background
                    indeterminateTintList = ColorStateList.valueOf(style.textColor)
                    setPadding(0, style.iconPadding.toDp(context), 0, style.iconPadding.toDp(context))
                    alpha = 0.5f
                }
                if(id == -1) id = R.id.idn_button_loading_id
                val constraintLayoutParams = ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_CONSTRAINT, ConstraintLayout.LayoutParams.MATCH_CONSTRAINT)
                    .allParents(id)
                (parent as ViewGroup).addView(progress, constraintLayoutParams)
                if(requestFocusOnLoading) {
                    progress?.let {
                        it.requestFocus()
                        it.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
                    }
                }
            }
            LoadingState.LOADING -> if(!isLoading) {
                loadingState = LoadingState.IDLE
                visibility = View.VISIBLE
                progress?.let{ (parent as ViewGroup).removeView(it) }
            }
        }
    }

    /**
     * Resize compound drawable to apply fixed size and padding
     */
    private fun Drawable.resize() {
        val iconSize = resources.getDimension(R.dimen.idnow_icon_size).toInt()
        compoundDrawablePadding = style.iconPadding.toDp(context)
        setBounds(0, 0, iconSize, iconSize)
    }
}

enum class ButtonType { PRIMARY, SECONDARY, DANGER }

internal enum class LoadingState { LOADING, IDLE }