package io.idnow.designsystem.styles.compose

import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.idnow.designsystem.R
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.xml_components.tutorial_step.TutorialStepIndicator

/**
 * Fully-resolved visual values for [IDnowTutorialStep].
 *
 * Compose mirror of the XML [io.idnow.designsystem.styles.xml.TutorialStepStyle] sealed class
 * (+ the `idnow_tutorial_step_*` dimens and the step-number/accent token colors). All values
 * are resolved from tokens in [IDnowTutorialStepDefaults.style] so the two worlds stay in sync.
 */
@Immutable
data class IDnowTutorialStepStyle(
    /** When true the step number is shown inline as a colored title prefix instead of a large glyph. */
    val isStepNumberInline: Boolean,
    /** Illustration (Lottie) width. */
    val illustrationWidth: Dp,
    /** Illustration height; `null` means wrap content (inline mode). */
    val illustrationHeight: Dp?,
    /** Horizontal gap reserved before the illustration in large mode (the XML `idn_space`). */
    val numberGap: Dp,
    /** Text style of the large step-number glyph. */
    val stepNumberTextStyle: TextStyle,
    /**
     * Amount to pull the large step-number glyph up so its ink top is flush with the top of its box.
     * The number font reserves empty space above the cap height inside its ascent metric, so even
     * with `includeFontPadding=false` the digit is not top-flush; this is the ascent→ink gap to
     * negate. `0.dp` in inline mode. Mirrors the XML `clampStepNumberInkToTop()`.
     */
    val stepNumberTopTrim: Dp,
    /** Opacity of the large step-number glyph (`0.4` in large mode). Mirrors the XML `android:alpha`. */
    val stepNumberOpacity: Float,
    /** Color of the inline `"$n."` title prefix. */
    val accentColor: Color,
    /** Title text style. */
    val titleTextStyle: TextStyle,
    /** Description text style. */
    val descriptionTextStyle: TextStyle,
    /** Spacing between the illustration cluster and the text column (XML title `SPACING_MD` start margin). */
    val contentSpacing: Dp,
    /** Spacing between title and description (XML description `SPACING_SM` top margin). */
    val descriptionSpacing: Dp,
) {
    /** Large mode shows the big step-number glyph. */
    val showStepNumber: Boolean get() = !isStepNumberInline
}

/** Default resolver for [IDnowTutorialStepStyle], analogous to Material3's `XxxDefaults`. */
object IDnowTutorialStepDefaults {

    @Composable
    fun style(indicator: TutorialStepIndicator): IDnowTutorialStepStyle {
        val inline = indicator == TutorialStepIndicator.INLINE
        val largeIconSize = dimensionResource(R.dimen.idnow_tutorial_step_large_icon_size)
        val inlineIconSize = dimensionResource(R.dimen.idnow_tutorial_step_inline_icon_size)
        val largeIconMargin = dimensionResource(R.dimen.idnow_tutorial_step_large_icon_margin)

        // Measure the ascent→ink gap of the number font at 120sp with the token-resolved typeface,
        // so the glyph can be pulled up to be top-flush — mirrors the XML `clampStepNumberInkToTop`.
        val context = LocalContext.current
        val density = LocalDensity.current
        val stepNumberTopTrim = if (inline) 0.dp else remember(IDnowDesignSystem.primitives, density) {
            val paint = Paint().apply {
                typeface = TypographyEnum.H1.toTypography(context).typeface
                textSize = with(density) { 120.sp.toPx() }
            }
            val ink = Rect().also { paint.getTextBounds("0", 0, 1, it) }
            // ascent is negative (px above baseline); ink.top is negative (ink top above baseline).
            // gap = |ascent| - |inkTop| = ink.top - ascent (>= 0).
            with(density) { (ink.top - paint.fontMetrics.ascent).coerceAtLeast(0f).toDp() }
        }

        return IDnowTutorialStepStyle(
            isStepNumberInline = inline,
            illustrationWidth = if (inline) inlineIconSize else largeIconSize,
            illustrationHeight = if (inline) null else largeIconSize,
            numberGap = if (inline) 0.dp else largeIconMargin,
            stepNumberTextStyle = TypographyEnum.H1
                .asTextStyle(color = TintColorEnum.ACCENT_VARIANT.composeColor)
                // dimen idnow_tutorial_step_large_text_size = 120sp; the XML number sets includeFontPadding=false.
                .copy(
                    fontSize = 120.sp,
                    lineHeight = 120.sp,
                    platformStyle = PlatformTextStyle(includeFontPadding = false),
                ),
            stepNumberTopTrim = stepNumberTopTrim,
            stepNumberOpacity = if (inline) 1f else 0.4f,
            accentColor = TintColorEnum.ACCENT.composeColor,
            titleTextStyle = TypographyEnum.H5.asTextStyle(color = TextColorEnum.HEADING.composeColor),
            descriptionTextStyle = TypographyEnum.BODY.asTextStyle(color = TextColorEnum.BODY.composeColor),
            contentSpacing = SpacingEnum.SPACING_MD.dp,
            descriptionSpacing = SpacingEnum.SPACING_SM.dp,
        )
    }
}
