package io.idnow.designsystem.customization

data class FontWeight(
    val default: Int = DefaultPrimitives.default,
    val prominent: Int = DefaultPrimitives.prominent,
) {
    @Deprecated(
        "Parameter has been renamed to default.",
        ReplaceWith("default")
    )
    val regular: Int get() = default

    @Deprecated(
        "Parameter has been renamed to prominent.",
        ReplaceWith("prominent")
    )
    val medium: Int get() = prominent

    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            regular: Int? = null,
            medium: Int? = null,
            default: Int? = null,
            prominent: Int? = null
        ) = FontWeight(
            default = regular ?: default ?: DefaultPrimitives.default,
            prominent = medium ?: prominent ?: DefaultPrimitives.prominent
        )
    }
}
