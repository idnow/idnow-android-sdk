package io.idnow.designsystem.customization

import androidx.annotation.Dimension
import io.idnow.designsystem.R

internal object DefaultPrimitives {
    /** Brand colors default values */
    const val primary: Int = 0xFFFB5E31.toInt()
    const val primaryVariant: Int = 0xFFFB5E31.toInt()
    const val secondary: Int = 0xFF456090.toInt()
    const val secondaryVariant: Int = 0xFF8DA8D9.toInt()
    const val error: Int = 0xFFE51520.toInt()
    const val processing: Int = 0xFFF6B500.toInt()
    const val success: Int = 0xFF2DAA52.toInt()
    const val active: Int = 0xFF38B0D1.toInt()

    /** Grey colors default values */
    const val grey100: Int = 0xFFFFFFFF.toInt()
    const val grey200: Int = 0xFFEEEEEE.toInt()
    const val grey300: Int = 0xFFDEDEDE.toInt()
    const val grey400: Int = 0xFFB6B6B6.toInt()
    const val grey500: Int = 0xFF85878E.toInt()
    const val grey600: Int = 0xFF555862.toInt()
    const val grey800: Int = 0xFF313542.toInt()
    const val grey900: Int = 0xFF02050A.toInt()

    /** Radius default values */
    @Dimension(unit = Dimension.DP)
    const val radius1 = 4
    @Dimension(unit = Dimension.DP)
    const val radius2 = 8
    @Dimension(unit = Dimension.DP)
    const val radius3 = 16
    @Dimension(unit = Dimension.DP)
    const val radius4 = 400

    /** Spacing default values */
    @Dimension(unit = Dimension.DP)
    const val spacing0_5 = 4
    @Dimension(unit = Dimension.DP)
    const val spacing1 = 8
    @Dimension(unit = Dimension.DP)
    const val spacing2 = 16
    @Dimension(unit = Dimension.DP)
    const val spacing3 = 24
    @Dimension(unit = Dimension.DP)
    const val spacing4 = 32
    @Dimension(unit = Dimension.DP)
    const val spacing5 = 40
    @Dimension(unit = Dimension.DP)
    const val spacing6 = 48

    /** Font weight default values */
    const val default = 500
    const val prominent = 700

    /** Font family default values */
    val heading = mapOf(Pair(default, R.font.red_hat_display_medium), Pair(prominent, R.font.red_hat_display_bold))
    val content = mapOf(Pair(default, R.font.red_hat_display_medium), Pair(prominent, R.font.red_hat_display_bold))

    /** Font size default values */
    const val remMultiplier = 16
    @Dimension(unit = Dimension.SP)
    const val fontSize00 = 0.875f
    @Dimension(unit = Dimension.SP)
    const val fontSize0 = 1f
    @Dimension(unit = Dimension.SP)
    const val fontSize1 = 1.125f
    @Dimension(unit = Dimension.SP)
    const val fontSize2 = 1.266f
    @Dimension(unit = Dimension.SP)
    const val fontSize3 = 1.424f
    @Dimension(unit = Dimension.SP)
    const val fontSize4 = 1.602f
    @Dimension(unit = Dimension.SP)
    const val fontSize5 = 1.802f
    @Dimension(unit = Dimension.SP)
    const val fontSize6 = 2.027f

    /** Line height */
    const val lineHeightHeading = 1.1f
    const val lineHeightContent = 1.2f
}