package io.idnow.designsystem.xml_components.extension


import android.content.Context
import android.content.res.ColorStateList
import android.content.res.TypedArray
import android.graphics.Rect
import android.graphics.drawable.DrawableContainer
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.graphics.drawable.VectorDrawable
import android.os.Build
import android.text.InputFilter
import android.util.AttributeSet
import android.util.TypedValue
import android.util.TypedValue.COMPLEX_UNIT_DIP
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.Px
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.view.updatePaddingRelative
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.tokens.Typography

/**
 * Set a typography to a TextView.
 * It will apply typeface, text size and can underline text.
 * @param typography the typography to apply.
 */
internal fun TextView.setTypography(typography: Typography) {
    typeface = typography.typeface
    textSize = typography.size

    val fontScale = resources.configuration.fontScale
    val density = resources.displayMetrics.density
    val lineHeightPx = typography.size * typography.lineSpacingMultiplier * density * fontScale
    setLineSpacing(lineHeightPx, 0f)

    paint.isUnderlineText = typography.isUnderlined
}



internal fun Int.toDp(context: Context): Int {
    if (this == 0) return 0
    return TypedValue.applyDimension(COMPLEX_UNIT_DIP, this + 0.5f, context.resources.displayMetrics).toInt()
}

internal fun Float.toDp(context: Context): Int {
    if (this == 0f) return 0
    return TypedValue.applyDimension(COMPLEX_UNIT_DIP, this + 0.5f, context.resources.displayMetrics).toInt()
}

/**
 * Set the solid color of the given child.
 * @param solidColor the color to apply to the solid
 * @param strokeColor the color to apply to the stroke
 * @param strokeWidth the width to apply to the stroke
 * @param cornerRadius the radius to apply to the corners
 * @param indexChild (optional) the wanted item in the selector
 * @param multipleItem set to true if an item contains a layer list with multiple sub items
 * @param innerChild only useful is set to true, this is the index of the wanted sub item
 * @param bounds apply a fixed size to the item
 */
internal fun StateListDrawable.customize(
    solidColor: Int? = null, strokeColor: Int? = null, strokeWidth: Int = 0, cornerRadius: Float? = null,
    indexChild: Int = 0, multipleItem: Boolean = false, innerChild: Int = 0, bounds: Rect? = null,
    solidColorStateList: ColorStateList? = null,
) {
    val boxDrawableContainerState = constantState as DrawableContainer.DrawableContainerState
    val boxChildren = boxDrawableContainerState.children
    val boxSelectedItem = if (!multipleItem) {
        boxChildren[indexChild]
    } else {
        val layer = boxChildren[indexChild] as LayerDrawable
        /** Some drawable such as [VectorDrawable] doesn't have an API to update their size dynamically, so we need to do it at the layers level. */
        bounds?.let { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) layer.setLayerSize(innerChild, it.right, it.bottom) }
        layer.getDrawable(innerChild)
    }
    when (boxSelectedItem) {
        is GradientDrawable -> boxSelectedItem.customize(solidColor, strokeColor, strokeWidth, cornerRadius, bounds, solidColorStateList)
        is VectorDrawable -> boxSelectedItem.customize(solidColor, solidColorStateList)
    }
}

/**
 * Apply the customisation to a [GradientDrawable]
 * @param solidColor the color to apply to the solid
 * @param strokeColor the color to apply to the stroke
 * @param strokeWidth the width to apply to the stroke
 * @param cornerRadius the radius to apply to the corners
 */
fun GradientDrawable.customize(
    solidColor: Int? = null, strokeColor: Int? = null, strokeWidth: Int = 0,
    cornerRadius: Float? = null, bounds: Rect? = null, solidColorStateList: ColorStateList? = null,
) {
    solidColor?.let { setColor(it) }
    solidColorStateList?.let { color = it }
    strokeColor?.let { setStroke(strokeWidth, it) }
    cornerRadius?.let { setCornerRadius(it) }
    bounds?.let { setSize(it.width(), it.height()) }
}

/**
 * Apply the customisation to a [GradientDrawable]
 * @param solidColor the color to apply to the solid
 */
private fun VectorDrawable.customize(solidColor: Int? = null, solidColorStateList: ColorStateList? = null) {
    solidColor?.let { setTint(solidColor) }
    solidColorStateList?.let { setTintList(it) }
}

internal fun ConstraintLayout.LayoutParams.allParents(id: Int?): ConstraintLayout.LayoutParams {
    topToTop = id ?: ConstraintLayout.LayoutParams.PARENT_ID
    bottomToBottom = id ?: ConstraintLayout.LayoutParams.PARENT_ID
    startToStart = id ?: ConstraintLayout.LayoutParams.PARENT_ID
    endToEnd = id ?: ConstraintLayout.LayoutParams.PARENT_ID
    return this
}

/**
 * Apply margin to a layout params.
 * It takes a [SpacingQuad], transforms it's values to DP and applies it to the correct side.
 */
internal fun ViewGroup.LayoutParams.applyMargin(context: Context, spacing: SpacingQuad): ViewGroup.LayoutParams = with(spacing) {
    applyMargin(context = context, start = start.value, top = top.value, end = end.value, bottom = bottom.value)
}

/**
 * Apply padding to a [View].
 * It takes a [SpacingQuad], transforms it's values to DP and applies it to the correct side.
 */
internal fun View.updatePadding(spacing: SpacingQuad) {
    with(spacing) {
        updatePaddingRelative(
            start = start.value.toDp(context),
            top = top.value.toDp(context),
            end = end.value.toDp(context),
            bottom = bottom.value.toDp(context),
        )
    }
}

/**
 * Apply margin to a layout params.
 * It takes margin in [Px] and transform them to DP
 */
internal fun ViewGroup.LayoutParams.applyMargin(context: Context, start: Int = 0, top: Int = 0, end: Int = 0, bottom: Int = 0): ViewGroup.LayoutParams {
    val params = this as ViewGroup.MarginLayoutParams
    params.setMargins(start.toDp(context), top.toDp(context), end.toDp(context), bottom.toDp(context))
    return params
}

internal fun View.applyPadding(start: Int = 0, top: Int = 0, end: Int = 0, bottom: Int = 0) {
    setPaddingRelative(start.toDp(context), top.toDp(context), end.toDp(context), bottom.toDp(context))
}

internal fun TextView.setTextColor(selectedColor: Int, unSelectedColor: Int) {
    val states = arrayOf(intArrayOf(android.R.attr.state_selected), intArrayOf())
    val colors = intArrayOf(selectedColor, unSelectedColor)
    setTextColor(ColorStateList(states, colors))
}

/** Alias for a lambda with no parameters. */
typealias UnitLambda = () -> Unit

/**
 * Retrieve the max length of an EditText if their is one.
 * @return the max length if it exists, null otherwise.
 */
fun EditText.getMaxLength(): Int? {
    return filters.filterIsInstance<InputFilter.LengthFilter>().firstOrNull()?.max
}

/**
 * Utility method to extract margins without the need to specify the styleable.
 */
internal fun View.extractMargins(attrs: AttributeSet?, default: SpacingEnum? = null, block: (SpacingQuad) -> Unit) {
    // Must be sorted in ascending order, see withStyledAttributes attrs doc
    val attributes = listOf(
        io.idnow.designsystem.R.attr.token_margin,
        io.idnow.designsystem.R.attr.token_topMargin,
        io.idnow.designsystem.R.attr.token_bottomMargin,
        io.idnow.designsystem.R.attr.token_startMargin,
        io.idnow.designsystem.R.attr.token_endMargin,
    ).sorted().toIntArray()

    context.withStyledAttributes(attrs, attributes) {
        block(extractMargins(attributes, default))
    }
}

/**
 * Utility method to extract margins from a component.
 * @param attributes Should pass in the component [io.idnow.designsystem.R.styleable].
 * @param default The default [SpacingEnum] applied for the margins.
 * @return The extracted [SpacingQuad] from the component attributes.
 */
internal fun TypedArray.extractMargins(
    attributes: IntArray,
    default: SpacingEnum? = null,
) = with(this) {
    fun compute(attr: Int, defaultVal: Int = -1) = attributes.indexOf(attr).takeIf { it != -1 }?.let { getInt(it, defaultVal) } ?: -1

    val margin = compute(io.idnow.designsystem.R.attr.token_margin, default?.ordinal ?: -1)
    val topMargin = compute(io.idnow.designsystem.R.attr.token_topMargin)
    val bottomMargin = compute(io.idnow.designsystem.R.attr.token_bottomMargin)
    val startMargin = compute(io.idnow.designsystem.R.attr.token_startMargin)
    val endMargin = compute(io.idnow.designsystem.R.attr.token_endMargin)

    SpacingQuad.fromAttributes(margin, startMargin, topMargin, endMargin, bottomMargin)
}