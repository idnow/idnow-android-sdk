package io.idnow.designsystem.xml_components.tutorial_step

import android.content.Context
import android.graphics.Rect
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowTutorialStepBinding
import io.idnow.designsystem.styles.xml.TutorialStepStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.lottie.IDnowLottieAnimationView
import androidx.core.content.withStyledAttributes

class IDnowTutorialStep: ConstraintLayout, IDnowMarginable {
    /** Inflate the layout into the view. */
    private val binding = IdnowTutorialStepBinding.inflate(LayoutInflater.from(context), this)

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** Add a description of the step below the title. */
    var description: CharSequence? = null
        set(value) {
            field = value
            binding.idnDescription.apply {
                isVisible = !field.isNullOrEmpty()
                text = field
            }
            setContentDescription()
        }

    /** Title of the step. */
    var title: CharSequence = ""
        set(value) {
            field = value
            applyNewText(stepIndicator.style.isStepNumberInline)
            setContentDescription()
        }

    /** Step number. 1 by default. */
    var stepNumber: Int = 1
        set(value) {
            field = value
            if(stepIndicator.style.isStepNumberInline) {
                applyNewText(true)
            } else {
                binding.idnStepNumber.text = field.toString()
                clampStepNumberInkToTop()
            }
            setContentDescription()
        }

    /**
     * Step indicator, large or inline.
     * If inline the step number will be displayed as a prefix of the title.
     * LARGE by default.
     */
    var stepIndicator: TutorialStepIndicator = TutorialStepIndicator.LARGE
        set(value) {
            field = value
            applyNewStyle(field.style)
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowTutorialStep) {
            val margin = getInt(R.styleable.IDnowTutorialStep_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowTutorialStep_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowTutorialStep_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowTutorialStep_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowTutorialStep_token_endMargin, -1)
            margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
            description = getString(R.styleable.IDnowTutorialStep_description)
            title = getString(R.styleable.IDnowTutorialStep_title) ?: ""
            stepNumber = getInt(R.styleable.IDnowTutorialStep_stepNumber, 1)
            stepIndicator = TutorialStepIndicator.entries[getInt(R.styleable.IDnowTutorialStep_stepIndicator, TutorialStepIndicator.LARGE.ordinal)]
        }
        initialize()
    }

    /**
     * Update the step number color token.
     */
    private fun initialize() {
        binding.idnStepNumber.setTextColor(Tokens.accentVariant)
        clampStepNumberInkToTop()
        setContentDescription()
    }

    /**
     * Stick the large step-number glyph to the top of its (fixed-height) view.
     *
     * Even with `includeFontPadding=false`, the number font (Red Hat Display) reserves empty space
     * above the cap height inside its own *ascent* metric, so the digit is not flush with the view
     * top. No XML attribute removes that band: `includeFontPadding` only trims padding beyond the
     * ascent, and `firstBaselineToTopHeight` can only *add* top spacing. So we measure the gap
     * between the ascent line (where the layout top sits) and the glyph's actual ink top, and pull
     * the text up by that amount with a negative top padding. Font-independent.
     *
     * No-op in inline mode, where the big number is hidden.
     */
    private fun clampStepNumberInkToTop() = with(binding.idnStepNumber) {
        if (stepIndicator.style.isStepNumberInline) return
        val glyph = text?.toString().takeUnless { it.isNullOrEmpty() } ?: return
        val ink = Rect().also { paint.getTextBounds(glyph, 0, glyph.length, it) }
        // ascent is negative (px above baseline); ink.top is negative (ink top above baseline).
        // gap = |ascent| - |inkTop| = ink.top - ascent  ( >= 0 ). Pull up by it.
        val gap = (ink.top - paint.fontMetrics.ascent).toInt().coerceAtLeast(0)
        setPadding(paddingLeft, -gap, paddingRight, paddingBottom)
    }

    /**
     * Prefix the title with the step if the step number is inline.
     * Also update the color of the prefix.
     * If not inline just show the title.
     * @param isInline if the step number should be inline or not.
     */
    private fun applyNewText(isInline: Boolean) {
        binding.idnTitle.text = if(isInline) {
            val prefix = "$stepNumber."
            val spannable = SpannableString("$prefix $title")
            spannable.setSpan(
                ForegroundColorSpan(Tokens.accent),
                0,
                prefix.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannable
        } else {
            title
        }
    }

    /**
     * Update the view with the given style.
     * @param style the style to apply.
     */
    private fun applyNewStyle(style: TutorialStepStyle) {
        with(style) { binding.apply {
            idnStepNumber.isVisible = !isStepNumberInline
            idnSpace.isVisible = isSpaceVisible
            idnLottie.layoutParams.apply {
                width = lottieWidth(context)
                height = lottieHeight(context)
            }
            applyNewText(isStepNumberInline)
        }}
        clampStepNumberInkToTop()
    }

    /**
     * Used to retrieve and update the lottie.
     * @return this step [IDnowLottieAnimationView]
     */
    fun lottie() = binding.idnLottie


    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    /** Set a custom description for accessibility. */
    private fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.root, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = accessibilityContentText()
            }
        })
    }

    /** Build the a custom content description for accessibility. */
    private fun accessibilityContentText(): CharSequence {
        return SpannableStringBuilder().apply {
            append("$stepNumber. ")
            if(title.isNotEmpty()) append("$title${if(!title.endsWith(".")) "." else ""} ")
            description?.let { if(it.isNotEmpty()) append("$it${if(!it.endsWith(".")) "." else ""} ") }
        }
    }
}
