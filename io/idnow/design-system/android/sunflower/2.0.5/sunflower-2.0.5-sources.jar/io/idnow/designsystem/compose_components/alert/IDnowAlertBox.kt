package io.idnow.designsystem.compose_components.alert

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import io.idnow.designsystem.R
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.text_view.IDnowText
import io.idnow.designsystem.styles.compose.IDnowAlertDefaults
import io.idnow.designsystem.styles.compose.IDnowAlertType

/**
 * Tokenized alert box, the Compose counterpart of the XML `IDnowAlertBox`.
 *
 * Shows a [message] on an accent-tinted rounded surface whose color is driven by [alertType]
 * (INFO/WARNING/ERROR/SUCCESS), with an optional leading [IDnowAlertType] icon and an optional
 * trailing close action. Colors, typography, corner radius and paddings mirror the XML
 * `AlertBoxAndTagStyle` 1:1.
 *
 * Spacing around the box is applied by the caller through [modifier] (e.g.
 * `Modifier.padding(SpacingEnum.SPACING_MD.dp)`), matching the Compose-migration convention.
 *
 * @param message the alert text (can be HTML text message)
 * @param alertType the semantic type, driving accent color and default leading icon.
 * @param modifier the caller-owned modifier (spacing, width, …).
 * @param showStartIcon whether to show the leading icon (the type's default unless [startIcon] is set).
 * @param startIcon optional override [Painter] for the leading icon; falls back to the type's icon.
 * @param showCloseIcon whether to show the trailing close action.
 * @param onCloseClick invoked when the close action is tapped.
 */
@Composable
fun IDnowAlertBox(
    modifier: Modifier = Modifier,
    message: String,
    alertType: IDnowAlertType = IDnowAlertType.INFO,
    showStartIcon: Boolean = true,
    startIcon: Painter? = null,
    showCloseIcon: Boolean = true,
    onCloseClick: () -> Unit = {},
    onLinkClick: (String) -> Unit = {},
) {
    val style = IDnowAlertDefaults.style(alertType)
    val iconSize = dimensionResource(R.dimen.idnow_icon_size)
    val typeDescription = alertType.accessibilityLabel()
    val closeDescription = stringResource(R.string.sunflower_close_popup)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(style.boxCornerRadius))
            .background(style.boxBackgroundColor)
            .padding(style.boxItemPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Icon + message are merged into a single accessibility node (one focus stop reading
        // "<type> <message>"); the close action below stays a separate focusable node inside the box.
        Row(
            modifier = Modifier
                .weight(1f)
                .clearAndSetSemantics { contentDescription = "$typeDescription $message" },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (showStartIcon) {
                Image(
                    painter = startIcon ?: painterResource(style.typeDrawable),
                    contentDescription = null,
                    colorFilter = ColorFilter.tint(style.accentColor),
                    modifier = Modifier.size(iconSize),
                )
                Spacer(Modifier.width(style.boxItemPadding))
            }
            IDnowText(
                html = message,
                typography = TypographyEnum.BODY_SMALL,
                modifier = Modifier.weight(1f),
                onLinkClick = onLinkClick,
            )
        }

        if (showCloseIcon) {
            Spacer(Modifier.width(style.boxItemPadding))
            Image(
                painter = painterResource(R.drawable.sunflower_ic_cross),
                contentDescription = closeDescription,
                colorFilter = ColorFilter.tint(style.textColor),
                modifier = Modifier
                    .size(iconSize)
                    .clickable(onClick = onCloseClick),
            )
        }
    }
}

/** Localized accessibility prefix for the alert type, matching the XML `accessibilityAlertInfo`. */
@Composable
internal fun IDnowAlertType.accessibilityLabel(): String = stringResource(
    when (this) {
        IDnowAlertType.INFO -> R.string.sunflower_information
        IDnowAlertType.ERROR -> R.string.sunflower_error
        IDnowAlertType.WARNING -> R.string.sunflower_warning
        IDnowAlertType.SUCCESS -> R.string.sunflower_success
    },
)
