package io.idnow.designsystem.common

/**
 * The height a bottom sheet is displayed at when it first appears. Shared by both the XML
 * (`io.idnow.designsystem.xml_components.bottom_sheet.IDnowBottomSheet`) and the Compose
 * (`io.idnow.designsystem.compose_components.bottom_sheet.IDnowBottomSheet`) implementations so the two
 * expose the same states.
 */
enum class BottomSheetStateEnum {
    /** The sheet is as tall as its content (default). */
    WRAP_CONTENT,

    /** The sheet opens covering roughly half the screen height and can be dragged to full height. */
    HALF_EXPANDED,

    /** The sheet opens covering most of the available height. */
    FULLY_EXPANDED,
}