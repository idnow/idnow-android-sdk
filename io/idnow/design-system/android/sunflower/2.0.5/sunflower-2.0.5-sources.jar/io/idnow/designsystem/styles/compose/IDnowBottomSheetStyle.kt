package io.idnow.designsystem.styles.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values the [io.idnow.designsystem.compose_components.bottom_sheet.IDnowBottomSheet]
 * reads from. Mirrors the XML `styles.xml.BottomSheetStyle`: the sheet surface background, the opaque
 * scrim painted behind the sheet, the drag-handle color and the top corner radius.
 *
 * Only token-derived values live here; layout spacings (`SPACING_SM/MD/…`) are applied inline in the
 * composable through `SpacingEnum.*.dp`, the design-system's Compose spacing convention.
 */
@Immutable
data class IDnowBottomSheetStyle(
    val backgroundColor: Color,
    val scrimColor: Color,
    val handleColor: Color,
    val cornerRadius: Dp,
)

/** Default resolver for [IDnowBottomSheetStyle], analogous to Material3's `XxxDefaults`. */
object IDnowBottomSheetDefaults {

    /**
     * Resolve the bottom-sheet style from the current tokens, mapping the same tokens the XML
     * `BottomSheetStyle` uses to their Compose types. The `Tokens.*` reads below happen directly during
     * composition (not inside a `remember`), so each transitively reads the snapshot-backed
     * `IDnowDesignSystem.primitives` and a runtime re-theme recomposes any open sheet automatically.
     */
    @Composable
    fun style(): IDnowBottomSheetStyle {
        return IDnowBottomSheetStyle(
            backgroundColor = Color(Tokens.backgroundPrimary),
            scrimColor = Color(Utils.adjustAlpha(Tokens.backgroundTertiary, 0.2f)),
            handleColor = Color(Tokens.backgroundTertiary),
            cornerRadius = Tokens.radiusLg.dp,
        )
    }
}
