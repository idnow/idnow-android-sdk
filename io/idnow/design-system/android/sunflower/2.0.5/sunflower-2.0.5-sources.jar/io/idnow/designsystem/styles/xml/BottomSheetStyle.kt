package io.idnow.designsystem.styles.xml

import android.content.Context
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.toDp

internal object BottomSheetStyle {
    /** region Internal properties */
    /**
     * Background color of the bottom sheet.
     */
    val backgroundColor get() = Tokens.backgroundPrimary

    /**
     * Opaque color of the scrim shown behind the bottom sheet (replaces the default translucent dim).
     */
    val scrimColor get() = Utils.adjustAlpha(Tokens.backgroundTertiary, 0.2f)

    /**
     * Color of the drag handle (knob) at the top of the bottom sheet.
     */
    val handleColor get() = Tokens.backgroundTertiary

    /** region Internal methods */
    /**
     * Top corner radius (in px) of the bottom sheet.
     */
    fun cornerRadius(context: Context) = Tokens.radiusLg.toDp(context).toFloat()

    /** endregion Internal methods */
}
