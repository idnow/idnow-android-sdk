package io.idnow.designsystem.xml_components.bottom_sheet

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.view.WindowManager
import androidx.annotation.LayoutRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import com.google.android.material.R as MaterialR
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.shape.MaterialShapeDrawable
import io.idnow.designsystem.R
import io.idnow.designsystem.common.BottomSheetStateEnum
import io.idnow.designsystem.databinding.IdnowBottomSheetBinding
import io.idnow.designsystem.styles.xml.BottomSheetStyle
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.gradientDrawable
import androidx.core.graphics.drawable.toDrawable
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

/**
 * This is the idnow bottom sheet dialog. It slides up from the bottom of the screen and shows, from top
 * to bottom: a spacer, a drag handle, and a content placeholder into which the integrator passes a
 * custom layout (via [customView] or the [Builder]). The design-system chrome (rounded top corners,
 * primary background, opaque scrim, drag handle) is provided; the content is entirely caller-defined.
 */
class IDnowBottomSheet private constructor(context: Context) :
    BottomSheetDialog(context, R.style.IDnowBottomSheetDialogStyle) {
    private val binding = IdnowBottomSheetBinding.inflate(LayoutInflater.from(context))

    /**
     * The integrator-supplied content shown inside the sheet. Setting it replaces whatever the content
     * placeholder currently holds; `null` clears it.
     */
    var customView: View? = null
        set(value) {
            field = value
            binding.idnowBottomSheetContentContainer.apply {
                removeAllViews()
                value?.let { addView(it) }
            }
        }

    /** Whether the top-left close button is shown. Hidden by default. */
    var isCloseButtonVisible: Boolean = false
        set(value) {
            field = value
            binding.idnowBottomSheetCloseButton.isVisible = value
            // Anchor the content below the close button when it's shown, otherwise directly below the handle.
            val anchor = if (value) R.id.idnow_bottom_sheet_close_button else R.id.idnow_bottom_sheet_handle
            binding.idnowBottomSheetContentContainer.updateLayoutParams<ConstraintLayout.LayoutParams> {
                topToBottom = anchor
            }
        }

    /** Set an on click listener to the close button; `null` restores the default (dismiss). */
    var closeButtonOnClickListener: OnClickListener? = null
        set(value) {
            field = value
            binding.idnowBottomSheetCloseButton.setOnClickListener(value ?: defaultClickListener)
        }

    /**
     * Whether the opaque design-system gray scrim is painted behind the sheet. When `false`, the sheet
     * keeps the platform's default translucent dim instead. Enabled by default.
     */
    var isScrimVisible: Boolean = true

    /**
     * Whether tapping outside the sheet (on the scrim) dismisses it. Disabled by default. Applied on
     * [onCreate]; set it before the sheet is shown.
     */
    var dismissOnTouchOutside: Boolean = false
        set(value) {
            field = value
            setCanceledOnTouchOutside(value)
        }

    /**
     * The height the sheet is displayed at when it first appears. Defaults to
     * [BottomSheetStateEnum.WRAP_CONTENT] (the sheet is as tall as its content). Applied on
     * [onCreate]; set it before the sheet is shown.
     */
    var initialState: BottomSheetStateEnum = BottomSheetStateEnum.WRAP_CONTENT

    /** Default click listener for the close button. */
    private val defaultClickListener = OnClickListener { dismiss() }

    init {
        binding.idnowBottomSheetCloseButton.setOnClickListener(defaultClickListener)
    }

    /** region Override methods */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        applyBackground()
        applyScrim()
        applyInitialState()
        setCanceledOnTouchOutside(dismissOnTouchOutside)
        //apply padding so content shows above the navigation bar
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.updatePadding(bottom = insets.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    override fun onStart() {
        super.onStart()
        if (initialState == BottomSheetStateEnum.WRAP_CONTENT) return
        behavior.state = when (initialState) {
            BottomSheetStateEnum.HALF_EXPANDED -> BottomSheetBehavior.STATE_HALF_EXPANDED
            else -> BottomSheetBehavior.STATE_EXPANDED
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        //make the bottom sheet appear below the navigation bar
        window?.let {
            WindowCompat.setDecorFitsSystemWindows(it, false)
        }
        findViewById<View>(com.google.android.material.R.id.container)?.apply {
            fitsSystemWindows = false
        }
    }
    /** endregion Override methods */

    /** region Private methods */
    /**
     * Applies the design-system background (primary color + top rounded corners) to the content root,
     * and neutralizes the Material sheet container behind it.
     *
     * The container draws its own opaque [MaterialShapeDrawable], whose corners the
     * [com.google.android.material.bottomsheet.BottomSheetBehavior] flattens to square once the sheet
     * is expanded. We make that drawable transparent (fill + shadow) so the rounded content root is the
     * only visible surface and the corners stay rounded in every sheet state. Setting the fill on the
     * behavior-owned drawable (rather than swapping the whole background) means it survives the
     * behavior re-applying its background on subsequent layout passes.
     */
    private fun applyBackground() {
        val radius = BottomSheetStyle.cornerRadius(context)
        binding.root.background = gradientDrawable {
            color(argb = BottomSheetStyle.backgroundColor)
            cornerRadius {
                topLeft = radius
                topRight = radius
            }
        }
        binding.idnowBottomSheetHandle.background = gradientDrawable {
            color(argb = BottomSheetStyle.handleColor)
            cornerRadius(BottomSheetStyle.cornerRadius(context))
        }
        setOnShowListener {
            val sheet = findViewById<View>(MaterialR.id.design_bottom_sheet)
            (sheet?.background as? MaterialShapeDrawable)?.apply {
                fillColor = ColorStateList.valueOf(Color.TRANSPARENT)
                elevation = 1f
            }
        }
    }

    /**
     * Configures the [BottomSheetBehavior] and the view heights for the requested [initialState], up
     * front (on [onCreate], before layout) so the sheet can settle to its target in a single pass — the
     * target state itself is set in [onStart].
     */
    private fun applyInitialState() {
        val displayHeight = context.resources.displayMetrics.heightPixels
        behavior.maxHeight = (displayHeight * EXPANDED_HEIGHT_RATIO).toInt()

        if (initialState == BottomSheetStateEnum.WRAP_CONTENT) return

        behavior.isFitToContents = false
        behavior.expandedOffset = (displayHeight * (1f - EXPANDED_HEIGHT_RATIO)).toInt()
        findViewById<View>(MaterialR.id.design_bottom_sheet)?.updateLayoutParams {
            height = ViewGroup.LayoutParams.MATCH_PARENT
        }
        binding.root.updateLayoutParams {
            height = ViewGroup.LayoutParams.MATCH_PARENT
        }
        binding.idnowBottomSheetContentContainer.updateLayoutParams<ConstraintLayout.LayoutParams> {
            height = 0
        }
    }

    /**
     * Replaces the dialog's default translucent black dim with an opaque design-system gray backdrop.
     *
     * Painting the window itself (rather than dimming the activity behind it) means the underlying
     * screen is fully hidden and the sheet reads as sitting on a solid gray surface, as per the design.
     * The [android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND] flag is cleared so no black dim is
     * composited on top of the gray.
     */
    private fun applyScrim() {
        window?.apply {
            setBackgroundDrawable(
                if (isScrimVisible) {
                    BottomSheetStyle.scrimColor
                } else {
                    Color.TRANSPARENT
                }.toDrawable()
            )
            clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }
    }
    /** endregion Private methods */

    private companion object {
        /**
         * Fraction of the total available height the fully expanded sheet covers — it stops short of
         * the very top rather than covering the whole screen.
         */
        private const val EXPANDED_HEIGHT_RATIO = 0.9f
    }

    /**
     * This builder builds an [IDnowBottomSheet].
     * First, create a builder with a [context].
     * Then, set the content layout to display, using the methods below.
     * Finally, build the bottom sheet using [create], and show it using [show] (or [show] directly).
     *
     * @see setContentView
     * @see create
     * @see show
     */
    class Builder(val context: Context) {
        private val bottomSheet = IDnowBottomSheet(context)

        /**
         * Sets the content layout of the bottom sheet from an already-inflated [view].
         * @param view the custom content placed inside the sheet's content placeholder.
         */
        fun setContentView(view: View): Builder {
            bottomSheet.customView = view
            return this
        }

        /**
         * Sets the content layout of the bottom sheet by inflating [layoutRes] into the content
         * placeholder (so its root layout params are honored).
         * @param layoutRes the layout resource to inflate as the sheet's content.
         */
        fun setContentView(@LayoutRes layoutRes: Int): Builder {
            val view = LayoutInflater.from(context)
                .inflate(layoutRes, bottomSheet.binding.idnowBottomSheetContentContainer, false)
            return setContentView(view)
        }

        /**
         * Shows or hides the top-left close button.
         * @param visible whether the close button is shown (hidden by default).
         * @param listener the close-button click listener; `null` (default) dismisses the sheet.
         */
        fun setCloseButton(visible: Boolean, listener: ((IDnowBottomSheet) -> Unit)? = null): Builder {
            bottomSheet.isCloseButtonVisible = visible
            bottomSheet.closeButtonOnClickListener = OnClickListener {
                listener?.let { it(bottomSheet) } ?: bottomSheet.dismiss()
            }
            return this
        }

        /**
         * Sets whether the opaque design-system gray scrim is painted behind the sheet.
         * @param visible `true` (default) paints the gray scrim; `false` keeps the platform dim.
         */
        fun setScrimVisible(visible: Boolean): Builder {
            bottomSheet.isScrimVisible = visible
            return this
        }

        /**
         * Sets whether tapping outside the sheet dismisses it.
         * @param cancelable `true` to dismiss on an outside tap; `false` (default) to keep it open.
         */
        fun setDismissOnTouchOutside(cancelable: Boolean): Builder {
            bottomSheet.dismissOnTouchOutside = cancelable
            return this
        }

        /**
         * Sets the height the sheet is displayed at when it first appears.
         * @param state [BottomSheetStateEnum.WRAP_CONTENT] (default) sizes the sheet to its
         *   content; [BottomSheetStateEnum.HALF_EXPANDED] opens it at half the screen height;
         *   [BottomSheetStateEnum.FULLY_EXPANDED] opens it at the full available height.
         */
        fun setInitialState(state: BottomSheetStateEnum): Builder {
            bottomSheet.initialState = state
            return this
        }

        /**
         * Creates an [IDnowBottomSheet] with the arguments supplied to this builder.
         * Calling this method does not display the bottom sheet. If no additional
         * processing is needed, [show] may be called instead to both create and display it.
         */
        fun create(): IDnowBottomSheet {
            return bottomSheet
        }

        /**
         * Creates an [IDnowBottomSheet] with the arguments supplied to this builder and immediately displays it.
         */
        fun show(): IDnowBottomSheet {
            create().show()
            return bottomSheet
        }
    }
}
