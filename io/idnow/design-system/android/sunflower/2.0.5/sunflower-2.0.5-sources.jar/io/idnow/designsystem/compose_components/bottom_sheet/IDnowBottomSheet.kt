package io.idnow.designsystem.compose_components.bottom_sheet

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalBottomSheetProperties
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.common.BottomSheetStateEnum
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.compose_components.extension.dp
import io.idnow.designsystem.styles.compose.IDnowBottomSheetDefaults
import io.idnow.designsystem.tokens.Tokens
import kotlin.math.roundToInt

/**
 * Tokenized bottom-sheet dialog. It slides up from the bottom of the screen and shows, from top to
 * bottom: a drag handle, an optional top-left close button, and a caller-supplied [content] slot into
 * which the integrator places any composable. The design-system chrome (rounded top corners, primary
 * background, opaque scrim, drag handle) is provided;
 *
 * Visibility is **caller-driven** — the caller owns the state (e.g. `var visible by remember { … }`)
 * and toggles [visible]; the sheet calls [onDismiss] when a swipe / scrim / back / close requests it.
 *
 * @param visible whether the sheet is shown.
 * @param onDismiss invoked when the sheet should be hidden (swipe / scrim / back / close).
 * @param isCloseButtonVisible whether the top-left close button is shown (hidden by default).
 * @param isScrimVisible `true` (default) paints the opaque design-system scrim; `false` keeps the
 *   platform's default translucent dim.
 * @param dismissOnTouchOutside whether tapping outside the sheet dismisses it (disabled by default).
 * @param initialState the height the sheet opens at (see [BottomSheetStateEnum]); defaults to
 *   [BottomSheetStateEnum.WRAP_CONTENT] (as tall as its content).
 * @param content the caller-supplied content placed inside the sheet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IDnowBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    isCloseButtonVisible: Boolean = false,
    isScrimVisible: Boolean = true,
    dismissOnTouchOutside: Boolean = false,
    initialState: BottomSheetStateEnum = BottomSheetStateEnum.WRAP_CONTENT,
    content: @Composable ColumnScope.() -> Unit,
) {
    if (!visible) return

    val style = IDnowBottomSheetDefaults.style()
    // Only HALF_EXPANDED keeps the intermediate (half-screen) stop; WRAP_CONTENT and FULLY_EXPANDED
    // open directly at their expanded height.
    val sheetState = rememberModalBottomSheetState(
        skipPartiallyExpanded = initialState != BottomSheetStateEnum.HALF_EXPANDED,
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = modifier,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = style.cornerRadius, topEnd = style.cornerRadius),
        containerColor = style.backgroundColor,
        scrimColor = if (isScrimVisible) style.scrimColor else Color.Transparent,
        dragHandle = {
            IDnowBottomSheetDragHandle(
                handleColor = style.handleColor,
                isCloseButtonVisible = isCloseButtonVisible,
                onCloseClick = onDismiss,
            )
        },
        properties = ModalBottomSheetProperties(
            shouldDismissOnClickOutside = dismissOnTouchOutside,
            shouldDismissOnBackPress = true,
            isAppearanceLightStatusBars = IDnowDesignSystem.isLightMode,
            isAppearanceLightNavigationBars = IDnowDesignSystem.isLightMode,
        ),
        contentWindowInsets = {
            WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Bottom)
        },
    ) {
        Column(
            modifier = Modifier
                // Cap the content to EXPANDED_HEIGHT_RATIO of the height Material actually gives it
                // (the incoming constraint already excludes the drag handle and window insets), so the
                // whole sheet stays under full height in every state — dragging a WRAP_CONTENT or
                // HALF_EXPANDED sheet up stops at the cap and never covers the screen.
                .layout { measurable, constraints ->
                    val maxHeight = if (constraints.hasBoundedHeight) {
                        (constraints.maxHeight * EXPANDED_HEIGHT_RATIO).roundToInt()
                            .coerceAtLeast(constraints.minHeight)
                    } else {
                        constraints.maxHeight
                    }
                    val placeable = measurable.measure(constraints.copy(maxHeight = maxHeight))
                    layout(placeable.width, placeable.height) { placeable.place(0, 0) }
                }
                // FULLY_EXPANDED opens filling that capped height regardless of content size.
                .then(
                    if (initialState == BottomSheetStateEnum.FULLY_EXPANDED) {
                        Modifier.fillMaxHeight()
                    } else {
                        Modifier
                    },
                )
                // Scrollable so content taller than the cap stays reachable (like the XML NestedScrollView).
                .verticalScroll(rememberScrollState()),
            content = content,
        )
    }
}

/** Fraction of the available height the fully expanded sheet covers */
private const val EXPANDED_HEIGHT_RATIO = 0.9f

/**
 * The tokenized drag handle, replacing the Material default: a centered rounded knob and — when
 * [isCloseButtonVisible] — a top-left close button,
 */
@Composable
private fun IDnowBottomSheetDragHandle(
    handleColor: Color,
    isCloseButtonVisible: Boolean,
    onCloseClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = SpacingEnum.SPACING_SM.dp),
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .width(dimensionResource(R.dimen.idnow_bottom_sheet_handle_width))
                .height(dimensionResource(R.dimen.idnow_bottom_sheet_handle_height))
                .clip(RoundedCornerShape(size = Tokens.radiusFull.dp))
                .background(handleColor),
        )
        if (isCloseButtonVisible) {
            Image(
                painter = painterResource(R.drawable.sunflower_ic_cross),
                contentDescription = stringResource(R.string.sunflower_close_popup),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .size(dimensionResource(R.dimen.idnow_bottom_sheet_close_icon_size))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onCloseClick,
                    )
                    .padding(dimensionResource(R.dimen.idnow_bottom_sheet_close_icon_padding)),
            )
        }
    }
}
