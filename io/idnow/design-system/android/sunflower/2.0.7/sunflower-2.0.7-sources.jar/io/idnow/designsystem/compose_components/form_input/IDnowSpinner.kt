package io.idnow.designsystem.compose_components.form_input

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import io.idnow.designsystem.R
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputDropdown
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputFrame
import io.idnow.designsystem.compose_components.form_input.common.IDnowInputItemRow
import io.idnow.designsystem.compose_components.form_input.common.idnowInputContainer
import io.idnow.designsystem.compose_components.form_input.common.rememberInputAccessibilityText
import io.idnow.designsystem.compose_components.form_input.common.resolveContainerState
import io.idnow.designsystem.compose_components.form_input.common.takeFocusOrClear
import io.idnow.designsystem.styles.compose.IDnowFormInputDefaults
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItem

/**
 * Compose counterpart of the XML `IDnowSpinner`. A read-only field showing the selected item (or the
 * [hint] placeholder) with a trailing chevron, opening a shared dropdown of selectable items.
 *
 * Stateless: hoist [selectedItem]; the chosen item is delivered via [onItemSelected].
 *
 * @param initiallyExpanded opens the dropdown on first composition (e.g. to prompt a choice when
 * nothing is pre-selected). Only read once: later changes are ignored. Has no effect when the spinner
 * is created disabled.
 */
@Composable
fun IDnowSpinner(
    items: List<IDnowItem>,
    selectedItem: IDnowItem?,
    onItemSelected: (IDnowItem) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    hint: String? = null,
    helperText: String? = null,
    errorText: String? = null,
    isError: Boolean = false,
    enabled: Boolean = true,
    initiallyExpanded: Boolean = false,
) {
    val style = IDnowFormInputDefaults.style()
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var expanded by remember { mutableStateOf(initiallyExpanded && enabled) }
    var anchorWidthPx by remember { mutableIntStateOf(0) }
    // The anchor is unmeasured (width 0) until onSizeChanged fires, so an initially expanded dropdown
    // would open at zero width on the first frame; treat it as closed until the anchor has a size.
    val showDropdown = expanded && anchorWidthPx > 0
    val interactionSource = remember { MutableInteractionSource() }
    val containerState = resolveContainerState(focused = showDropdown, isError = isError, enabled = enabled)
    // The spinner has no native editableText, so its spoken "content" (the selected item, or the hint
    // when nothing is selected) is passed as the trailing part of the description.
    val displayText = selectedItem?.content?.toString() ?: hint
    val accessibilityText = rememberInputAccessibilityText(
        label = label,
        hint = displayText,
        errorText = errorText,
        isError = isError,
        helperText = helperText,
    )
    // The spinner has no native editable semantics, so it needs a non-empty name to be focusable;
    // fall back to "Not selected." (the role adds "Drop down list").
    val spokenText = accessibilityText.ifEmpty { stringResource(R.string.sunflower_not_selected) }

    IDnowInputFrame(style, label, errorText, isError, helperText, modifier) {
        Box {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .onSizeChanged { anchorWidthPx = it.width }
                    .idnowInputContainer(containerState, style)
                    .focusRequester(focusRequester)
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        enabled = enabled,
                        role = Role.DropdownList,
                        // Move focus off any focused text field so its keyboard/dropdown dismiss: with a
                        // keyboard/d-pad the spinner takes focus (and keeps it once the dropdown closes);
                        // in touch mode a clickable can't be focused, so focus is cleared instead (see
                        // takeFocusOrClear).
                        onClick = {
                            focusRequester.takeFocusOrClear(focusManager)
                            expanded = !expanded
                        },
                    )
                    .padding(style.innerPadding)
                    .clearAndSetSemantics { contentDescription = spokenText },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                selectedItem?.icon?.let { icon ->
                    Image(
                        painter = painterResource(icon),
                        contentDescription = null,
                        modifier = Modifier.size(style.itemIconSize),
                    )
                    Spacer(Modifier.width(style.itemSpacing))
                }
                BasicText(
                    text = selectedItem?.content?.toString() ?: hint.orEmpty(),
                    style = if (selectedItem == null) style.fieldTextStyle.copy(color = style.hintColor) else style.fieldTextStyle,
                    maxLines = 1,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(style.innerPadding))
                // The XML `sunflower_ic_chevron_up_down` is a state-list selector (unsupported by
                // painterResource); swap the plain vector by open state instead (up when expanded).
                Image(
                    painter = painterResource(
                        if (showDropdown) R.drawable.sunflower_ic_chevron_up else R.drawable.sunflower_ic_chevron_down,
                    ),
                    contentDescription = null,
                    colorFilter = ColorFilter.tint(style.trailingIconTint),
                    modifier = Modifier.size(style.trailingIconSize),
                )
            }
            IDnowInputDropdown(
                expanded = showDropdown,
                onDismissRequest = { expanded = false },
                anchorWidthPx = anchorWidthPx,
                style = style,
            ) {
                items(items) { item ->
                    IDnowInputItemRow(
                        item = item,
                        style = style,
                        selected = item == selectedItem,
                        showCheck = true,
                        onClick = {
                            onItemSelected(item)
                            expanded = false
                        },
                    )
                }
            }
        }
    }
}
