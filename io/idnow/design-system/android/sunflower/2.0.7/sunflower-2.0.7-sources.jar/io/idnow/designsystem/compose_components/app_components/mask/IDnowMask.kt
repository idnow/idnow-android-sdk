package io.idnow.designsystem.compose_components.app_components.mask

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.styles.compose.IDnowMaskDefaults
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskOverlay
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskShape
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskStatus

/**
 * Compose counterpart of the XML `IDnowMaskView`: a mask drawn on top of a camera/image. It darkens
 * everything outside [quad] with [maskBackgroundColor] and cuts the [shape] out (so the camera shows
 * through), then strokes an [overlay] in the [status] color on top.
 *
 * Stack it over the camera/preview in a `Box`. The [quad] is given in **pixels** (four corners,
 * supporting a skewed quadrilateral for live document detection) — compute it from the drawing size
 * (e.g. via `Modifier.onSizeChanged`). Reuses the same model types as the XML view.
 *
 * `Progress` fills the outline once over its duration then stays full; re-assigning the overlay (or
 * changing [shape]) replays it. `Corners(isBouncing = true)` pulses the corner brackets.
 */
@Composable
fun IDnowMask(
    quad: IDnowMaskQuad,
    modifier: Modifier = Modifier,
    shape: IDnowMaskShape = IDnowMaskShape.RECT,
    overlay: IDnowMaskOverlay = IDnowMaskOverlay.None,
    status: IDnowMaskStatus = IDnowMaskStatus.ACTIVE,
    maskBackgroundColor: Color = BackgroundColorEnum.SECONDARY.composeColor,
) {
    val style = IDnowMaskDefaults.style()
    val statusColor = status.tint.composeColor

    // Bounce: pulse the corner brackets (1 → power → 1), only when requested. Kept as a State and
    // read only in the draw block, so the pulse redraws every frame without recomposing.
    val bouncing = overlay is IDnowMaskOverlay.Corners && overlay.isBouncing
    val bounceScale: State<Float>? = if (bouncing) {
        rememberInfiniteTransition(label = "maskBounce").animateFloat(
            initialValue = 1f,
            targetValue = style.bouncePower,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = style.bounceDurationMillis / 2, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "maskBounceScale",
        )
    } else {
        null
    }

    // Progress: fill the outline once, replayed when the overlay/shape changes.
    val progress = remember { Animatable(0f) }
    val progressOverlay = overlay as? IDnowMaskOverlay.Progress
    LaunchedEffect(progressOverlay, shape) {
        if (progressOverlay != null) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMillis = progressOverlay.duration, easing = LinearEasing))
        }
    }

    // The geometry only depends on size, quad, shape, overlay and style, so it is built once in the
    // cache block; only the animated progress/bounce values are read per frame in onDrawBehind.
    Spacer(
        modifier = modifier.fillMaxSize().drawWithCache {
            val cornerWidth = style.cornerWidth.toPx()
            val cubicCorner = style.cubicCornerWidth.toPx()
            val isEmpty = quad.isEmpty()
            fun fullPath(): Path =
                if (shape == IDnowMaskShape.RECT) roundedRectMaskPath(quad, cornerWidth, cubicCorner, useCompleteLines = true)
                else ovalMaskPath(quad)

            // Shape: outer rect + cut-out shape (EvenOdd) → only the surrounding area is painted.
            val shapePath = Path().apply {
                fillType = PathFillType.EvenOdd
                addRect(Rect(0f, 0f, size.width, size.height))
                if (!isEmpty) addPath(fullPath())
            }

            // Overlay stroke. Progress keeps the full outline and extracts its leading segment per frame.
            val overlayPath: Path? = if (isEmpty) null else when (overlay) {
                IDnowMaskOverlay.None -> null
                is IDnowMaskOverlay.Corners ->
                    if (shape == IDnowMaskShape.RECT) roundedRectMaskPath(quad, cornerWidth, cubicCorner, useCompleteLines = false)
                    else ovalCornersMaskPath(quad)

                IDnowMaskOverlay.Full, is IDnowMaskOverlay.Progress -> fullPath()
            }
            val progressMeasure = if (overlay is IDnowMaskOverlay.Progress && overlayPath != null) {
                PathMeasure().apply { setPath(overlayPath, true) }
            } else {
                null
            }
            val progressPath = Path()
            val stroke = Stroke(width = style.strokeWidth.toPx(), join = StrokeJoin.Round)
            val pivot = Offset(
                x = (quad.leftTop.x + quad.rightTop.x) / 2f,
                y = (quad.leftTop.y + quad.leftBottom.y) / 2f,
            )

            onDrawBehind {
                drawPath(shapePath, color = maskBackgroundColor)

                val path = if (progressMeasure != null) {
                    progressPath.rewind()
                    progressMeasure.getSegment(0f, progressMeasure.length * progress.value, progressPath, true)
                    progressPath
                } else {
                    overlayPath ?: return@onDrawBehind
                }

                if (bounceScale != null) {
                    scale(bounceScale.value, pivot) { drawPath(path, color = statusColor, style = stroke) }
                } else {
                    drawPath(path, color = statusColor, style = stroke)
                }
            }
        },
    )
}

/** Map a mask status to its tint token so the overlay color re-themes. */
private val IDnowMaskStatus.tint: TintColorEnum
    get() = when (this) {
        IDnowMaskStatus.ACTIVE -> TintColorEnum.ACTIVE
        IDnowMaskStatus.PROCESSING -> TintColorEnum.PROCESSING
        IDnowMaskStatus.SUCCESS -> TintColorEnum.SUCCESS
        IDnowMaskStatus.ERROR -> TintColorEnum.ERROR
    }
