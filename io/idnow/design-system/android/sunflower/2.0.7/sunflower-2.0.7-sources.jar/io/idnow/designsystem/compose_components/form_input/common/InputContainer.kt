package io.idnow.designsystem.compose_components.form_input.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.focus.FocusRequester
import io.idnow.designsystem.styles.compose.IDnowFormInputStyle
import io.idnow.designsystem.styles.compose.IDnowInputContainerState

/**
 * The bordered input container background — Compose mirror of the XML `IDnowContainer` state-list
 * drawable. Clips to the rounded shape first so children (field, icons) stay inside the radius, then
 * fills the state background and draws the state border.
 */
fun Modifier.idnowInputContainer(
    state: IDnowInputContainerState,
    style: IDnowFormInputStyle,
): Modifier {
    val shape = RoundedCornerShape(style.cornerRadius)
    return this
        .clip(shape)
        .background(style.backgroundFor(state), shape)
        .border(style.strokeWidthFor(state), style.strokeColorFor(state), shape)
}

/**
 * Resolve the container state from the live focus/error/enabled inputs, following the XML state-list
 * precedence: disabled > error > focused(filling) > empty.
 */
fun resolveContainerState(focused: Boolean, isError: Boolean, enabled: Boolean): IDnowInputContainerState = when {
    !enabled -> IDnowInputContainerState.Disabled
    isError -> IDnowInputContainerState.Error
    focused -> IDnowInputContainerState.Filling
    else -> IDnowInputContainerState.Empty
}

/** Convenience: live container state driven by an [interactionSource]'s focus. */
@Composable
fun rememberContainerState(
    interactionSource: MutableInteractionSource,
    isError: Boolean,
    enabled: Boolean,
): IDnowInputContainerState {
    val focused by interactionSource.collectIsFocusedAsState()
    return resolveContainerState(focused, isError, enabled)
}

/**
 * Focus handling for the click of a dropdown trigger (spinner, phone flag selector): move focus onto
 * the trigger, or clear it when the trigger can't take it. A clickable is only focusable outside touch
 * mode (keyboard / d-pad), so on a tap (and typically a TalkBack double-tap, which leaves the device
 * in touch mode) the request fails, and without clearing, a focused text field would keep focus and
 * re-show its keyboard on the next tap.
 * `requestFocus` throws if the node is momentarily detached (rapid re-tap), hence the `runCatching`.
 */
internal fun FocusRequester.takeFocusOrClear(focusManager: FocusManager) {
    if (!runCatching { requestFocus() }.getOrDefault(false)) focusManager.clearFocus()
}
