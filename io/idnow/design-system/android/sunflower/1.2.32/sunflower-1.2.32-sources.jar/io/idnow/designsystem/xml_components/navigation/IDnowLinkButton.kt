package io.idnow.designsystem.xml_components.navigation

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.text.SpannableStringBuilder
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat.startActivity
import androidx.core.content.res.ResourcesCompat
import androidx.core.content.withStyledAttributes
import androidx.core.net.toUri
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.databinding.IdnowLinkButtonBinding
import io.idnow.designsystem.styles.LinkButtonStyle
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.extension.toHtmlText

class IDnowLinkButton: ConstraintLayout, IDnowMarginable {
    /** Inflate the layout into the view. */
    val binding = IdnowLinkButtonBinding.inflate(LayoutInflater.from(context), this)

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** Display or hide the start icon. */
    var startIcon: Drawable? = null
        set(value) {
            field = value
            binding.idnStartIcon.setImageDrawable(value)
        }

    /** Display or hide the end icon. */
    var endIcon: Drawable? = null
        set(value) {
            field = value
            binding.idnEndIcon.setImageDrawable(value)
        }

    /** Text of the link button. */
    var text: CharSequence = ""
        set(value) {
            field = value
            binding.idnText.text = value
            setContentDescription()
        }

    /** URI of the link */
    var link: Uri? = null
        set(value) {
            field = value
            if (value != null) {
                importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
                setOnClickListener {
                    onClick(value)
                }
            } else {
                importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
                setOnClickListener(null)
            }
        }

    /** Callback to the host app. */
    private var onLinkClickListener: ((Uri) -> Boolean)? = null

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowLinkButton) {
            val margin = getInt(R.styleable.IDnowLinkButton_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowLinkButton_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowLinkButton_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowLinkButton_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowLinkButton_token_endMargin, -1)
            margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
            startIcon = getDrawable(R.styleable.IDnowLinkButton_startIcon) ?:
                    ResourcesCompat.getDrawable(context.resources, R.drawable.sunflower_ic_documents, null)
            endIcon = getDrawable(R.styleable.IDnowLinkButton_endIcon) ?:
                    ResourcesCompat.getDrawable(context.resources, R.drawable.sunflower_ic_external_link, null)
            text = getString(R.styleable.IDnowLinkButton_android_text) ?: ""
            link = getString(R.styleable.IDnowLinkButton_link)?.toUri()
        }
        initialize()
    }

    private fun initialize() {
        /** Set custom background */
        setBackgroundResource(R.drawable.idnow_link_button_background)
        /** Apply tokens to the background */
        (background as? StateListDrawable)?.customizeGradient(context)
        /** Update end icon constraint */
        updateConstraints()
        /** Set accessibility content description */
        setContentDescription()
    }

    /**
     * Set a lambda to be called when the link button is clicked.
     * @param listener the lambda that will be called
     * The lambda return true is it handle the link redirection false otherwise.
     */
    fun setOnLinkClickListener(listener: ((Uri) -> Boolean)?) {
        onLinkClickListener = listener
    }

    /** Internal click action, can be handle by customer with an onLinkClickListener. */
    private fun onClick(uri: Uri) {
        if(onLinkClickListener?.invoke(uri) != true) {
            val browserIntent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(context, browserIntent, null)
        }
    }

    private fun updateConstraints() {
        with(LinkButtonStyle) {
            binding.idnEndIcon.apply {
                layoutParams = layoutParams.applyMargin(context, top = itemMargin, bottom = itemMargin, end = itemMargin)
                imageTintList = ColorStateList.valueOf(endIconColor)
            }
        }
    }

    /**
     * Customize the gradient of the button.
     * @param context the context to apply dp transformation
     */
    private fun StateListDrawable.customizeGradient(context: Context) {
        with(LinkButtonStyle) {
            /** Update tokens of pressed state */
            customize(
                solidColor = Utils.adjustAlpha(pressedBackgroundColor, pressedBackgroundOpacity),
                strokeColor = strokeColor,
                strokeWidth = strokeWidth.toDp(context),
                cornerRadius = cornerRadius.toDp(context).toFloat(),
            )
            /** Update tokens of classic state */
            customize(
                strokeColor = strokeColor,
                strokeWidth = strokeWidth.toDp(context),
                cornerRadius = cornerRadius.toDp(context).toFloat(),
                indexChild = 1
            )
        }
    }
    @Suppress("RemoveRedundantQualifierName") /* It is needed by IDE to know which method to override. */
    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    private fun setContentDescription() {
        @Suppress("UNNECESSARY_SAFE_CALL") // Wrong it will be null in some cases.
        ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = SpannableStringBuilder().apply {
                    append("$text${if(!text.endsWith(".")) "." else ""} ")
                    append(context.getString(R.string.sunflower_link))
                }
            }
        })
    }
}