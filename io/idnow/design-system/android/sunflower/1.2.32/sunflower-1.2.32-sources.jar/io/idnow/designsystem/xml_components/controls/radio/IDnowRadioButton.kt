package io.idnow.designsystem.xml_components.controls.radio

import android.content.Context
import android.os.Parcelable
import android.text.SpannableStringBuilder
import android.util.AttributeSet
import android.view.View
import android.widget.RadioButton
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowRadioButtonBinding
import io.idnow.designsystem.xml_components.controls.common.IDnowControls
import io.idnow.designsystem.xml_components.controls.common.Size

open class IDnowRadioButton : IDnowControls {
    /** Stub binding, replace the view stub with a check box. */
    private var radioButtonBinding: IdnowRadioButtonBinding

    init {
        binding.idnField.layoutResource = R.layout.idnow_radio_button
        radioButtonBinding = IdnowRadioButtonBinding.bind(binding.idnField.inflate())
    }

    var size: RadioSize = RadioSize.NORMAL
        set(value) {
            val size = Size.valueOf(value.name)
            controlSize = size
            radioButtonBinding.idnRadioButton.size = size
            field = value
        }

    /** Is the radio button checked */
    var isChecked: Boolean
        get() = radioButtonBinding.idnRadioButton.isChecked
        set(value) {
            radioButtonBinding.idnRadioButton.isChecked = value
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowRadioButton)
        val size = RadioSize.entries[customArray.getInt(R.styleable.IDnowRadioButton_radioSize, RadioSize.NORMAL.ordinal)]
        val isEnabled = customArray.getBoolean(R.styleable.IDnowRadioButton_android_enabled, true)
        val isChecked = customArray.getBoolean(R.styleable.IDnowRadioButton_android_checked, false)
        customArray.recycle()
        initialize(size, isEnabled, isChecked)
    }

    private fun initialize(size: RadioSize, isEnabled: Boolean, isChecked: Boolean) {
        this.size = size
        /** We initialize the controls here because we wait that all the variable retrieve from xml are transmit to the controls object before initializing it. */
        initializeControls()
        /** Is the component enable */
        this.isEnabled = isEnabled
        /** Is the component checked */
        this.isChecked = isChecked
        /** Remove error state on check changed */
        radioButtonBinding.idnRadioButton.onInternalChange = { stateError = false }

        /** Check the checkbox when the area and text are clicked */
        binding.idnContainer.setOnClickListener {
            radioButtonBinding.idnRadioButton.toggle()
        }

        /** Set content description for accessibility */
        setContentDescription()
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        radioButtonBinding.idnRadioButton.isEnabled = enabled
    }

    /**
     * Register a callback to be invoked when the checked state of this button
     * changes.
     *
     * @param listener the callback to call on checked state change
     */
    @Suppress("Unused")
    fun setOnCheckedChangeListener(listener: (IDnowRadioButton, Boolean) -> Unit) {
        radioButtonBinding.idnRadioButton.setOnCheckedChangeListener { _, isChecked ->
            listener(this, isChecked)
        }
    }

    /**
     * Remove the onChange callback. Can be useful when manually updating radio button.
     */
    @Suppress("Unused")
    fun removeOnCheckedChangeListener() {
        radioButtonBinding.idnRadioButton.setOnCheckedChangeListener(null)
    }

    /** Expose the radio button to allow the use of specific radio buttons callbacks and API. */
    @Suppress("Unused")
    fun radio(): RadioButton = radioButtonBinding.idnRadioButton

    override fun getStubView(): View = radioButtonBinding.idnRadioButton

    enum class RadioSize {
        SMALL, NORMAL
    }

    /** Set a custom description for accessibility. */
    override fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.idnContainer, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = SpannableStringBuilder().apply {
                    append(accessibilityContentText())
                    append("${accessibilityClassName()} ")
                    append("${accessibilityStatus()} ")
                    if (!isEnabled) append(context.getString(R.string.sunflower_disabled))
                }
            }
        })
    }

    override fun onSaveChildState(): Parcelable? = radioButtonBinding.root.onSaveInstanceState()

    override fun onRestoreChildState(childState: Parcelable?) {
        childState?.let { radioButtonBinding.root.onRestoreInstanceState(it) }
    }

    /** Retrieve the status of the checkbox for accessibility. */
    private fun accessibilityClassName(): String {
        return context.getString(R.string.sunflower_radio_button)
    }

    /** Retrieve the status of the checkbox for accessibility. */
    private fun accessibilityStatus(): String {
        return if (radioButtonBinding.idnRadioButton.isChecked) {
            context.getString(R.string.sunflower_selected)
        } else {
            context.getString(R.string.sunflower_not_selected)
        }
    }
}