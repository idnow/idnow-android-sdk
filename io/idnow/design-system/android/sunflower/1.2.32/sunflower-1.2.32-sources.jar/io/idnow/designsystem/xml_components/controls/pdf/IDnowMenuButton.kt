package io.idnow.designsystem.xml_components.controls.pdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.graphics.drawable.toDrawable
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isGone
import androidx.core.view.updateLayoutParams
import androidx.core.view.updateMarginsRelative
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.databinding.IdnowMenuButtonBinding
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.colorStateList
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.extractMargins
import io.idnow.designsystem.xml_components.extension.layerDrawable
import io.idnow.designsystem.xml_components.extension.marginable
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.extension.updatePadding

class IDnowMenuButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr), IDnowMarginable {
    private val binding = IdnowMenuButtonBinding.inflate(LayoutInflater.from(context), this)

    private val contentPadding = SpacingEnum.SPACING_SM

    override var margins: SpacingQuad by marginable()

    var lightUi: Boolean = false
        set(value) {
            field = value
            updateBackground(value)
        }

    var active: Boolean = false
        set(value) {
            field = value
            updateContent()
            refreshDrawableState()
        }

    var text: CharSequence
        get() = binding.idnMenuButtonLabel.text
        set(value) {
            binding.idnMenuButtonLabel.text = value
        }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowMenuButton, defStyleAttr) {
            margins = extractMargins(R.styleable.IDnowMenuButton)

            text = getString(R.styleable.IDnowMenuButton_android_text) ?: ""
            getDrawable(R.styleable.IDnowMenuButton_android_drawableStart)?.let {
                binding.idnMenuButtonIcon.setImageDrawable(it)
            } ?: run {
                binding.idnMenuButtonIcon.isGone = true
            }

            active = getBoolean(R.styleable.IDnowMenuButton_active, false)
            lightUi = getBoolean(R.styleable.IDnowMenuButton_lightUi, false)
        }

        isClickable = true
        isFocusable = true

        minHeight = resources.getDimension(R.dimen.idnow_icon_size).toInt() + (contentPadding.value.toDp(context) * 2)
        updatePadding(SpacingQuad(all = contentPadding))
        binding.idnMenuButtonIcon.updateLayoutParams<MarginLayoutParams> {
            updateMarginsRelative(end = contentPadding.value.toDp(context))
        }

        ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.className = Button::class.java.name
                info.isClickable = true
            }
        })
    }

    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        return if (active) {
            mergeDrawableStates(super.onCreateDrawableState(extraSpace + 1), intArrayOf(android.R.attr.state_activated))
        } else {
            super.onCreateDrawableState(extraSpace)
        }
    }

    private fun updateContent() {
        binding.idnMenuButtonLabel.textColor = if (active) TextColorEnum.HEADING else TextColorEnum.BODY
        binding.idnMenuButtonIcon.setColorFilter(if (active) Tokens.heading else Tokens.body)
    }

    private fun updateBackground(isLight: Boolean) {
        val cornerSize = Tokens.radiusSm.toDp(context).toFloat()

        background = if (isLight) layerDrawable {
            layer {
                gradient {
                    colorStateList { colorState(Tokens.backgroundSecondary, state = android.R.attr.state_pressed) }
                    cornerRadius {
                        topLeft = cornerSize
                        topRight = cornerSize
                    }
                }
            }
            layer {
                stateList {
                    state(states = intArrayOf(-android.R.attr.state_activated, -android.R.attr.state_pressed)) { single(Color.TRANSPARENT.toDrawable()) }
                    state { single(MenuButtonBottomStrokeDrawable(strokeColor = Tokens.primaryBackground, 3.toDp(context).toFloat())) }
                }
            }
        } else layerDrawable {
            layer {
                gradient {
                    colorStateList {
                        colorState(Tokens.backgroundSecondary, state = android.R.attr.state_activated)
                        colorState(Tokens.backgroundTertiary)
                    }
                    cornerRadius {
                        topLeft = cornerSize
                        topRight = cornerSize
                    }
                }
            }
            layer {
                stateList {
                    state(states = intArrayOf(-android.R.attr.state_activated, -android.R.attr.state_pressed)) { single(Color.TRANSPARENT.toDrawable()) }
                    state { single(MenuButtonTopStrokeDrawable(strokeColor = Tokens.active, cornerSize)) }
                }
            }
        }
    }
}

private class MenuButtonTopStrokeDrawable(
    strokeColor: Int,
    private val cornerRadius: Float,
) : Drawable() {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = strokeColor
    }

    private val path = Path()
    private val corners = floatArrayOf(
        cornerRadius, cornerRadius,
        cornerRadius, cornerRadius,
        0f, 0f,
        0f, 0f,
    )

    val strokeRect = RectF()

    override fun draw(canvas: Canvas) {
        path.reset()

        with(bounds) {
            strokeRect.set(
                left.toFloat(),
                top.toFloat(),
                right.toFloat(),
                top + cornerRadius,
            )
        }

        path.addRoundRect(strokeRect, corners, Path.Direction.CW)
        canvas.drawPath(path, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha; invalidateSelf()
    }

    override fun setColorFilter(cf: ColorFilter?) {
        paint.colorFilter = cf; invalidateSelf()
    }

    @Deprecated("Deprecated in Java", ReplaceWith("PixelFormat.TRANSLUCENT"))
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * A lightweight [Drawable] that paints a single horizontal line flush with the bottom edge of its bounds.
 *
 * @param strokeColor ARGB color of the stroke.
 * @param strokeWidth Height of the stroke in pixels.
 */
private class MenuButtonBottomStrokeDrawable(
    strokeColor: Int,
    private val strokeWidth: Float,
) : Drawable() {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = strokeColor
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        canvas.drawRect(
            b.left.toFloat(),
            b.bottom - strokeWidth,
            b.right.toFloat(),
            b.bottom.toFloat(),
            paint,
        )
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha; invalidateSelf()
    }

    override fun setColorFilter(cf: ColorFilter?) {
        paint.colorFilter = cf; invalidateSelf()
    }

    @Deprecated("Deprecated in Java", ReplaceWith("PixelFormat.TRANSLUCENT"))
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
