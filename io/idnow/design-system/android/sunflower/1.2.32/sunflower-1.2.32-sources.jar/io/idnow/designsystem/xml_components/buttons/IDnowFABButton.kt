package io.idnow.designsystem.xml_components.buttons

import android.content.Context
import android.util.AttributeSet
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.content.withStyledAttributes
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.styles.ButtonStyle
import io.idnow.designsystem.xml_components.extension.extractMargins
import io.idnow.designsystem.xml_components.extension.marginable
import io.idnow.designsystem.xml_components.extension.toDp

class IDnowFABButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : AppCompatImageButton(context, attrs, defStyleAttr), IDnowMarginable {
    /** Style, always primary for FAB button */
    private lateinit var style: ButtonStyle

    /** Margins */
    override var margins: SpacingQuad by marginable()

    init {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowFABButton) {
            val attrStyle = ButtonType.entries[getInt(R.styleable.IDnowFABButton_style, ButtonType.PRIMARY.ordinal)]
            val size = ButtonSize.entries[getInt(R.styleable.IDnowFABButton_size, ButtonSize.MEDIUM.ordinal)]

            style = when (attrStyle) {
                ButtonType.PRIMARY -> ButtonStyle.PrimaryButton(size)
                ButtonType.SECONDARY -> ButtonStyle.SecondaryButton(size)
                ButtonType.DANGER -> ButtonStyle.DangerButton(size)
                ButtonType.TRIGGER -> ButtonStyle.TriggerButton(size)
            }

            /** Handle the component margin. */
            margins = extractMargins(R.styleable.IDnowFABButton)

            isEnabled = getBoolean(R.styleable.IDnowFABButton_android_enabled, true)

            /** Background */
            background = style.background(context)
            /** Color the drawable */
            drawable.setTint(style.textColor)
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        val iconSize = resources.getDimension(style.iconSize).toInt()
        // Padding size is hardcoded per Figma guideline
        val padding = when (style.size) {
            ButtonSize.SMALL -> 8
            ButtonSize.MEDIUM -> 14
            ButtonSize.LARGE -> 16
        }.toDp(context)
        val componentSize = iconSize + (padding * 2)

        setPadding(padding)

        params?.width = componentSize
        params?.height = componentSize

        super.setLayoutParams(params)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ButtonStyle.opacity(enabled)
    }
}