package io.idnow.designsystem.xml_components.form_input_texts.common

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.widget.EditText
import androidx.core.content.withStyledAttributes
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.doOnLayout
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.xml_components.extension.getMaxLength
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp

abstract class IDnowBaseTextField @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : IDnowFormInputs(context, attrs, defStyleAttr) {
    protected abstract val editText: EditText

    /** Add an optional tooltip text for accessibility. */
    @get:JvmName("getIDnowTextFieldTooltipText")
    @set:JvmName("setIDnowTextFieldTooltipText")
    var tooltipText: CharSequence? = null

    /** Property to delay [editText] text init. */
    private var _text: String? = null

    /** Change the edittext text */
    var text: String
        get() = editText.text.toString()
        set(value) {
            editText.setText(value)
        }


    /** Property to delay [editText] hint init. */
    private var _hint: CharSequence? = null

    /** Change the edittext hint */
    var hint: CharSequence
        get() = editText.hint.toString()
        set(value) {
            editText.hint = value
        }

    /** Display or hide the clear icon. */
    var clearIcon: Boolean = false
        set(value) {
            field = value
            binding.idnContClear.isVisible = value
        }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowBaseTextField, defStyleAttr) {
            _text = getString(R.styleable.IDnowBaseTextField_text)
            _hint = getString(R.styleable.IDnowBaseTextField_hint)
            tooltipText = getString(R.styleable.IDnowBaseTextField_tooltipText)
            clearIcon = getBoolean(R.styleable.IDnowBaseTextField_clearIcon, false)
        }

        doOnLayout { updateConstraints() }
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        _text?.let { text = it }.also { _text = null }
        _hint?.let { hint = it }.also { _hint = null }
    }

    override fun setContentDescription() {
        @Suppress("SENSELESS_COMPARISON") // Wrong it will be null when first called and in some other cases.
        if (editText == null) return
        ViewCompat.setAccessibilityDelegate(editText, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.text = getAccessibilityContentText().append(info.text ?: "")
                editText.getMaxLength()?.let {
                    info.maxTextLength = getAccessibilityContentText().length + it
                }
                tooltipText?.let { info.tooltipText = it }
            }
        })
    }

    fun editText() = editText

    private fun updateConstraints() {
        with(FormInputsStyle) {
            editText.apply {
                // Set top and bottom as padding to have more space to click (recommended by Android for accessibility)
                setPadding(itemMargin.toDp(context))
                setTypography(ContainerStyle.font(context))
                setTextColor(ContainerStyle.textColor)
                setHintTextColor(Utils.adjustAlpha(ContainerStyle.textColor, ContainerStyle.hintOpacity))
                // It is not possible to update (without reflection) the cursor color below API 29.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    textCursorDrawable?.setTint(ContainerStyle.Filling.strokeColor)
                }
            }
        }
    }
}
