package io.idnow.designsystem.xml_components.buttons

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.ProgressBar
import androidx.appcompat.widget.AppCompatButton
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.view.doOnLayout
import androidx.core.view.updatePaddingRelative
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.styles.ButtonStyle
import io.idnow.designsystem.xml_components.extension.allParents
import io.idnow.designsystem.xml_components.extension.extractMargins
import io.idnow.designsystem.xml_components.extension.marginable
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp
import kotlin.math.ceil
import kotlin.math.max

class IDnowButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : AppCompatButton(context, attrs, defStyleAttr), IDnowMarginable {
    /** Button style */
    private lateinit var style: ButtonStyle

    /** Store a progress bar to remove it when loading is done */
    private var progress: ProgressBar? = null

    /** Change button state to loading state. */
    var isLoading: Boolean = false
        set(value) {
            field = value
            doOnLayout { changeLoadingState(value) }
        }

    /** Keep a loading state to only change the button visibility when loading is done. */
    private var loadingState = LoadingState.IDLE

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad by marginable()

    /**
     * Should request focus on loading.
     * This must set before called before setting a view to loading.
     */
    var requestFocusOnLoading = false

    init {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowButton) {
            val drawableStart = getDrawable(R.styleable.IDnowButton_android_drawableStart)
            val drawableEnd = getDrawable(R.styleable.IDnowButton_android_drawableEnd)
            val loading = getBoolean(R.styleable.IDnowButton_loading, false)
            val attrStyle = ButtonType.entries[getInt(R.styleable.IDnowButton_style, ButtonType.PRIMARY.ordinal)]
            val size = ButtonSize.entries[getInt(R.styleable.IDnowButton_size, ButtonSize.MEDIUM.ordinal)]

            setStyle(attrStyle, size)
            setCompoundDrawablesRelative(drawableStart, null, drawableEnd.takeIf { drawableStart == null }, null)

            margins = extractMargins(R.styleable.IDnowButton)

            /** Switch view to loading mode */
            if (loading) isLoading = true
        }
    }

    private fun setupTextStyle() {
        textAlignment = TEXT_ALIGNMENT_CENTER
        gravity = Gravity.CENTER
        setTextColor(style.textColor)
        setTypography(style.typography.toTypography(context))
    }

    fun setStyle(style: ButtonType, size: ButtonSize = ButtonSize.MEDIUM) {
        this.style = when (style) {
            ButtonType.PRIMARY, ButtonType.TRIGGER -> ButtonStyle.PrimaryButton(size)
            ButtonType.SECONDARY -> ButtonStyle.SecondaryButton(size)
            ButtonType.DANGER -> ButtonStyle.DangerButton(size)
        }
        val padding = this.style.paddings
        setPaddingRelative(
            padding.start.value.toDp(context),
            padding.top.value.toDp(context),
            padding.end.value.toDp(context),
            padding.bottom.value.toDp(context)
        )

        /** Set and customize the background */
        background = this.style.background(context)
        /** Customize the text */
        setupTextStyle()
        /** Add padding to center the compound drawable */
        setCompoundDrawablesRelative(compoundDrawables[0], compoundDrawables[1], compoundDrawables[2], compoundDrawables[3])
    }

    override fun getMaxWidth(): Int {
        return style.maxWidth.toDp(context)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ButtonStyle.opacity(enabled)
    }

    private fun getTextLayoutWidth(singleLine: Boolean = false): Int {
        var maxWidth = 0f
        for (line in 0 until lineCount) {
            if (singleLine) {
                maxWidth += layout.getLineWidth(line)
            } else {
                maxWidth = max(maxWidth, layout.getLineWidth(line))
            }
        }
        return ceil(maxWidth).toInt()
    }

    override fun setCompoundDrawables(left: Drawable?, top: Drawable?, right: Drawable?, bottom: Drawable?) {
        /** Do nothing. Please use the relatives drawable. */
    }

    override fun setCompoundDrawablesRelative(start: Drawable?, top: Drawable?, end: Drawable?, bottom: Drawable?) {
        start?.resize()
        end?.resize()
        super.setCompoundDrawablesRelative(start, top, end, bottom)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        packedDrawable()
    }

    private fun packedDrawable() {
        if (measuredWidth == 0 || getTextLayoutWidth(singleLine = true) == 0) return
        val drawable = compoundDrawablesRelative[0] ?: compoundDrawablesRelative[2] ?: return
        // First update the drawable color
        drawable.setTint(style.textColor)
        // Then place it on the next layout iteration
        val iconSize = resources.getDimension(style.iconSize).toInt()
        val iconPadding = if (text.isEmpty()) 0 else style.iconPadding.toDp(context)
        var textWidth = getTextLayoutWidth(singleLine = true)
        if (measuredWidth - iconSize - iconPadding < textWidth) {
            textWidth = getTextLayoutWidth(singleLine = false)
        }
        val emptyWidth = (measuredWidth - textWidth - iconSize - iconPadding)
        val padding = emptyWidth / 2
        updatePaddingRelative(padding, style.paddings.top.value.toDp(context), padding, style.paddings.bottom.value.toDp(context))
    }

    /**
     * Add a loading view in top of the button and temporarily hide the button.
     * The button is shown again when the loading state is removed.
     * @param isLoading to show/hide the loading view.
     */
    private fun changeLoadingState(isLoading: Boolean) {
        when (loadingState) {
            LoadingState.IDLE -> if (isLoading) {
                visibility = View.INVISIBLE
                loadingState = LoadingState.LOADING
                progress = ProgressBar(context).apply {
                    id = R.id.idn_loading_id
                    background = this@IDnowButton.background
                    indeterminateTintList = ColorStateList.valueOf(style.textColor)
                    setPadding(0, style.iconPadding.toDp(context), 0, style.iconPadding.toDp(context))
                    alpha = 0.5f
                }
                if (id == -1) id = R.id.idn_button_loading_id
                val constraintLayoutParams =
                    ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_CONSTRAINT, ConstraintLayout.LayoutParams.MATCH_CONSTRAINT)
                        .allParents(id)
                (parent as ViewGroup).addView(progress, constraintLayoutParams)
                if (requestFocusOnLoading) {
                    progress?.let {
                        it.requestFocus()
                        it.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
                    }
                }
            }

            LoadingState.LOADING -> if (!isLoading) {
                loadingState = LoadingState.IDLE
                visibility = View.VISIBLE
                progress?.let { (parent as ViewGroup).removeView(it) }
            }
        }
    }

    /**
     * Resize compound drawable to apply fixed size and padding
     */
    private fun Drawable.resize() {
        val iconSize = resources.getDimension(style.iconSize).toInt()
        compoundDrawablePadding = style.iconPadding.toDp(context)
        setBounds(0, 0, iconSize, iconSize)
    }
}

enum class ButtonType { PRIMARY, SECONDARY, DANGER, TRIGGER }

internal enum class LoadingState { LOADING, IDLE }