package io.idnow.designsystem.xml_components.controls.idn_switch

import android.content.Context
import android.os.Parcelable
import android.text.SpannableStringBuilder
import android.util.AttributeSet
import android.view.View
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowSwitchBinding
import io.idnow.designsystem.xml_components.controls.check_box.OnCheckChangeListener
import io.idnow.designsystem.xml_components.controls.common.IDnowControls
import io.idnow.designsystem.xml_components.controls.common.Size

class IDnowSwitch : IDnowControls {
    /** Stub binding, replace the view stub with a toggle button. */
    private var switchBinding: IdnowSwitchBinding

    init {
        binding.idnField.layoutResource = R.layout.idnow_switch
        switchBinding = IdnowSwitchBinding.bind(binding.idnField.inflate())
    }

    var size: SwitchSize = SwitchSize.NORMAL
        set(value) {
            val size = Size.valueOf(value.name)
            controlSize = size
            switchBinding.idnSwitch.size = size
            field = value
        }

    /** Is the toggle checked */
    var isChecked: Boolean
        get() = switchBinding.idnSwitch.isChecked
        set(value) {
            switchBinding.idnSwitch.isChecked = value
        }

    override val isFieldOnRightSide: Boolean = true

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowSwitch)
        val size = SwitchSize.entries[customArray.getInt(R.styleable.IDnowSwitch_switchSize, SwitchSize.NORMAL.ordinal)]
        val isEnabled = customArray.getBoolean(R.styleable.IDnowSwitch_android_enabled, true)
        val isChecked = customArray.getBoolean(R.styleable.IDnowSwitch_android_checked, false)
        customArray.recycle()
        initialize(size, isEnabled, isChecked)
    }

    private fun initialize(size: SwitchSize, isEnabled: Boolean, isChecked: Boolean) {
        this.size = size
        /** We initialize the controls here because we wait that all the variable retrieve from xml are transmit to the controls object before initializing it. */
        initializeControls()
        /** Is the component enable */
        this.isEnabled = isEnabled
        /** Is the component checked */
        this.isChecked = isChecked
        /** Remove error state on check changed */
        switchBinding.idnSwitch.onInternalChange = { stateError = false }

        binding.idnContainer.setOnClickListener {
            switchBinding.idnSwitch.toggle()
        }
    }

    /**
     * Register a callback to be invoked when the checked state of this button
     * changes.
     *
     * @param onCheckChangeListener the callback to call on checked state change
     */
    @Suppress("Unused")
    fun setOnCheckedChangeListener(onCheckChangeListener: OnCheckChangeListener) {
        switchBinding.idnSwitch.setOnCheckedChangeListener { _, isChecked: Boolean ->
            onCheckChangeListener.onCheckChange(isChecked)
        }
    }

    /**
     * Register a callback to be invoked when the checked state of this button
     * changes.
     *
     * @param listener the callback to call on checked state change
     */
    fun setOnCheckedChangeListener(listener: (IDnowSwitch, Boolean) -> Unit) {
        switchBinding.idnSwitch.setOnCheckedChangeListener { _, isChecked ->
            listener(this, isChecked)
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        switchBinding.idnSwitch.isEnabled = isEnabled
    }

    override fun getStubView(): View = switchBinding.idnSwitch

    enum class SwitchSize {
        SMALL, NORMAL, BIG
    }

    /** Set a custom description for accessibility. */
    override fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.idnContainer, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = SpannableStringBuilder().apply {
                    append(accessibilityContentText())
                    append("${accessibilityClassName()} ")
                    append("${accessibilityStatus()} ")
                    if (!isEnabled) append(context.getString(R.string.sunflower_disabled))
                }
            }
        })
    }

    override fun onSaveChildState(): Parcelable? = switchBinding.root.onSaveInstanceState()

    override fun onRestoreChildState(childState: Parcelable?) {
        childState?.let { switchBinding.root.onRestoreInstanceState(it) }
    }

    /** Retrieve the status of the checkbox for accessibility. */
    private fun accessibilityClassName(): String {
        return context.getString(R.string.sunflower_switch)
    }

    /** Retrieve the status of the checkbox for accessibility. */
    private fun accessibilityStatus(): String {
        return if (switchBinding.idnSwitch.isChecked) {
            context.getString(R.string.sunflower_on)
        } else {
            context.getString(R.string.sunflower_off)
        }
    }
}