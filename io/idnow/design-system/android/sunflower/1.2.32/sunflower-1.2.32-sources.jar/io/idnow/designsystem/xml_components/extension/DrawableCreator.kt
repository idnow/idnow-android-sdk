@file:Suppress("unused")

package io.idnow.designsystem.xml_components.extension

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.graphics.drawable.VectorDrawable
import android.os.Build
import android.util.Size
import android.view.View
import androidx.annotation.ColorInt
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import kotlin.contracts.ExperimentalContracts

@DslMarker
internal annotation class DrawableCreator

internal sealed interface DrawableBuilder<D : Drawable> {
    fun build(): D
}

@DrawableCreator
internal abstract class DrawableEntryBuilder {
    abstract val buildErrorMessage: String

    protected var drawableBuilder: DrawableBuilder<*>? = null

    fun gradient(block: GradientDrawableBuilder.() -> Unit) {
        drawableBuilder = GradientDrawableBuilder().apply(block)
    }

    fun vector(context: Context, resourceId: Int, block: (VectorDrawableBuilder.() -> Unit)? = null) {
        drawableBuilder = VectorDrawableBuilder(context, resourceId).apply { block?.invoke(this) }
    }

    fun single(drawable: Drawable) {
        drawableBuilder = SingleDrawableBuilder(drawable = drawable)
    }

    fun buildDrawable() = requireNotNull(drawableBuilder?.build()) { buildErrorMessage }
}

@DrawableCreator
@JvmInline
internal value class SingleDrawableBuilder(private val drawable: Drawable) : DrawableBuilder<Drawable> {
    override fun build() = drawable
}

@DrawableCreator
internal class GradientDrawableBuilder : DrawableBuilder<GradientDrawable> {
    data class CornerRadius(
        val topLeft: Float? = null,
        val topRight: Float? = null,
        val bottomLeft: Float? = null,
        val bottomRight: Float? = null,
    ) {
        constructor(radius: Float) : this(radius, radius, radius, radius)

        fun toRadii() = floatArrayOf(
            topLeft ?: 0f, topLeft ?: 0f,
            topRight ?: 0f, topRight ?: 0f,
            bottomLeft ?: 0f, bottomLeft ?: 0f,
            bottomRight ?: 0f, bottomRight ?: 0f,
        )

        @DrawableCreator
        class Builder {
            var topLeft: Float? = null
            var topRight: Float? = null
            var bottomLeft: Float? = null
            var bottomRight: Float? = null

            fun toCornerRadius() = CornerRadius(
                topLeft = topLeft,
                topRight = topRight,
                bottomLeft = bottomLeft,
                bottomRight = bottomRight,
            )
        }
    }

    data class Stroke(val color: Color, val width: Int)

    sealed interface Color {
        @JvmInline
        value class Solid(val argb: Int) : Color

        @JvmInline
        value class ColorList(val colorList: IntArray) : Color

        @JvmInline
        value class StateList(val stateList: ColorStateList) : Color {
            @DrawableCreator
            class Builder {
                private val states = mutableListOf<Pair<IntArray, Int>>()

                fun colorState(@ColorInt color: Int, states: IntArray = intArrayOf()) {
                    this.states.add(states to color)
                }

                fun colorState(@ColorInt color: Int, state: Int) {
                    this.states.add(intArrayOf(state) to color)
                }

                fun build() = StateList(
                    ColorStateList(
                        Array(states.size) { this.states[it].first },
                        IntArray(states.size) { this.states[it].second },
                    )
                )
            }
        }
    }

    data class Padding(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        constructor(horizontal: Int, vertical: Int) : this(horizontal, vertical, horizontal, vertical)
        constructor(all: Int) : this(all, all, all, all)
    }

    var shape: Int = GradientDrawable.RECTANGLE
    var color: Color? = null
    var stroke: Stroke? = null
    var cornerRadius: CornerRadius? = null
    var size: Size? = null

    @RequiresApi(29)
    var padding: Padding? = null

    override fun build(): GradientDrawable {
        val drawable = GradientDrawable()
        when (val c = color) {
            is Color.ColorList -> drawable.colors = c.colorList
            is Color.Solid -> drawable.setColor(c.argb)
            is Color.StateList -> drawable.color = c.stateList
            null -> {}
        }

        drawable.shape = shape
        stroke?.let {
            when (val c = it.color) {
                is Color.ColorList -> drawable.setStroke(it.width, c.colorList[0])
                is Color.Solid -> drawable.setStroke(it.width, c.argb)
                is Color.StateList -> drawable.setStroke(it.width, c.stateList)
            }
        }
        cornerRadius?.let { drawable.cornerRadii = it.toRadii() }
        size?.let { drawable.setSize(it.width, it.height) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) padding?.let { drawable.setPadding(it.left, it.top, it.right, it.bottom) }

        return drawable
    }
}

// === GradientDrawable Builder Utilities - Color ===
@DrawableCreator
internal fun GradientDrawableBuilder.color(argb: Int) {
    this.color = GradientDrawableBuilder.Color.Solid(argb)
}

@DrawableCreator
internal fun GradientDrawableBuilder.colorList(colorList: IntArray) {
    this.color = GradientDrawableBuilder.Color.ColorList(colorList)
}

@DrawableCreator
internal fun GradientDrawableBuilder.colorStateList(colorStateList: ColorStateList) {
    this.color = GradientDrawableBuilder.Color.StateList(colorStateList)
}

@DrawableCreator
internal fun GradientDrawableBuilder.colorStateList(block: GradientDrawableBuilder.Color.StateList.Builder.() -> Unit) {
    this.color = GradientDrawableBuilder.Color.StateList.Builder().apply(block).build()
}

// === GradientDrawable Builder Utilities - Stroke ===

@DrawableCreator
internal fun GradientDrawableBuilder.stroke(@ColorInt color: Int, width: Int) {
    this.stroke = GradientDrawableBuilder.Stroke(GradientDrawableBuilder.Color.Solid(color), width)
}

@DrawableCreator
internal fun GradientDrawableBuilder.stroke(colorStateList: ColorStateList, width: Int) {
    this.stroke = GradientDrawableBuilder.Stroke(GradientDrawableBuilder.Color.StateList(colorStateList), width)
}

@DrawableCreator
internal fun GradientDrawableBuilder.stroke(width: Int, builder: GradientDrawableBuilder.Color.StateList.Builder.() -> Unit) {
    this.stroke = GradientDrawableBuilder.Stroke(GradientDrawableBuilder.Color.StateList.Builder().apply(builder).build(), width)
}

// === GradientDrawable Builder Utilities - Corner Radius ===

@DrawableCreator
internal fun GradientDrawableBuilder.cornerRadius(radius: Float) {
    this.cornerRadius = GradientDrawableBuilder.CornerRadius(radius)
}

@DrawableCreator
internal fun GradientDrawableBuilder.cornerRadius(builder: GradientDrawableBuilder.CornerRadius.Builder.() -> Unit) {
    this.cornerRadius = GradientDrawableBuilder.CornerRadius.Builder().apply(builder).toCornerRadius()
}

@DrawableCreator
internal fun GradientDrawableBuilder.size(width: Int, height: Int) {
    this.size = Size(width, height)
}

@DrawableCreator
internal fun GradientDrawableBuilder.size(all: Int) {
    this.size = Size(all, all)
}

internal fun gradientDrawable(block: GradientDrawableBuilder.() -> Unit) = GradientDrawableBuilder().apply(block).build()

@DrawableCreator
internal class VectorDrawableBuilder(
    private val context: Context,
    private val resourceId: Int,
) : DrawableBuilder<VectorDrawable> {

    var tintColor: Int? = null
    var tintColorStateList: ColorStateList? = null
    var alpha: Int = 255
    var bounds: Rect? = null

    override fun build(): VectorDrawable {
        require(resourceId != 0) { "VectorDrawableBuilder requires a non-zero resourceId." }

        val drawable = requireNotNull(ContextCompat.getDrawable(context, resourceId)?.mutate()) {
            "Could not load drawable for resourceId=$resourceId"
        }

        tintColorStateList?.let { drawable.setTintList(it) } ?: tintColor?.let { drawable.setTint(it) }

        drawable.alpha = alpha
        bounds?.let { drawable.bounds = it }
        return drawable as VectorDrawable
    }
}

internal fun vectorDrawable(context: Context, resourceId: Int, block: VectorDrawableBuilder.() -> Unit) =
    VectorDrawableBuilder(context, resourceId).apply(block).build()

@DrawableCreator
internal class LayerBuilder : DrawableEntryBuilder() {
    override val buildErrorMessage: String = "A layer must contain exactly one leaf drawable (gradient or vector)."

    var inset: Insets? = null
    var size: Size? = null

    data class Insets(
        val left: Int = 0,
        val top: Int = 0,
        val right: Int = 0,
        val bottom: Int = 0,
    ) {
        constructor(all: Int) : this(all, all, all, all)
    }

    /** Optional layer id (used with [LayerDrawable.findDrawableByLayerId]). */
    var layerId: Int = View.NO_ID

    fun stateList(block: StateListDrawableBuilder.() -> Unit) {
        drawableBuilder = StateListDrawableBuilder().apply(block)
    }
}

@DrawableCreator
internal class LayerDrawableBuilder : DrawableBuilder<LayerDrawable> {

    private val layers = mutableListOf<LayerBuilder>()

    /** Adds a new layer to the drawable. */
    fun layer(block: LayerBuilder.() -> Unit) {
        layers.add(LayerBuilder().apply(block))
    }

    override fun build(): LayerDrawable {
        require(layers.isNotEmpty()) { "LayerListDrawable must have at least one layer." }

        val drawables = layers.map { it.buildDrawable() }.toTypedArray()
        val layerDrawable = LayerDrawable(drawables)

        layers.forEachIndexed { index, layerBuilder ->
            layerBuilder.inset?.let { layerDrawable.setLayerInset(index, it.left, it.top, it.right, it.bottom) }
            layerBuilder.size?.let { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) layerDrawable.setLayerSize(index, it.width, it.height) }

            if (layerBuilder.layerId != View.NO_ID) {
                layerDrawable.setId(index, layerBuilder.layerId)
            }
        }

        return layerDrawable
    }
}

internal fun layerDrawable(block: LayerDrawableBuilder.() -> Unit) = LayerDrawableBuilder().apply(block).build()

@DrawableCreator
/**
 * State attributes to match, e.g.
 * `intArrayOf(android.R.attr.state_enabled)` or
 * `intArrayOf(-android.R.attr.state_enabled)` (negative = "not").
 *
 * An empty array is treated as the default/fallback state.
 */
internal class StateEntryBuilder(
    val states: IntArray = intArrayOf(),
) : DrawableEntryBuilder() {

    override val buildErrorMessage: String = "A state entry must define a drawable (gradient, vector, or layerList)."

    /** Attaches a [LayerDrawable] to this state. */
    @OptIn(ExperimentalContracts::class)
    fun layerList(block: LayerDrawableBuilder.() -> Unit) {
        drawableBuilder = LayerDrawableBuilder().apply(block)
    }
}

@DrawableCreator
internal class StateListDrawableBuilder : DrawableBuilder<StateListDrawable> {
    private val entries = mutableListOf<StateEntryBuilder>()

    /** Adds a state entry. Use an empty [StateEntryBuilder.states] for the default fallback. */
    fun state(states: IntArray = intArrayOf(), block: StateEntryBuilder.() -> Unit) {
        entries.add(StateEntryBuilder(states).apply(block))
    }

    fun state(state: Int, block: StateEntryBuilder.() -> Unit) {
        entries.add(StateEntryBuilder(intArrayOf(state)).apply(block))
    }

    override fun build(): StateListDrawable {
        val stateListDrawable = StateListDrawable()
        entries.forEach { entry ->
            stateListDrawable.addState(entry.states, entry.buildDrawable())
        }
        return stateListDrawable
    }
}

internal fun stateListDrawable(block: StateListDrawableBuilder.() -> Unit) = StateListDrawableBuilder().apply(block).build()
