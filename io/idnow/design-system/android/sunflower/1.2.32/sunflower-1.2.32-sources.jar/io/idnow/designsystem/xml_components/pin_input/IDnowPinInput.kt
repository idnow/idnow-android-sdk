package io.idnow.designsystem.xml_components.pin_input

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.os.CountDownTimer
import android.os.Parcelable
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.util.AttributeSet
import android.util.Log
import android.view.ActionMode
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.content.withStyledAttributes
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowPinInputBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.ControlStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp
import kotlinx.parcelize.Parcelize
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.properties.Delegates
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds

/**
 * The IDnowPinInput component.
 *
 * The method [linkInputKeyboard] should be called to use this component.
 *
 * The following attributes can be defined in XML:
 * - viewable - If the input can be viewed by the user
 * - last_box_viewable - If the last box is visible on user input
 * - last_box_visibility_millis - Delay after which the box is hidden. Does nothing if last_box_viewable is false.
 */
class IDnowPinInput @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr), IDnowMarginable {

    /** Listener for input updates. */
    interface InputListener {

        /** Called when a char has effectively been added. */
        fun added(c: Char)

        /** Called when the last box has effectively been removed. */
        fun removedLast()
    }

    private enum class Type { Hidden, Viewable, Visible }

    private val binding: IdnowPinInputBinding = IdnowPinInputBinding.inflate(LayoutInflater.from(context), this)

    private lateinit var type: Type
    private var isLastBoxViewable by Delegates.notNull<Boolean>()
    private var lastBoxHideDelay by Delegates.notNull<Duration>()

    private val inputController: InputController
    private val internalPasswordDrawable = IDnowPinDrawable()

    private var listener: InputListener? = null

    /** Used to dispatch pin container focus changes instead of parent to listener. */
    private var externalFocusListener: OnFocusChangeListener? = null

    /** Utility access function to get the currently displayed content. */
    val inputText get() = binding.idnowPinInputContainer.text.toString()

    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /**
     * Current size of the input.
     *
     * If this value is 0, this IDnowPinInput component is hidden.
     * When changing the value programmatically, the input field content is cleared.
     */
    var inputSize: Int = 0
        set(value) {
            binding.root.isVisible = value > 0
            if (value < 0) return

            field = value
            clearInput()
            with(binding.idnowPinInputContainer) {
                filters = arrayOf(*filters.filter { it !is InputFilter.LengthFilter }.toTypedArray() + InputFilter.LengthFilter(value))
            }
            setContentDescription()
        }

    /** Show/hide the error text group */
    var stateError: Boolean = false
        set(value) {
            field = value

            binding.idnErrorGroup.isVisible = field
            refreshDrawableState()

            internalPasswordDrawable.invalidateSelf()
        }

    /** Set the error text. */
    var errorText: CharSequence = ""
        set(value) {
            field = value
            binding.idnTvError.text = field
            setContentDescription()
        }

    /** Whether the input content is visible or not. This can be updated only if input type is viewable. */
    var isInputVisible: Boolean = false
        get() = when (type) {
            Type.Hidden -> false
            Type.Visible -> true
            Type.Viewable -> field
        }
        set(value) {
            if (type != Type.Viewable) return

            field = value
            val eye = if (field) R.drawable.sunflower_ic_eye_off else R.drawable.sunflower_ic_eye_on
            val contDesc = if (field) R.string.sunflower_hide_pin_input_content_description else R.string.sunflower_show_pin_input_content_description
            binding.idnowPinInputEyeIcon.apply {
                setImageDrawable(ContextCompat.getDrawable(context, eye))
                contentDescription = context.getString(contDesc)
            }
            inputController.updateInputVisibility(value)
        }

    var isInputEnabled: Boolean = true
        set(value) {
            field = value

            with(binding.idnowPinInputContainer) {
                isEnabled = value
                if (!value) clearFocus()
            }

            internalPasswordDrawable.invalidateSelf()
        }

    var inputType: Int = 0
        set(value) {
            field = value
            binding.idnowPinInputContainer.setInputType(value or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE)
        }

    /** Set an accessibility label that will be used to describe the type of code that need to be entered. */
    var accessibilityLabel: String = ""

    /**
     * This is the main logic handler of the pin input. It watches to text changes from container and apply a custom logic to its editable and the [boxes].
     */
    private inner class InputController : TextWatcher, IDnowPinKeyboard.Listener {
        private val hiddenChar = '•'

        /**
         * Acts as the content memory, because EditText cannot remember the hidden content.
         * This field is public, but only for restoration purposes and should not be updated outside InputController otherwise.
         */
        var boxes: List<IDnowPinBox> = listOf()
            set(value) {
                field = value
                binding.idnowPinInputContainer.setText(value.joinToString(separator = "") { (it.current() ?: hiddenChar).toString() })
                binding.idnowPinInputContainer.setSelection(value.size)
                internalPasswordDrawable.invalidateSelf()
            }

        private val factory = IDnowPinBox.factory(type != Type.Hidden)
        private val timer: CountDownTimer = object : CountDownTimer(lastBoxHideDelay.inWholeMilliseconds, lastBoxHideDelay.inWholeMilliseconds) {
            override fun onFinish() {
                if (boxes.isNotEmpty()) boxes = updateLastBox()
            }

            override fun onTick(millisUntilFinished: Long) {}
        }

        /**
         * Because pin container editable is programmatically updated, TextWatcher callback is called after update. To prevent an infinite loop, we use this
         * variable to check if the editable has been manually updated.
         */
        private var isResetting = false

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun afterTextChanged(s: Editable?) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            when {
                isResetting -> isResetting = false
                s == null || count == before -> {}
                // Input clear condition
                start == 0 && count == 0 -> {
                    isResetting = true
                    repeat((0 until before).count()) { listener?.removedLast() }
                    boxes = emptyList()
                }

                count == before + 1 -> addBoxContent(s.last())
                count == before - 1 -> removeLastBox()
                else -> {
                    isResetting = true
                    boxes = boxes
                }
            }
        }

        private fun addBoxContent(c: Char) {
            if (boxes.size >= inputSize || !isInputEnabled) return

            // Here the timer may not have finished, so we cancel the timer and force update the last box.
            timer.cancel()
            if (boxes.isNotEmpty()) updateLastBox()
            boxes += factory.create(c, isLastBoxViewable || isInputVisible)

            if (isLastBoxViewable && !isInputVisible) timer.start()
            listener?.added(c)
            setContentDescription()
        }

        private fun removeLastBox() {
            if (boxes.isEmpty() || !isInputEnabled) return

            timer.cancel()
            boxes = boxes.dropLast(1)
            listener?.removedLast()
            setContentDescription()
        }

        fun updateInputVisibility(isVisible: Boolean) {
            boxes = boxes.apply { forEach { box -> if (isVisible) box.show() else box.hide() } }
        }

        override fun addContent(c: Char) {
            with(binding.idnowPinInputContainer) {
                if (isEnabled) editableText.append(c)
            }
        }

        override fun removeLast() {
            with(binding.idnowPinInputContainer) {
                if (isEnabled) dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            }
        }

        private fun updateLastBox() = boxes.apply { if (isInputVisible) last().show() else last().hide() }
    }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowPinInput, defStyleAttr) {
            val margin = getInt(R.styleable.IDnowPinInput_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowPinInput_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowPinInput_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowPinInput_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowPinInput_token_endMargin, -1)
            margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)

            errorText = getString(R.styleable.IDnowPinInput_errorText) ?: ""
            stateError = getBoolean(R.styleable.IDnowPinInput_state_error, false)

            type = Type.entries[getInt(R.styleable.IDnowPinInput_type, Type.Viewable.ordinal)]
            isLastBoxViewable = getBoolean(R.styleable.IDnowPinInput_last_box_viewable, true)
            lastBoxHideDelay = max(getInt(R.styleable.IDnowPinInput_last_box_visibility_millis, 1000), 0).milliseconds

            inputSize = getInt(R.styleable.IDnowPinInput_pin_size, 0).takeIf { it != 0 || !isInEditMode } ?: 6

            inputType = getInt(R.styleable.IDnowPinInput_android_inputType, EditorInfo.TYPE_NULL)
        }

        /** Save should be disabled for the internal EditText, otherwise when it will restore it's state, it will fire the text changed listener.
        The actual state restoration is handled by the [inputController]. */
        binding.idnowPinInputContainer.isSaveEnabled = false
        inputController = InputController()

        with(binding.idnowPinInputEyeIcon) {
            isVisible = type == Type.Viewable

            if (type == Type.Viewable) {
                setOnClickListener {
                    isInputVisible = !isInputVisible
                    if (isInputVisible) {
                        announceForAccessibility(context.getString(R.string.sunflower_pin_input_visible))
                    } else {
                        announceForAccessibility(context.getString(R.string.sunflower_pin_input_hidden))
                    }
                }
            }
        }

        with(binding.idnowPinInputContainer) {
            customSelectionActionModeCallback = object : ActionMode.Callback {
                override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean = false
                override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean = false
                override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean = false
                override fun onDestroyActionMode(mode: ActionMode?) {}
            }

            background = internalPasswordDrawable
            onFocusChangeListener = OnFocusChangeListener { v, hasFocus ->
                externalFocusListener?.onFocusChange(v, hasFocus)
                internalPasswordDrawable.invalidateSelf()
            }

            addTextChangedListener(inputController)
        }
        setContentDescription()
    }

    /**
     * Fills the pin input with the given content.
     *
     * If the content is of different size as [inputSize], abort the fill operation.
     * If the input already has content this does nothing, but if [forceFill] is set, clears the previous content and fills with [content].
     */
    fun fillInput(content: CharArray, forceFill: Boolean = false) {
        if (content.size != inputSize) return
        if (inputText.isNotEmpty() && !forceFill) return

        clearInput()
        content.forEach { inputController.addContent(it) }
    }

    /**
     * Clears the input content.
     */
    fun clearInput() {
        binding.idnowPinInputContainer.text.clear()
    }

    fun addInputFilter(filter: InputFilter) {
        binding.idnowPinInputContainer.filters += filter
    }

    /**
     * Adds an input listener to listen for this input events.
     */
    fun setInputListener(listener: InputListener) {
        this.listener = listener
    }

    /**
     * Setups the pin input using a custom keyboard.
     */
    fun linkInputKeyboard(inputKeyboard: IDnowPinKeyboard) {
        inputKeyboard.addListener(inputController)
        with(binding.idnowPinInputContainer) {
            if (hasFocus()) {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.hideSoftInputFromWindow(windowToken, 0)
            }
            requestFocus()
            showSoftInputOnFocus = false
        }
    }

    /**
     * Unlink a previously linked custom keyboard.
     */
    fun unlinkInputKeyboard(inputKeyboard: IDnowPinKeyboard) {
        inputKeyboard.removeListener(inputController)
        with(binding.idnowPinInputContainer) {
            clearFocus()
            showSoftInputOnFocus = true
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        with(ControlStyle) {
            binding.idnIvError.imageTintList = ColorStateList.valueOf(errorColor)
            binding.idnTvError.apply {
                layoutParams = layoutParams.applyMargin(context, start = horItemMargin, bottom = verItemMargin(Size.NORMAL))
                setTypography(descFont(context))
                setTextColor(errorColor)
            }
        }

        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value, margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    override fun setOnFocusChangeListener(l: OnFocusChangeListener?) {
        externalFocusListener = l
    }

    private fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.idnowPinInputContainer, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.text = SpannableStringBuilder().apply {
                    append(accessibilityContentText())
                    if (inputText.isNotEmpty() && isInputVisible) {
                        append(info.text.asSequence().joinToString(separator = ". ", postfix = "."))
                    }
                }
                info.maxTextLength = accessibilityContentText().length + inputSize
            }
        })
    }

    /** Build the custom content description for accessibility. */
    private fun accessibilityContentText(): CharSequence {
        return SpannableStringBuilder().apply {
            if (accessibilityLabel.isNotEmpty()) {
                append("$accessibilityLabel${if (!accessibilityLabel.endsWith(".")) "." else ""} ")
            } else {
                append("${context.getString(R.string.sunflower_code_field)} ")
            }
            append("${context.getString(R.string.sunflower_number_of_digits, inputSize.toString())} ")
            if (stateError && errorText.isNotEmpty()) {
                append("${context.getString(R.string.sunflower_warning)}. ")
                append("$errorText${if (!errorText.endsWith(".")) "." else ""} ")
            }
        }
    }

    /** Use this method to reset the focus to this edit text. */
    fun requestFocusForAccessibility() {
        binding.idnowPinInputContainer.apply {
            requestFocus()
            sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
        }
    }

    // ===== STATE RESTORATION ===== //

    override fun onSaveInstanceState(): Parcelable {
        return SavedState(
            superState = super.onSaveInstanceState(),
            inputSize = inputSize,
            stateError = stateError,
            errorText = errorText,
            isInputVisible = isInputVisible,
            isInputEnabled = isInputEnabled,
            inputContent = inputController.boxes,
        )
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is SavedState) {
            super.onRestoreInstanceState(state)
            return
        }

        super.onRestoreInstanceState(state.superState)
        this.inputSize = state.inputSize
        this.stateError = state.stateError == true
        this.errorText = state.errorText ?: ""
        this.isInputEnabled = state.isInputEnabled == true

        /** Restoration order is **IMPORTANT**: Boxes should be restored first, and input visibility will handle the actual update by side effect. */
        this.inputController.boxes = state.inputContent
        this.isInputVisible = state.isInputVisible == true
    }

    @Parcelize
    internal class SavedState(
        @Suppress("CanBeParameter", "RedundantSuppression")
        private val superState: Parcelable?,
        val inputSize: Int = 0,
        val stateError: Boolean? = null,
        val errorText: CharSequence? = null,
        val isInputVisible: Boolean? = null,
        val isInputEnabled: Boolean? = null,
        val inputContent: List<IDnowPinBox> = emptyList(),
    ) : BaseSavedState(superState)

    // ===== PIN DRAWABLE ===== //

    private inner class IDnowPinDrawable(
        typography: Typography = Typography.BodyBoldLarge(context),
        boxInternalPadding: Int = Tokens.spacingSm,
        interspersePadding: Int = Tokens.spacingSm,
    ) : Drawable() {

        private val boxOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
        }

        private val density: Float = context.resources.displayMetrics.density
        private val contentPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Tokens.inputText
            typeface = typography.typeface
            isFakeBoldText = false
            textSize = typography.size * density
        }

        private val boxInternalPaddingDp = boxInternalPadding.toDp(context)
        private val interspersePaddingDp = interspersePadding.toDp(context)

        // Default box width. This value is taken from Figma.
        private val defaultBoxContentSize = 24.toDp(context).toFloat()
        private val width: Int
            get() {
                // The internal padding is applied twice horizontally, before and after box content.
                val internalPaddingTotal = inputSize * (boxInternalPaddingDp * 2)
                // To intersperse should be applied between each box.
                val interspersePaddingTotal = (inputSize - 1) * interspersePaddingDp
                // The total width occupied by the box character content.
                val inputCharsTotal = inputSize * defaultBoxContentSize

                return (inputCharsTotal + interspersePaddingTotal + internalPaddingTotal).roundToInt()
            }
        private val height: Int = with(contentPaint.fontMetrics) {
            // The internal padding is applied twice vertically, above and below text.
            val internalPaddingTotal = boxInternalPaddingDp * 2
            val lineHeight = bottom - top

            (lineHeight * typography.lineSpacingMultiplier + internalPaddingTotal).roundToInt()
        }

        override fun draw(canvas: Canvas) {
            var currentWidth = 0f
            val currentInputSize = inputText.length

            for (i in 0 until inputSize) {
                if (i != 0) currentWidth += interspersePaddingDp

                val contentDrawWidth = currentWidth + boxInternalPaddingDp
                val finalContentDrawWidth = contentDrawWidth + defaultBoxContentSize + boxInternalPaddingDp

                val isFocused = binding.idnowPinInputContainer.isFocused
                val isEnabled = binding.idnowPinInputContainer.isEnabled
                val style = when {
                    !isEnabled -> ContainerStyle.Disabled
                    (i == currentInputSize || (i == (currentInputSize - 1) && i == (inputSize - 1))) && isFocused -> ContainerStyle.Filling
                    stateError -> ContainerStyle.Error
                    else -> ContainerStyle.Empty
                }
                boxOutlinePaint.style = if (isEnabled) Paint.Style.STROKE else Paint.Style.FILL

                val radius = ContainerStyle.cornerRadius.toDp(context).toFloat()
                val strokeWidth = style.strokeWidth.toDp(context).toFloat()
                val halfStrokeWidth = strokeWidth / 2f

                boxOutlinePaint.color = style.strokeColor
                boxOutlinePaint.strokeWidth = strokeWidth
                canvas.drawRoundRect(
                    currentWidth + halfStrokeWidth,
                    halfStrokeWidth,
                    finalContentDrawWidth - halfStrokeWidth,
                    height - halfStrokeWidth,
                    radius,
                    radius,
                    boxOutlinePaint
                )

                if (i < currentInputSize) {
                    Log.d("IDnowPinInput", "drawing[$i]=${inputText[i]}, box=${inputController.boxes[i]}")
                    drawChar(canvas, inputText[i], contentDrawWidth)
                }

                currentWidth = finalContentDrawWidth
            }
        }

        private fun drawChar(canvas: Canvas, c: Char, currentWidth: Float) {
            val char = c.toString()
            val textBaseline = (height / 2F) - (contentPaint.fontMetrics.ascent / 2f)
            val charMargin = defaultBoxContentSize - contentPaint.measureText(char)

            canvas.drawText(char, currentWidth + charMargin / 2, textBaseline, contentPaint)
        }

        override fun getIntrinsicWidth(): Int = width

        override fun getIntrinsicHeight(): Int = height

        override fun setAlpha(alpha: Int) {}

        @Deprecated("Deprecated in Java, not used anymore", ReplaceWith("PixelFormat.TRANSLUCENT", "android.graphics.PixelFormat"))
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

        override fun setColorFilter(colorFilter: ColorFilter?) {}
    }
}
