package io.idnow.designsystem.xml_components.controls.check_box

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatCheckBox
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.ControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.DrawableEntryBuilder
import io.idnow.designsystem.xml_components.extension.GradientDrawableBuilder
import io.idnow.designsystem.xml_components.extension.StateEntryBuilder
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.size
import io.idnow.designsystem.xml_components.extension.stateListDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp


internal class IDnowCheckBoxInternal : AppCompatCheckBox {
    /** The custom indeterminate state reference */
    private val stateIndeterminate = intArrayOf(R.attr.state_indeterminate)

    /** Current state of the checkbox */
    var checkState: CheckState = CheckState.UNCHECKED
        set(value) {
            field = value
            refreshDrawableState()
        }

    /** Check change listener */
    var onCheckChangeListener: OnCheckChangeListener? = null

    /** Internal usage only ! Notify a control of a change. */
    var onInternalChange: (() -> Unit)? = null

    /** Size of the check box */
    var size: Size = Size.NORMAL
        set(value) {
            field = value
            setupDrawable()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    private fun setupDrawable() {
        buttonDrawable = stateListDrawable {
            val checkboxSize = ControlStyle.controlSize(this@IDnowCheckBoxInternal.size).toDp(context)
            fun DrawableEntryBuilder.outline(block: GradientDrawableBuilder.() -> Unit) = gradient {
                size(checkboxSize)
                cornerRadius(ControlStyle.checkBoxRadius(this@IDnowCheckBoxInternal.size).toDp(context).toFloat())
                block()
            }

            fun StateEntryBuilder.filled(icon: Int) = layerList {
                layer {
                    outline { color(argb = ControlStyle.activeColor) }
                }
                layer {
                    size = android.util.Size(checkboxSize, checkboxSize)
                    vector(context, icon) {
                        tintColor = ControlStyle.iconColor
                    }
                }
            }

            state(states = intArrayOf(android.R.attr.state_checked)) {
                filled(R.drawable.sunflower_ic_check)
            }

            state(states = intArrayOf(R.attr.state_indeterminate)) {
                filled(R.drawable.sunflower_ic_minus)
            }

            state {
                outline { stroke(color = ControlStyle.strokeColor, width = ControlStyle.strokeWidth().toDp(context)) }
            }
        }
    }

    /**
     * Add the indeterminate state to the current state list if it has been set.
     */
    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        val drawableStates = super.onCreateDrawableState(extraSpace + 1)
        if (checkState == CheckState.INDETERMINATE) {
            mergeDrawableStates(drawableStates, stateIndeterminate)
        }
        return drawableStates
    }


    override fun isChecked(): Boolean = checkState == CheckState.CHECKED

    override fun toggle() {
        isChecked = !isChecked
    }

    override fun setChecked(checked: Boolean) {
        /** If the checkbox is disabled, check state can't be updated. */
        if (!isEnabled) return

        checkState = (if (checked) CheckState.CHECKED else CheckState.UNCHECKED)
        /** Notify internally */
        onInternalChange?.invoke()
        /** Notify of state changes. */
        onCheckChangeListener?.onCheckChange(checked)
        super.setChecked(checked)
        refreshDrawableState()
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ControlStyle.opacity(enabled)
    }
}