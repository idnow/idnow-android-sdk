package io.idnow.designsystem.xml_components.navigation.menu

import android.content.Context
import android.graphics.drawable.Drawable
import android.text.SpannableStringBuilder
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.content.withStyledAttributes
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils.adjustAlpha
import io.idnow.designsystem.databinding.IdnowMenuItemBinding
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyPadding
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.stateListDrawable

class IDnowMenuItem @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr) {
    private val binding = IdnowMenuItemBinding.inflate(LayoutInflater.from(context), this)

    var title: CharSequence = ""
        set(value) {
            field = value
            binding.idnMenuItemTitle.text = value
            setContentDescription()
        }

    var description: CharSequence? = null
        set(value) {
            field = value
            binding.idnMenuItemDescription.isVisible = value != null
            binding.idnMenuItemDescription.text = value
            setContentDescription()
        }

    var startIcon: Drawable?
        get() = binding.idnStartIcon.drawable
        set(value) {
            binding.idnStartIcon.isVisible = value != null
            binding.idnStartIcon.setImageDrawable(value)
        }

    var endIcon: Drawable?
        get() = binding.idnEndIcon.drawable
        set(value) {
            binding.idnEndIcon.isVisible = value != null
            binding.idnEndIcon.setImageDrawable(value)
        }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowMenuItem, defStyleAttr) {
            title = getString(R.styleable.IDnowMenuItem_title) ?: ""
            description = getString(R.styleable.IDnowMenuItem_description)
            startIcon = getDrawable(R.styleable.IDnowMenuItem_startIcon)
            endIcon = getDrawable(R.styleable.IDnowMenuItem_endIcon) ?: ContextCompat.getDrawable(context, R.drawable.sunflower_ic_chevron_right)
        }

        isClickable = true
        background = stateListDrawable {
            state(states = intArrayOf(android.R.attr.state_pressed)) {
                gradient { color(adjustAlpha(Tokens.accent, 0.05f)) }
            }
        }

        val margins = SpacingQuad().handleMargins(SpacingEnum.SPACING_MD.ordinal, -1, -1, -1, -1)
        applyPadding(margins.start.value, margins.top.value, margins.end.value, margins.bottom.value)
    }

    private fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.root, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = SpannableStringBuilder().apply {
                    if (title.isNotEmpty()) append("${title.withEndDot()} ")
                    description?.takeIf { it.isNotEmpty() }?.let { append("${it.withEndDot()} ") }
                    append("${resources.getString(R.string.sunflower_menu_item)} ")
                    if (!isEnabled) append(context.getString(R.string.sunflower_disabled))
                }
            }
        })
    }

    private fun CharSequence.withEndDot() = "${this}${if (!endsWith(".")) "." else ""}"
}