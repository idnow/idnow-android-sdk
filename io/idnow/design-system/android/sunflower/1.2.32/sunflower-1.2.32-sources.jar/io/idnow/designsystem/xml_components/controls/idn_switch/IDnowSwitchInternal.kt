package io.idnow.designsystem.xml_components.controls.idn_switch

import android.content.Context
import android.util.AttributeSet
import android.view.accessibility.AccessibilityEvent
import androidx.appcompat.widget.SwitchCompat
import io.idnow.designsystem.styles.ControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.LayerBuilder
import io.idnow.designsystem.xml_components.extension.StateEntryBuilder
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.layerDrawable
import io.idnow.designsystem.xml_components.extension.size
import io.idnow.designsystem.xml_components.extension.stateListDrawable
import io.idnow.designsystem.xml_components.extension.toDp

internal class IDnowSwitchInternal : SwitchCompat {
    /** Internal usage only ! Notify a control of a change. */
    var onInternalChange: (() -> Unit)? = null

    /** Size of the switch */
    var size: Size = Size.NORMAL
        set(value) {
            field = value
            setupDrawable()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        initialize()
    }

    private fun initialize() {
        /** No Text required for ON and OFF states */
        textOn = ""
        textOff = ""
        /** Prevent switch to expand to larger width when custom track and thumb drawables are used */
        setEnforceSwitchWidth(false)
    }

    private fun setupDrawable() {
        /**
         * To update the width we have to update the switchMinWidth parameter
         * as it's the one that will be used by the onMeasure while drawing the view
         */
        switchMinWidth = ControlStyle.toggleWidth(size).toDp(context)
        val toggleWidth = ControlStyle.toggleWidth(size).toDp(context)
        val toggleHeight = ControlStyle.toggleHeight(size).toDp(context)

        trackDrawable = stateListDrawable {
            fun StateEntryBuilder.background(color: Int) = gradient {
                size(width = toggleWidth, height = toggleHeight)
                cornerRadius(toggleHeight / 2f)
                color(argb = color)
            }

            state(states = intArrayOf(android.R.attr.state_checked)) { background(ControlStyle.activeColor) }
            state { background(ControlStyle.uncheckedColor) }
        }

        val thumbSize = ControlStyle.thumbSize(size).toDp(context)
        thumbDrawable = layerDrawable {
            layer {
                inset = LayerBuilder.Insets(2.toDp(context))
                gradient {
                    size(thumbSize)
                    cornerRadius(thumbSize / 2f)
                    color(argb = ControlStyle.toggleKnobColor)
                }
            }
        }
    }

    override fun toggle() {
        /* Only trigger the state changes if the radio is enabled */
        if (isEnabled) {
            isChecked = !isChecked
            sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_CLICKED)
        }
    }

    override fun setChecked(checked: Boolean) {
        /** Notify internally */
        onInternalChange?.invoke()
        super.setChecked(checked)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ControlStyle.opacity(enabled)
    }
}