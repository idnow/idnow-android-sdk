package io.idnow.designsystem.xml_components.alert

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.graphics.ColorUtils
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowAlertBinding
import io.idnow.designsystem.styles.AlertBoxAndTagStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.UnitLambda
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.colorStateList
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.gradientDrawable
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp

class IDnowAlertTag : ConstraintLayout, IDnowMarginable {

    /** The actual layout for this alert tag */
    private val binding = IdnowAlertBinding.inflate(LayoutInflater.from(context), this)

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** The alert type; Based on this a custom bgColor and leftIcon will be set */
    var alertType: IDnowAlertType = IDnowAlertType.INFO
        set(value) {
            field = value
            initialize()
        }

    /** The alert tag text */
    var text: CharSequence
        get() = binding.idnTvMessage.text?.toString().orEmpty()
        set(value) {
            binding.idnTvMessage.text = value
            setContentDescription()
        }

    /** Show or hide the start icon */
    var startIcon: Drawable?
        get() = binding.idnStartIcon.drawable
        set(value) {
            binding.idnStartIcon.isVisible = value != null
            binding.idnStartIcon.setImageDrawable(value)
            applyTextMargins()
        }

    /** Callback for close click */
    var onTagClick: UnitLambda = {}

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        context.withStyledAttributes(attrs, R.styleable.IDnowAlertTag) {
            /** Handle the component margin. */
            val margin = getInt(R.styleable.IDnowAlertTag_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowAlertTag_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowAlertTag_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowAlertTag_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowAlertTag_token_endMargin, -1)
            margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
            text = getString(R.styleable.IDnowAlertTag_text) ?: ""
            startIcon = getDrawable(R.styleable.IDnowAlertTag_startIcon)
            alertType = IDnowAlertType.entries[getInt(R.styleable.IDnowAlertTag_alert_box_type, IDnowAlertType.INFO.ordinal)]
        }
    }

    private fun initialize() {
        with(AlertBoxAndTagStyle) {
            binding.root.background = gradientDrawable {
                val states = arrayOf(intArrayOf(android.R.attr.state_pressed), intArrayOf())
                val colors = intArrayOf(alertType.color(), ColorUtils.blendARGB(alertType.color(), Tokens.background, 1 - bgColorOpacity))
                colorStateList(ColorStateList(states, colors))
                cornerRadius(cornerRadiusTag.toDp(context).toFloat())
            }

            /** Set general padding inside the tag */
            binding.root.apply {
                setPadding(tagItemMargin.toDp(context))
                setOnClickListener { onTagClick() }
            }

            /** Customize the message textView */
            applyTextMargins()
            binding.idnTvMessage.apply {
                setTextColor(textColor)
                setTypography(tagTextFont(context))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            /** Customize the left icon */
            binding.idnStartIcon.apply {
                layoutParams = layoutParams.apply {
                    width = alertIconSize.toDp(context)
                    height = alertIconSize.toDp(context)
                    //constrain left icon to bottom of parent so it will be vertically aligned
                    (this as LayoutParams).bottomToBottom = LayoutParams.PARENT_ID
                }
            }
        }
        /** Set content description */
        setContentDescription()
    }

    /** Apply left text margin based on weather left icon is visible or not  */
    private fun applyTextMargins() {
        binding.idnTvMessage.apply {
            layoutParams = layoutParams.applyMargin(
                context = context,
                start = if (startIcon != null) AlertBoxAndTagStyle.tagInnerItemMargin else 0,
            )
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(
            context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value
        )
        super.setLayoutParams(mParams)
    }

    /** Set a custom description for accessibility. */
    private fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.root, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = SpannableStringBuilder().apply {
                    append(accessibilityAlertInfo())
                    append(text)
                }
            }
        })
    }

    /** Retrieve the alert info text for accessibility. */
    private fun accessibilityAlertInfo(): String {
        return when (alertType) {
            IDnowAlertType.INFO -> context.getString(R.string.sunflower_information)
            IDnowAlertType.ERROR -> context.getString(R.string.sunflower_error)
            IDnowAlertType.WARNING -> context.getString(R.string.sunflower_warning)
            IDnowAlertType.SUCCESS -> context.getString(R.string.sunflower_success)
        }.plus(" ")
    }
}