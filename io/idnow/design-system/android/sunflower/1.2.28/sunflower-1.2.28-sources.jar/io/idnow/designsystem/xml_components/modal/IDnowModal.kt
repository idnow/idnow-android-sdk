package io.idnow.designsystem.xml_components.modal

import android.app.Dialog
import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.WindowInsets
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.WRAP_CONTENT
import androidx.annotation.DrawableRes
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import androidx.constraintlayout.widget.ConstraintLayout.LayoutParams
import androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.MATCH_CONSTRAINT
import androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID
import androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.UNSET
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.doOnNextLayout
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.databinding.IdnowModalBinding
import io.idnow.designsystem.styles.ModalStyle
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.modal.IDnowModal.Button.CLOSE
import io.idnow.designsystem.xml_components.modal.IDnowModal.Button.NEGATIVE
import io.idnow.designsystem.xml_components.modal.IDnowModal.Button.POSITIVE

/**
 * This is the idnow modal.
 * The modal can be configured and shown using a [Builder].
 */
class IDnowModal private constructor(context: Context) : Dialog(context) {
    var binding = IdnowModalBinding.inflate(LayoutInflater.from(context))
    /** Modal title */
    var title: String? = null
        set(value) {
            field = value
            binding.idnowModalTitle.text = value
        }
    /** Modal title icon */
    var icon: Drawable? = null
        set(value) {
            field = value
            binding.idnowModalIcon.apply {
                updateHeader()
            }
        }
    /** Is the close button visible. */
    var isCloseButtonVisible: Boolean = true
        set(value) {
            field = value
            binding.idnowModalCloseButton.isVisible = value && isHeaderVisible
            updateHeader()
        }
    /** Set a on click listener to the modal close button. */
    var closeButtonOnClickListener: OnClickListener? = null
        set(value) {
            field = value
            binding.idnowModalCloseButton.setOnClickListener(value ?: defaultClickListener)
        }
    /** Display the modal header */
    var isHeaderVisible = true
        set(value) {
            field = value
            updateHeader()
            updateDividers()
        }
    /** Content view, you can update it but can't change it. */
    var content: View? = null
        private set
    /** Display the modal footer */
    var isFooterVisible = true
        set(value) {
            field = value
            binding.apply {
                idnowModalNegativeButton.isVisible = value && !negativeButtonTitle.isNullOrEmpty()
                idnowModalPositiveButton.isVisible = value && !positiveButtonTitle.isNullOrEmpty()
            }
            updateDividers()
        }
    /** Negative button text, the buttons will only be displayed of they have a text. */
    var negativeButtonTitle: String? = null
        set(value) {
            field = value
            binding.idnowModalNegativeButton.apply {
                text = value
                isVisible = !value.isNullOrEmpty() && isFooterVisible
                checkButtonMargin()
            }
        }
    /** Positive button text, the buttons will only be displayed of they have a text. */
    var positiveButtonTitle: String? = null
        set(value) {
            field = value
            binding.idnowModalPositiveButton.apply {
                text = value
                isVisible = !value.isNullOrEmpty() && isFooterVisible
                checkButtonMargin()
            }
        }
    /** Negative button start icon, null to remove. */
    var negativeButtonIcon: Drawable? = null
        set(value) {
            field = value
            binding.idnowModalNegativeButton.setCompoundDrawablesRelative(value, null, null, null)
        }
    /** Positive button start icon, null to remove */
    var positiveButtonIcon: Drawable? = null
        set(value) {
            field = value
            binding.idnowModalPositiveButton.setCompoundDrawablesRelative(value, null, null, null)
        }
    /** Set a on click listener to the modal negative button */
    var negativeButtonOnClickListener: OnClickListener? = null
        set(value) {
            field = value
            binding.idnowModalNegativeButton.setOnClickListener(value ?: defaultClickListener)
        }
    /** Set a on click listener to the modal positive button */
    var positiveButtonOnClickListener: OnClickListener? = null
        set(value) {
            field = value
            binding.idnowModalPositiveButton.setOnClickListener(value ?: defaultClickListener)
        }

    var positiveButtonType: ButtonFillType = ButtonFillType.FILL
        set(value) {
            field = value
            binding.idnowModalPositiveButton.updateLayoutParams {
                width = if(value == ButtonFillType.WRAP) WRAP_CONTENT else MATCH_CONSTRAINT
            }
        }

    var negativeButtonType: ButtonFillType = ButtonFillType.FILL
        set(value) {
            field = value
            binding.idnowModalNegativeButton.updateLayoutParams {
                width = if(value == ButtonFillType.WRAP) WRAP_CONTENT else MATCH_CONSTRAINT
            }
        }


    /** Default click listener for all buttons. */
    private val defaultClickListener = OnClickListener { dismiss() }
    /** endregion Private Properties */

    /** region Public enums */
    enum class Button {
        CLOSE,
        NEGATIVE,
        POSITIVE
    }

    enum class ButtonFillType {
        WRAP,
        FILL
    }
    /** endregion Public enums */

    /** region Override methods */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(binding.root)

        setCancelable(false)
        initialize()
    }
    /** endregion Override methods */

    /** region Private methods */
    private fun initialize() {
        initializeWindowMargins()
        updateHeader()
        initializeContent()
        updateDividers()
    }

    private fun initializeWindowMargins() {
        val window = window ?: return

        with(ModalStyle) {
            // Get the width of the screen
            val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            val screenWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val metrics = windowManager.currentWindowMetrics
                val insets = metrics.windowInsets.getInsets(WindowInsets.Type.systemBars())
                metrics.bounds.width() - insets.left - insets.right
            } else {
                val displayMetrics = DisplayMetrics()
                windowManager.defaultDisplay.getMetrics(displayMetrics)
                displayMetrics.widthPixels
            }

            // Apply margins only if the screen width is not equal to 0.
            if (screenWidth == 0) return

            // Apply margins
            val layoutParams = window.attributes
            layoutParams.width = screenWidth - (2 * modalHorizontalMargin(context))
            layoutParams.height = WRAP_CONTENT

            // Apply background
            val background = ResourcesCompat.getDrawable(context.resources, R.drawable.idnow_modal_background, null)
            (background as StateListDrawable).apply {
                customize(solidColor = backgroundColor, cornerRadius = cornerRadius(context), indexChild = 0)
            }

            window.setBackgroundDrawable(background)

            // Set the layout parameters
            window.attributes = layoutParams
        }
    }

    /** Reapply constraint based on visibility. It has to be called every time the visibility of a header's component change. */
    private fun updateHeader() {
        with(binding) {
            // Icon
            idnowModalIcon.apply {
                isVisible = isHeaderVisible && icon != null
                setImageDrawable(icon)
            }

            // Close button
            idnowModalCloseButton.apply {
                isVisible = isHeaderVisible && isCloseButtonVisible
                setColorFilter(ModalStyle.closeButtonTintColor)

                val closeListener = closeButtonOnClickListener ?: defaultClickListener
                setOnClickListener(closeListener)
            }

            // Title
            idnowModalTitle.apply {
                isVisible = isHeaderVisible
                text = title
                margins = ModalStyle.titleMargins(idnowModalIcon.isVisible, idnowModalCloseButton.isVisible)
            }
        }
    }

    private fun initializeContent() {
        val content = content ?: return

        with(binding) {
            with(ModalStyle) {
                // Create a layoutParams, that will be applied to the content
                val params = LayoutParams(MATCH_CONSTRAINT, WRAP_CONTENT).apply {
                    // Layout constraints
                    topToBottom = idnowModalFirstDivider.id
                    startToStart = PARENT_ID
                    endToEnd = PARENT_ID

                    // Margins
                    applyMargin(
                        context = context,
                        start = contentStartMargin.value,
                        top = contentTopMargin.value,
                        end = contentEndMargin.value,
                        bottom = contentBottomMargin.value
                    )
                }

                content.apply {
                    // Add a custom id to the content
                    id = R.id.idn_modal_content_id

                    // If the content is an IDnowMarginable, we need to set its margins using the "margins" parameter
                    if (this is IDnowMarginable) {
                        margins = contentMargins
                    }
                }

                // Add the content to the view
                root.addView(content, params)
            }
        }
    }

    /** Update the button margin base on button visibility. */
    private fun checkButtonMargin() {
        with(binding) {
            if(!idnowModalPositiveButton.isVisible && idnowModalNegativeButton.isVisible) {
                idnowModalNegativeButton.margins = idnowModalNegativeButton.margins.copy(end = SpacingEnum.NO_SPACING)
            } else {
                idnowModalNegativeButton.margins = idnowModalNegativeButton.margins.copy(end = SpacingEnum.SPACING_MD)
            }
        }
    }

    private fun updateDividers() {
        with(binding) {
            // First divider
            idnowModalFirstDivider.isVisible = isHeaderVisible && (content != null || isFooterVisible)

            // Second divider
            idnowModalSecondDivider.isVisible = content != null && isFooterVisible

            // If the second modal disappear, stick the content to the bottom.
            content?.apply {
                layoutParams?.let {
                    layoutParams = (it as LayoutParams).apply {
                        bottomToBottom = if(!idnowModalSecondDivider.isVisible) {
                            PARENT_ID
                        } else {
                            (idnowModalSecondDivider.layoutParams as? LayoutParams)?.topToBottom = id
                            UNSET
                        }
                    }
                }
            }
        }
    }
    /** endregion Private methods */

    /**
     * This builder builds an [IDnowModal].
     * First, create a builder with a [context].
     * Then, set all the parameters you need, using the methods bellow.
     * Finally, build the modal using the [build] method, and show it using the [show] method.
     *
     * @see setTitle
     * @see setIcon
     * @see setCloseButtonOnClickListener
     * @see setHeaderVisible
     * @see setContent
     * @see setFooterVisible
     * @see setNegativeButton
     * @see setPositiveButton
     * @see build
     *
     */
    class Builder(val context: Context) {
        /** region Private properties */
        private val modal = IDnowModal(context)
        /** endregion Private properties */

        /** region Public methods */
        /**
         * Sets the title of the modal.
         * @param titleId String resource of the modal's title. If null, the title is hidden.
         */
        fun setTitle(@StringRes titleId: Int?): Builder {
            return setTitle(titleId?.let { context.resources.getString(it) })
        }

        /** region Public methods */
        /**
         * Sets the title of the modal.
         * @param title Title of the modal. If null, the title is hidden.
         */
        fun setTitle(title: String?): Builder {
            modal.title = title
            return this
        }

        /**
         * Sets the icon of the modal.
         * @param iconId Drawable resource to put in the modal. If null, the icon is hidden.
         */
        fun setIcon(@DrawableRes iconId: Int?): Builder {
            val icon = iconId?.let { ResourcesCompat.getDrawable(context.resources, it, null) }
            return setIcon(icon)
        }

        /**
         * Sets the icon of the modal.
         * @param icon Drawable to put in the modal. If null, the icon is hidden.
         */
        fun setIcon(icon: Drawable?): Builder {
            modal.icon = icon
            return this
        }

        /**
         * Show/Hide the close button.
         * Visible by default.
         */
        fun setCloseButtonVisibility(isVisible: Boolean): Builder {
            modal.isCloseButtonVisible = isVisible
            return this
        }

        /**
         * Sets the close button listener.
         * @param listener Listener of the close button.
         * Do not forget to call the "dismiss" method
         */
        fun setCloseButtonOnClickListener(listener: ((IDnowModal, Button) -> Unit)): Builder {
            modal.closeButtonOnClickListener = OnClickListener {
                listener(modal, CLOSE)
            }
            return this
        }

        /**
         * Sets either the the modal's header is hidden or not.
         * @param isVisible If true, the header is visible.
         */
        fun setHeaderVisible(isVisible: Boolean): Builder {
            modal.isHeaderVisible = isVisible
            return this
        }

        /**
         * Sets the custom content of the modal, that is set between the header and the footer.
         * @param contentId Layout resource that will be put in the modal.
         */
        fun setContent(@LayoutRes contentId: Int): Builder {
            val layoutInflater = LayoutInflater.from(context)
            val content = layoutInflater.inflate(contentId, null)
            return setContent(content)
        }

        /**
         * Sets the custom content of the modal, that is set between the header and the footer.
         * @param content Custom view that will be put in the modal.
         */
        fun setContent(content: View?): Builder {
            modal.content = content
            return this
        }

        /**
         * Sets either the the modal's footer is hidden or not.
         * @param isVisible If true, the footer will be hidden
         */
        fun setFooterVisible(isVisible: Boolean): Builder {
            modal.isFooterVisible = isVisible
            return this
        }

        /**
         * Sets the negative button.
         *  @param textId String resource of the negative button.
         *      If null, the negative button is hidden.
         *  @param iconId Drawable resource of the negative button's icon.
         *      The icon will be put at the left of the button.
         *      If null, the icon is hidden
         *  @param buttonFillType change the behavior of the button between wrap and fill
         *  @param listener Listener of the negative button.
         *      If null, when the user clicks the negative button, the modal is dismissed
         *      Do not forget to call the "dismiss" method if you use a listener
         */
        fun setNegativeButton(
            @StringRes textId: Int? = null,
            @DrawableRes iconId: Int? = null,
            buttonFillType: ButtonFillType = ButtonFillType.FILL,
            listener: ((IDnowModal, Button) -> Unit)? = null
        ): Builder {
            return setNegativeButton(
                textId?.let { context.resources.getString(it) },
                iconId?.let { ResourcesCompat.getDrawable(context.resources, iconId, null) },
                buttonFillType,
                listener
            )
        }

        /**
         * Sets the negative button.
         *  @param text Title of the negative button.
         *      If null, the negative button is hidden.
         *  @param icon Drawable of the negative button's icon.
         *      The icon will be put at the left of the button.
         *      If null, the icon is hidden
         *  @param buttonFillType change the behavior of the button between wrap and fill
         *  @param listener Listener of the negative button.
         *      If null, when the user clicks the negative button, the modal is dismissed
         *      Do not forget to call the "dismiss" method if you use a listener
         */
        fun setNegativeButton(
            text: String? = null,
            icon: Drawable? = null,
            buttonFillType: ButtonFillType = ButtonFillType.FILL,
            listener: ((IDnowModal, Button) -> Unit)? = null
        ): Builder {
            modal.negativeButtonTitle = text
            modal.negativeButtonIcon = icon
            modal.negativeButtonType = buttonFillType
            modal.negativeButtonOnClickListener = OnClickListener {
                listener?.let { it(modal, NEGATIVE) } ?: modal.dismiss()
            }
            return this
        }

        /**
         * Sets the negative button.
         *  @param textId String resource of the positive button.
         *      If null, the positive button is hidden.
         *  @param iconId Drawable resource of the positive button's icon.
         *      The icon will be put at the left of the button.
         *      If null, the icon is hidden
         *  @param buttonFillType change the behavior of the button between wrap and fill
         *  @param listener Listener of the positive button.
         *      If null, when the user clicks the negative button, the modal is dismissed
         *      Do not forget to call the "dismiss" method if you use a listener
         */
        fun setPositiveButton(
            @StringRes textId: Int? = null,
            @DrawableRes iconId: Int? = null,
            buttonFillType: ButtonFillType = ButtonFillType.FILL,
            listener: ((IDnowModal, Button) -> Unit)? = null
        ): Builder {
            return setPositiveButton(
                textId?.let { context.resources.getString(it) },
                iconId?.let { ResourcesCompat.getDrawable(context.resources, iconId, null) },
                buttonFillType,
                listener
            )
        }

        /**
         * Sets the negative button.
         *  @param text Title of the positive button.
         *      If null, the negative button is hidden.
         *  @param icon Drawable of the positive button's icon.
         *      The icon will be put at the left of the button.
         *      If null, the icon is hidden
         *  @param buttonFillType change the behavior of the button between wrap and fill
         *  @param listener listener of the positive button.
         *      If null, when the user clicks the negative button, the modal is dismissed
         *      Do not forget to call the "dismiss" method if you use a listener
         */
        fun setPositiveButton(
            text: String? = null,
            icon: Drawable? = null,
            buttonFillType: ButtonFillType = ButtonFillType.FILL,
            listener: ((IDnowModal, Button) -> Unit)? = null
        ): Builder {
            modal.positiveButtonTitle = text
            modal.positiveButtonIcon = icon
            modal.positiveButtonType = buttonFillType
            modal.positiveButtonOnClickListener = OnClickListener {
                listener?.let { it(modal, POSITIVE) } ?: modal.dismiss()
            }
            return this
        }

        /**
         * Creates an [IDnowModal] with the arguments supplied to this builder.
         * Calling this method does not display the modal. If no additional
         * processing is needed, [show] may be called instead to both create and display the modal.
         */
        fun create(): IDnowModal {
            return modal
        }

        /**
         * Creates an [IDnowModal] with the arguments supplied to thi builder and immediately displays the modal.
         */
        fun show(): IDnowModal {
            create().show()
            return modal
        }
        /** endregion Public methods */
    }
}