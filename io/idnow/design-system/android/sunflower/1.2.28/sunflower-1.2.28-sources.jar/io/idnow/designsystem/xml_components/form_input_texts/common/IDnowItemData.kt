package io.idnow.designsystem.xml_components.form_input_texts.common

/**
 * General interface for defining data to be used in adapters
 */
interface IDnowItemData {
    val icon: Int?
    val content: String?
}