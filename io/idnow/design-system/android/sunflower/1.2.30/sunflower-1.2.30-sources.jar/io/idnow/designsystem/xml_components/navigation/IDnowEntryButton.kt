package io.idnow.designsystem.xml_components.navigation

import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.text.SpannableStringBuilder
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.core.content.withStyledAttributes
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isVisible
import androidx.viewbinding.ViewBinding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.databinding.IdnowEntryButtonBinding
import io.idnow.designsystem.databinding.IdnowEntryButtonLargeBinding
import io.idnow.designsystem.styles.EntryButtonStyle
import io.idnow.designsystem.xml_components.extension.UnitLambda
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.image_view.IDnowImageView
import io.idnow.designsystem.xml_components.lottie.IDnowLottieAnimationView

class IDnowEntryButton : ConstraintLayout, IDnowMarginable {
    /** Keep only the current binding to avoid duplication. */
    private var currentBinding: ViewBinding? = null

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /**
     * Tint color enum for the start icon.
     * It allows to set a specific token color in the code or in xml.
     */
    var startIconTintColor: TintColorEnum = TintColorEnum.MAIN
        set(value) {
            field = value
            setStartIconTintInternal(field)
        }

    /**
     * Tint color enum for the end icon.
     * It allows to set a specific token color in the code or in xml.
     */
    var endIconTintColor: TintColorEnum = TintColorEnum.MAIN
        set(value) {
            field = value
            setEndIconTintInternal(field)
        }

    /** Display or hide the start icon. */
    var startIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(getView(R.id.idn_start_icon), value, startIconTintColor)
        }

    /** Change the lottie for large view style. */
    var lottieRawRes: Int = -1
        set(value) {
            field = value
            setLottie(field)
        }

    /** Display or hide the end icon. */
    var endIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(getView(R.id.idn_end_icon), value, endIconTintColor)
        }

    /** Title of the button. */
    var title: CharSequence = ""
        set(value) {
            field = value
            setTitleInternal(field)
            setContentDescription()
        }

    /** Add an optional description below the title. */
    var description: CharSequence? = null
        set(value) {
            field = value
            setDescriptionInternal(field)
            setContentDescription()
        }

    /** Update the entry button style. */
    var style: Style = Style.MEDIUM
        set(value) {
            field = value
            updateStyle(field)
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowEntryButton) {
            val margin = getInt(R.styleable.IDnowEntryButton_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowEntryButton_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowEntryButton_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowEntryButton_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowEntryButton_token_endMargin, -1)
            margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
            style = Style.entries[getInt(R.styleable.IDnowEntryButton_entryButtonStyle, Style.MEDIUM.ordinal)]
            startIcon = getDrawable(R.styleable.IDnowEntryButton_startIcon)
            endIcon = getDrawable(R.styleable.IDnowEntryButton_endIcon) ?: ResourcesCompat.getDrawable(context.resources, R.drawable.sunflower_ic_chevron_right, null)
            title = getString(R.styleable.IDnowEntryButton_title) ?: ""
            description = getString(R.styleable.IDnowEntryButton_description)
            startIconTintColor = TintColorEnum.entries[getInt(R.styleable.IDnowEntryButton_token_startIconTint, TintColorEnum.MAIN.ordinal)]
            endIconTintColor = TintColorEnum.entries[getInt(R.styleable.IDnowEntryButton_token_endIconTint, TintColorEnum.ACCENT.ordinal)]
            lottieRawRes = getResourceId(R.styleable.IDnowEntryButton_lottie_rawRes, -1)
        }
        /** Set content description. */
        setContentDescription()
    }

    /**
     * Register a callback to be invoked when whole button is clicked.
     * Send null to remove the callback.
     * @param lambda the callback that will run
     */
    fun setOnClickListener(lambda: UnitLambda?) {
        currentBinding?.root?.setOnClickListener {
            lambda?.invoke()
        }
    }

    /**
     * Register a callback to be invoked when the end icon is clicked.
     * @param lambda the callback that will run
     */
    fun setOnEndIconClickListener(lambda: UnitLambda?) {
        getView<IDnowImageView>(R.id.idn_end_icon)?.setOnClickListener {
            lambda?.invoke()
        }
    }

    /**
     * Find a view in the current binding.
     * We don't use view binding here to avoid duplication as we have two different XML.
     * @param id the id to find in the view.
     */
    private fun <T : View> getView(id: Int): T? {
        return currentBinding?.root?.findViewById(id)
    }

    /**
     * Set the title text whatever the current binding is.
     * @param text the text to set.
     */
    private fun setTitleInternal(text: CharSequence) {
        getView<TextView>(R.id.idn_title)?.text = text
    }

    /**
     * Set the description text whatever the current binding is.
     * @param text the text to set.
     */
    private fun setDescriptionInternal(text: CharSequence?) {
        getView<TextView>(R.id.idn_description)?.apply {
            isVisible = text != null
            alpha = EntryButtonStyle.descOpacity
            text?.let { setText(it) }
        }
    }

    /**
     * Set the lottie animation whatever the current binding is.
     * @param lottieRawRes the lottie raw resource to set.
     */
    private fun setLottie(lottieRawRes: Int) {
        getView<IDnowLottieAnimationView>(R.id.idn_lottie)?.apply {
            if(lottieRawRes != -1) {
                setAnimation(lottieRawRes)
            }
        }
    }

    /**
     * Set the start icon tint whatever the current binding is.
     * @param tint the tint to transmit to the image view
     */
    private fun setStartIconTintInternal(tint: TintColorEnum) {
        getView<IDnowImageView>(R.id.idn_start_icon)?.tintColor = tint
    }

    /**
     * Set the end icon tint whatever the current binding is.
     * @param tint the tint to transmit to the image view
     */
    private fun setEndIconTintInternal(tint: TintColorEnum) {
        getView<IDnowImageView>(R.id.idn_end_icon)?.tintColor = tint
    }

    /**
     * Display the given view with the given icon.
     * If the icon is null, hide the view instead.
     * @param iconView the view to display/hide
     * @param icon the icon (null to hide view)
     * @param tint the tint to apply
     */
    private fun displayViewWithIcon(iconView: IDnowImageView?, icon: Drawable?, tint: TintColorEnum) {
        iconView?.apply {
            if (icon != null) {
                isVisible = true
                setImageDrawable(icon)
                tintColor = tint
            } else {
                isVisible = false
            }
        }
    }

    /**
     * Update the style of the entry button.
     * @param style the style to apply
     */
    private fun updateStyle(style: Style) {
        // Clean all the existing views
        removeAllViews()
        // Re-inflate the view
        currentBinding = when (style) {
            Style.MEDIUM -> IdnowEntryButtonBinding.inflate(LayoutInflater.from(context), this).apply {
                root.setBackgroundResource(R.drawable.idnow_entry_button_background)
            }
            Style.LARGE -> IdnowEntryButtonLargeBinding.inflate(LayoutInflater.from(context), this).apply {
                root.setBackgroundResource(R.drawable.idnow_entry_button_large_background)
            }
        }
        // Re-apply all the parameters that were set on the previous view.
        setTitleInternal(title)
        setDescriptionInternal(description)
        startIcon = startIcon
        endIcon = endIcon
        setStartIconTintInternal(startIconTintColor)
        setEndIconTintInternal(endIconTintColor)
        setContentDescription()
        // Change the background token depending on the style
        when(style) {
            Style.MEDIUM -> (currentBinding?.root?.background as? GradientDrawable)?.customizeGradient(context)
            Style.LARGE -> (currentBinding?.root?.background as? LayerDrawable)?.let {
                // Hide the left border of the large item. On version < 23, left corners will be visible.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    it.setLayerInsetLeft(0, -(EntryButtonStyle.cornerRadius.toDp(context) + EntryButtonStyle.strokeWidth.toDp(context)))
                }
                (it.getDrawable(0) as GradientDrawable).customizeGradient(context)
            }
        }
    }

    /**
     * Customize the gradient of the button.
     * @param context the context to apply dp transformation
     */
    private fun GradientDrawable.customizeGradient(context: Context) {
        with(EntryButtonStyle) {
            customize(
                cornerRadius = cornerRadius.toDp(context).toFloat(),
                strokeColor = strokeColor,
                strokeWidth = strokeWidth.toDp(context)
            )
        }
    }

    /** All the possible style of an entry button. */
    enum class Style {
        MEDIUM, LARGE
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    /**
     * Used to retrieve and update the lottie.
     * @return this step [IDnowLottieAnimationView] or null when style is not LARGE
     */
    fun lottie() = getView<IDnowLottieAnimationView>(R.id.idn_lottie)

    /** Set a custom description for accessibility. */
    private fun setContentDescription() {
        currentBinding?.root?.let {
            ViewCompat.setAccessibilityDelegate(it, object : AccessibilityDelegateCompat() {
                override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info.contentDescription = SpannableStringBuilder().apply {
                        append(accessibilityContentText())
                        append(accessibilityClassName())
                    }
                }
            })
        }
    }

    /** Build the a custom content description for accessibility. */
    private fun accessibilityContentText(): CharSequence {
        return SpannableStringBuilder().apply {
            if(title.isNotEmpty()) append("$title${if(!title.endsWith(".")) "." else ""} ")
            description?.let { if(it.isNotEmpty()) append("$it${if(!it.endsWith(".")) "." else ""} ") }
        }
    }

    /** Retrieve the class name for accessibility. */
    private fun accessibilityClassName(): String {
        return context.getString(R.string.sunflower_button)
    }

}