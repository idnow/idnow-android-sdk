package io.idnow.designsystem.xml_components.alert

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.text.SpannableStringBuilder
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.graphics.drawable.toDrawable
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.databinding.IdnowAlertBinding
import io.idnow.designsystem.styles.AlertBoxAndTagStyle
import io.idnow.designsystem.styles.ControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.UnitLambda
import io.idnow.designsystem.xml_components.extension.addActionForLinks
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.handleUrlClicks
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.extension.toDp

class IDnowAlertBox @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
): ConstraintLayout(context, attrs, defStyleAttr, R.style.IDnowAlertStyle), IDnowMarginable {

    /** The actual layout for this alert box */
    private val binding = IdnowAlertBinding.inflate(LayoutInflater.from(context), this)

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** The alert type; Based on this a custom bgColor and startIcon will be set */
    var alertType: IDnowAlertType = IDnowAlertType.INFO
        set(value) {
            field = value
            initialize()
        }

    /** The alert box text */
    var text: CharSequence
        get() = binding.idnTvMessage.text ?: ""
        set(value) {
            binding.idnTvMessage.text = value
            setContentDescription()
        }

    /** Show or hide the start icon */
    var showStartIcon: Boolean = false
        set(value) {
            field = value
            binding.idnStartIcon.isVisible = value
            applyTextMargins()
        }

    /** Show or hide the close icon */
    var showCloseIcon: Boolean = false
        set(value) {
            field = value
            binding.idnCloseIcon.isVisible = value
            applyTextMargins()
        }

    /** Override the start icon if you don't want to use the default one. */
    var startIcon: Drawable? = null
        set(value) {
            field = value
            value?.let {
                binding.idnStartIcon.setImageDrawable(value)
            }
        }

    /** Callback for close click */
    var onCloseClick: UnitLambda = {}

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowAlertBox) {

            /** Handle the component margin. */
            val margin = getInt(R.styleable.IDnowAlertBox_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowAlertBox_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowAlertBox_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowAlertBox_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowAlertBox_token_endMargin, -1)
            margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
            text = getString(R.styleable.IDnowAlertBox_text) ?: ""
            showStartIcon = getBoolean(R.styleable.IDnowAlertBox_showStartIcon, true)
            showCloseIcon = getBoolean(R.styleable.IDnowAlertBox_showCloseIcon, true)
            alertType = IDnowAlertType.entries[getInt(R.styleable.IDnowAlertBox_alert_box_type, IDnowAlertType.INFO.ordinal)]
            startIcon = getDrawable(R.styleable.IDnowAlertBox_startIcon)
        }
    }

    private fun initialize() {
        with(AlertBoxAndTagStyle) {
            /** Apply background color to the box */
            (binding.root.background as StateListDrawable).apply {
                /* set the first layer drawable bg color required because second item has transparency and view under it will be visible */
                customize(
                    multipleItem = true,
                    innerChild = 0,
                    solidColor = containerBgColor,
                    cornerRadius = cornerRadiusBox.toDp(context).toFloat(),
                )
                /* set actual box bg color - second layer - this will be visible to the user */
                customize(
                    multipleItem = true,
                    innerChild = 1,
                    solidColor = Utils.adjustAlpha(alertType.color(), bgColorOpacity),
                    cornerRadius = cornerRadiusBox.toDp(context).toFloat(),
                )
            }
            /** Set general padding inside the box */
            binding.root.setPadding(boxItemMargin.toDp(context))
            /** Customize the message textView */
            applyTextMargins()
            binding.idnTvMessage.apply {
                setTextColor(textColor)
                setTypography(boxTextFont(context))
            }
            /** Customize the start icon */
            binding.idnStartIcon.apply {
                // We set a default icon if their is none defined.
                if(startIcon == null) {
                    setImageResource(alertType.drawable)
                }
                imageTintList = ColorStateList.valueOf(alertType.color())
            }
            /** Customize the close icon */
            binding.idnCloseIcon.apply {
                imageTintList = ColorStateList.valueOf(textColor)
                setOnClickListener { onCloseClick() }
            }
        }
        /** Set content description */
        setContentDescription()
    }

    /** Apply text margin based on weather start and end icons are visible or not  */
    private fun applyTextMargins() {
        /** Customize the message textView */
        binding.idnTvMessage.apply {
            layoutParams = layoutParams.applyMargin(
                context = context,
                start = if (showStartIcon) AlertBoxAndTagStyle.boxItemMargin else 0,
                end = if (showCloseIcon) AlertBoxAndTagStyle.boxItemMargin else 0
            )
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(
            context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value
        )
        super.setLayoutParams(mParams)
    }

    /** Set a custom description for accessibility. */
    private fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.root, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = SpannableStringBuilder().apply {
                    append(accessibilityAlertInfo())
                    append(text)
                }
            }
        })
    }

    fun handleUrlClicks(onClicked: ((String) -> Unit)) {
        binding.idnTvMessage.handleUrlClicks(
            typography = ControlStyle.fontColor(context, Size.SMALL),
            onClicked = onClicked
        ) { actionName, span -> addActionForLinks(binding.root, binding.root, actionName, span) }
    }

    /** Retrieve the alert info text for accessibility. */
    private fun accessibilityAlertInfo(): CharSequence {
        return when(alertType) {
            IDnowAlertType.INFO -> context.getString(R.string.sunflower_information)
            IDnowAlertType.ERROR -> context.getString(R.string.sunflower_error)
            IDnowAlertType.WARNING -> context.getString(R.string.sunflower_warning)
            IDnowAlertType.SUCCESS -> context.getString(R.string.sunflower_success)
        }.plus(" ")
    }

    companion object {
        /**
         * Builds and shows the [IDnowAlertBox] as a [PopupWindow] animated from outside top to top of screen
         *
         * @param anchorView - the root view of the fragment or activity in which this will be displayed
         * @param alertType - the [IDnowAlertType]
         * @param text - the text to be displayed in the alert box
         * @param showStartIcon - show or hide start icon; default is showing
         * @param startIcon - you can provide a start icon to override the default one
         * @param showCloseIcon - show or hide close icon; default is showing
         * @param margins - the [SpacingQuad]  specifying margins relative to the screen
         * @param onCloseClick - listener for close click
         *
         * @return the instance of the showing [PopupWindow]. Can be used by host app to determine weather
         * the popup is already showing, or to dismiss it automatically if needed
         */
        fun showAsToastPopup(
            anchorView: View,
            alertType: IDnowAlertType,
            text: String,
            showStartIcon: Boolean = true,
            startIcon: Drawable? = null,
            showCloseIcon: Boolean = true,
            margins: SpacingQuad = SpacingQuad().handleMargins(
                margins = -1,
                startMargin = SpacingEnum.SPACING_MD.ordinal,
                topMargin = SpacingEnum.SPACING_MD.ordinal,
                endMargin = SpacingEnum.SPACING_MD.ordinal,
                bottomMargin = SpacingEnum.SPACING_MD.ordinal,
            ),
            onCloseClick: UnitLambda = {},
        ): PopupWindow? {
            val popupWindow: PopupWindow?
            return try {
                IDnowAlertBox(anchorView.context).apply {
                    popupWindow = createPopupWindow(contentView = this)
                    this.alertType = alertType
                    this.margins = margins
                    this.text = text
                    this.showStartIcon = showStartIcon
                    this.startIcon = startIcon
                    this.showCloseIcon = showCloseIcon
                    this.onCloseClick = {
                        popupWindow.dismiss()
                        onCloseClick()
                    }
                    popupWindow.showAsDropDown(anchorView, 0, calculateYOffset(this, anchorView), Gravity.BOTTOM)
                }
                popupWindow
            } catch (_: Exception) {
                //exception might be thrown if activity is finishing or anchorView was destroyed
                null
            }
        }

        private fun createPopupWindow(contentView: View): PopupWindow {
            val popupWindow = PopupWindow(
                contentView,
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT,
                false
            )
            popupWindow.isOutsideTouchable = false
            popupWindow.isFocusable = true
            popupWindow.setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
            popupWindow.animationStyle = R.style.IDnowAlertBoxPopupStyle
            return popupWindow
        }

        //show the popup outside top the screen and animation will be translating it down
        private fun calculateYOffset(popupView: View, anchorView: View): Int {
            //the popup window default anchors to the bottom of the view
            popupView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
            //calculate y offset to be linked to the top of the view above the screen
            return -popupView.measuredHeight - anchorView.measuredHeight
        }
    }
}