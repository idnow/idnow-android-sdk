package io.idnow.designsystem.xml_components.progress

import androidx.annotation.FloatRange

/**
 * A single step displayed by [IDnowStepsProgressIndicator].
 * @param title the step title, displayed next to the bullet.
 * @param subtitle optional description displayed below the title.
 * @param state the current state of the step, [IDnowStepProgressState.PENDING] by default.
 * @param progress the progress of the step, between 0.0 (0%) and 1.0 (100%), 0.0 by default. Only displayed while
 * the step is [IDnowStepProgressState.ACTIVE], as an arc filling the bullet ring clockwise from 12 o'clock.
 * Values out of range are clamped. Reaching 1.0 does not change the [state]: moving to the next step is up to the
 * integrator.
 */
data class IDnowStepProgressItem(
    val title: CharSequence,
    val subtitle: CharSequence? = null,
    val state: IDnowStepProgressState = IDnowStepProgressState.PENDING,
    @FloatRange(from = 0.0, to = 1.0) val progress: Float = 0f,
)

/** [IDnowStepProgressItem.progress] clamped to its 0.0 - 1.0 range. */
internal val IDnowStepProgressItem.clampedProgress: Float
    get() = progress.coerceIn(0f, 1f)

/** Index of the step currently [IDnowStepProgressState.ACTIVE], or -1 if there is none. */
internal val List<IDnowStepProgressItem>.activeStepIndex: Int
    get() = indexOfFirst { it.state == IDnowStepProgressState.ACTIVE }

/**
 * Compute the steps after advancing the progress by one step. Shared by the XML and Compose steps progress indicators.
 *
 * Every step before the next one is marked as [IDnowStepProgressState.SUCCESS] and the next step, if any,
 * is marked as [IDnowStepProgressState.ACTIVE] (keeping its [IDnowStepProgressItem.progress], 0.0 by default).
 * When there is no active step yet, the first pending step becomes active. When the last step was active, all the
 * steps end up successful. [IDnowStepProgressState.ERROR] steps are never changed: an error is only set or cleared
 * explicitly.
 */
internal fun List<IDnowStepProgressItem>.advancedToNextStep(): List<IDnowStepProgressItem> {
    val activeIndex = activeStepIndex
    val nextIndex = if (activeIndex == -1) {
        indexOfFirst { it.state == IDnowStepProgressState.PENDING }.takeIf { it != -1 } ?: size
    } else {
        activeIndex + 1
    }

    return mapIndexed { index, item ->
        when {
            item.state == IDnowStepProgressState.ERROR -> item
            index < nextIndex -> item.copy(state = IDnowStepProgressState.SUCCESS)
            index == nextIndex -> item.copy(state = IDnowStepProgressState.ACTIVE)
            else -> item
        }
    }
}

/** The step at [index], or null if there is no step at [index]: the caller then skips the update. */
internal fun List<IDnowStepProgressItem>.requireStep(index: Int): IDnowStepProgressItem? = getOrNull(index)
