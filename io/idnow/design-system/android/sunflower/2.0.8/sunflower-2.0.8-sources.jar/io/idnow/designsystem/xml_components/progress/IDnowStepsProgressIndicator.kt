package io.idnow.designsystem.xml_components.progress

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.annotation.FloatRange
import androidx.core.content.withStyledAttributes
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import androidx.core.view.updateLayoutParams
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowStepsProgressItemBinding
import io.idnow.designsystem.styles.xml.StepsProgressIndicatorStyle
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.color
import io.idnow.designsystem.xml_components.extension.gradientDrawable
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp
import kotlin.math.roundToInt

/**
 * The IDnowStepsProgressIndicator component.
 *
 * Displays a vertical list of [IDnowStepProgressItem], each one with a bullet on the start side reflecting its
 * [IDnowStepProgressState] (step number, step number inside a ring filled up to the step progress, success or error
 * icon, delayed icon) and its title/subtitle next to it.
 *
 * Use [advanceToNextStep] to move to the next step, [setActiveStepProgress] / [setStepProgress] to fill the active
 * step ring from 0% to 100%, [setStepState] to e.g. mark a step as failed or delayed, or [updateStep] to replace a step.
 * Reaching 100% does nothing on its own: the integrator decides when to move to the next step.
 *
 * Accessibility: each step is focusable on its own and read as "Step 1 of 2: Title. Description, in progress.".
 * Every step state change made through [advanceToNextStep], [setStepState], [setStepProgress] or [updateStep] is
 * announced once, e.g. "Step 1 of 2 completed. Step 2 of 2: Title, in progress." or "Step 2 of 2: Title, failed.".
 * Replacing the whole list through [steps] is not announced.
 */
class IDnowStepsProgressIndicator @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : LinearLayout(context, attrs, defStyleAttr), IDnowMarginable {
    private val inflater = LayoutInflater.from(context)

    /** One binding per displayed step, in the same order as [steps]. */
    private val itemBindings = mutableListOf<IdnowStepsProgressItemBinding>()

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /**
     * The steps to display.
     * Setting a new list rebuilds the component, without any accessibility announcement.
     */
    var steps: List<IDnowStepProgressItem>
        get() = _steps.toList()
        set(value) {
            _steps.clear()
            _steps.addAll(value)
            rebuildItems()
        }
    private val _steps = mutableListOf<IDnowStepProgressItem>()

    /** Index of the step currently [IDnowStepProgressState.ACTIVE], or -1 if there is none. */
    val activeStepIndex: Int
        get() = _steps.activeStepIndex

    init {
        orientation = VERTICAL
        context.withStyledAttributes(attrs, R.styleable.IDnowStepsProgressIndicator, defStyleAttr) {
            val margin = getInt(R.styleable.IDnowStepsProgressIndicator_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowStepsProgressIndicator_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowStepsProgressIndicator_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowStepsProgressIndicator_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowStepsProgressIndicator_token_endMargin, -1)
            margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        }
    }

    /**
     * Advance the progress by one step.
     *
     * Every step before the next one is marked as [IDnowStepProgressState.SUCCESS] and the next step, if any,
     * is marked as [IDnowStepProgressState.ACTIVE]. When there is no active step yet, the first pending step
     * becomes active. When the last step was active, all the steps end up successful.
     * [IDnowStepProgressState.ERROR] steps are never changed.
     *
     * @return true if a step is active after the call, false otherwise.
     */
    fun advanceToNextStep(): Boolean {
        announcingChanges {
            _steps.advancedToNextStep().forEachIndexed { index, item ->
                if (item != _steps[index]) applyStep(index, item)
            }
        }
        return activeStepIndex != -1
    }

    /**
     * Update the progress of the active step, if any. Shortcut for [setStepProgress] on [activeStepIndex].
     * @param progress the new progress, between 0.0 (0%) and 1.0 (100%). Values out of range are clamped.
     * @return true if there is an active step, false if the call had no effect.
     */
    fun setActiveStepProgress(@FloatRange(from = 0.0, to = 1.0) progress: Float): Boolean {
        val index = activeStepIndex
        if (index == -1) return false
        setStepProgress(index, progress)
        return true
    }

    /**
     * Update the progress of a single step. The progress is only displayed while the step is
     * [IDnowStepProgressState.ACTIVE], and the change is animated.
     * @param index index of the step to update. Nothing happens if there is no step at this index.
     * @param progress the new progress, between 0.0 (0%) and 1.0 (100%). Values out of range are clamped.
     */
    fun setStepProgress(index: Int, @FloatRange(from = 0.0, to = 1.0) progress: Float) {
        val step = _steps.requireStep(index) ?: return
        updateStep(index, step.copy(progress = progress))
    }

    /**
     * Update the state of a single step, e.g. to mark it as [IDnowStepProgressState.ERROR] or
     * [IDnowStepProgressState.PROCESSING].
     * @param index index of the step to update. Nothing happens if there is no step at this index.
     * @param state the new state of the step.
     */
    fun setStepState(index: Int, state: IDnowStepProgressState) {
        val step = _steps.requireStep(index) ?: return
        updateStep(index, step.copy(state = state))
    }

    /**
     * Update a single step without rebuilding the whole component.
     * @param index index of the step to update. Nothing happens if there is no step at this index.
     * @param item the new value of the step.
     */
    fun updateStep(index: Int, item: IDnowStepProgressItem) {
        _steps.requireStep(index) ?: return
        announcingChanges { applyStep(index, item) }
    }

    /** Update a single step without any accessibility announcement. */
    private fun applyStep(index: Int, item: IDnowStepProgressItem) {
        val previous = _steps[index]
        _steps[index] = item
        // Only animate the arc when an already active step moves forward or backward.
        val animateProgress = previous.state == IDnowStepProgressState.ACTIVE && item.state == IDnowStepProgressState.ACTIVE
        bindItem(itemBindings[index], index, animateProgress)
    }

    /**
     * Run [update], then announce once the step state changes it made, e.g. "Step 1 of 2 completed. Step 2 of 2:
     * Title, in progress.". Progress only changes are not announced.
     */
    private inline fun announcingChanges(update: () -> Unit) {
        val previous = _steps.toList()
        update()
        resources.stepsChangeAnnouncement(previous, _steps)?.let(::announceForAccessibility)
    }

    /** Inflate one row per step, reusing the existing rows when possible. */
    private fun rebuildItems() {
        while (itemBindings.size > _steps.size) {
            val binding = itemBindings.removeAt(itemBindings.lastIndex)
            removeView(binding.root)
        }
        while (itemBindings.size < _steps.size) {
            val binding = IdnowStepsProgressItemBinding.inflate(inflater, this, false)
            itemBindings.add(binding)
            addView(binding.root)
        }
        itemBindings.forEachIndexed { index, binding -> bindItem(binding, index, animateProgress = false) }
    }

    /** Apply the step at [index] to its row, animating the progress arc change when [animateProgress]. */
    private fun bindItem(binding: IdnowStepsProgressItemBinding, index: Int, animateProgress: Boolean) = with(binding) {
        val item = _steps[index]
        val style = StepsProgressIndicatorStyle
        val isFirst = index == 0
        val isLast = index == _steps.lastIndex

        // Connecting line, hidden above the first bullet and below the last one.
        idnTopLine.visibility = if (isFirst) INVISIBLE else VISIBLE
        idnBottomLine.visibility = if (isLast) INVISIBLE else VISIBLE
        idnTopLine.setBackgroundColor(style.lineColor)
        idnBottomLine.setBackgroundColor(style.lineColor)

        // Texts, the spacing between steps is set on the texts so the line can go through it.
        idnTitle.typography = style.titleTypography
        idnTitle.textColor = style.titleColor
        idnTitle.text = item.title
        idnDescription.typography = style.descriptionTypography
        idnDescription.textColor = style.descriptionColor
        idnDescription.text = item.subtitle
        idnDescription.isVisible = !item.subtitle.isNullOrEmpty()

        // The bullet is vertically centered on the first title line (on its capital letters, like the design),
        // whichever is taller between the bullet and that line is placed at the top of the row.
        val bulletSize = resources.getDimensionPixelSize(R.dimen.idnow_steps_progress_bullet_size)
        val titleLineCenter = idnTitle.paddingTop - idnTitle.paint.fontMetricsInt.top - style.titleCapHeightPx(context) / 2f
        val bulletOffset = (titleLineCenter - bulletSize / 2f).roundToInt()
        idnBullet.updateLayoutParams<MarginLayoutParams> { topMargin = bulletOffset.coerceAtLeast(0) }
        idnTextContainer.updateLayoutParams<MarginLayoutParams> {
            topMargin = (-bulletOffset).coerceAtLeast(0)
            bottomMargin = if (isLast) 0 else style.itemSpacing.toDp(context)
        }

        // Bullet: always surrounded by the ring. The step number stays visible while pending or active (the progress
        // arc then fills the ring), the success / error / delayed icon takes its place otherwise.
        idnBullet.background = gradientDrawable {
            shape = GradientDrawable.OVAL
            stroke(style.bulletBorderColor, style.bulletBorderWidth.toDp(context))
        }
        val showsNumber = item.state == IDnowStepProgressState.PENDING || item.state == IDnowStepProgressState.ACTIVE
        idnStepNumber.isVisible = showsNumber
        idnProgress.isVisible = item.state == IDnowStepProgressState.ACTIVE
        idnStateIcon.isVisible = !showsNumber
        when (item.state) {
            IDnowStepProgressState.PENDING -> bindNumber(index)
            IDnowStepProgressState.ACTIVE -> {
                bindNumber(index)
                bindProgress(item.clampedProgress, animateProgress)
            }
            IDnowStepProgressState.SUCCESS -> bindStateIcon(style.successIcon, style.successColor)
            IDnowStepProgressState.ERROR -> bindStateIcon(style.errorIcon, style.errorColor)
            IDnowStepProgressState.PROCESSING -> bindStateIcon(style.delayedIcon, style.delayedColor)
        }

        root.contentDescription = resources.stepContentDescription(index, _steps.size, item)
    }

    /** Step number, displayed in the pending and active bullets. */
    private fun IdnowStepsProgressItemBinding.bindNumber(index: Int) {
        val style = StepsProgressIndicatorStyle
        val typography = style.stepNumberFont(context)
        idnStepNumber.text = "${index + 1}"
        idnStepNumber.typeface = typography.typeface
        // The number must always fit in the bullet, so it does not follow the font scale.
        idnStepNumber.setTextSize(TypedValue.COMPLEX_UNIT_PX, resources.getDimension(R.dimen.idnow_steps_progress_step_number_text_size))
        idnStepNumber.setTextColor(style.stepNumberColor.color())
    }

    /**
     * Arc filling the bullet ring clockwise from 12 o'clock up to [progress], the ring itself acts as the track.
     * The change is animated by the Material indicator spring when [animate], otherwise applied immediately.
     */
    private fun IdnowStepsProgressItemBinding.bindProgress(progress: Float, animate: Boolean) = with(idnProgress) {
        val style = StepsProgressIndicatorStyle
        val thickness = resources.getDimensionPixelSize(R.dimen.idnow_steps_progress_progress_thickness)
        indicatorSize = resources.getDimensionPixelSize(R.dimen.idnow_steps_progress_bullet_size)
        trackThickness = thickness
        trackCornerRadius = thickness / 2
        trackColor = Color.TRANSPARENT
        setIndicatorColor(style.progressIndicatorColor)
        isIndeterminate = false
        setProgressCompat((progress * max).roundToInt(), animate)
    }

    /** Success / error / delayed icon displayed in place of the step number, on a disc of the state color. */
    private fun IdnowStepsProgressItemBinding.bindStateIcon(@DrawableRes icon: Int, @ColorInt discColor: Int) = with(idnStateIcon) {
        val style = StepsProgressIndicatorStyle
        setImageResource(icon)
        setColorFilter(style.stateIconColor)
        setPadding(style.stateIconPadding.toDp(context))
        background = gradientDrawable {
            shape = GradientDrawable.OVAL
            color(argb = discColor)
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value, margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }
}
