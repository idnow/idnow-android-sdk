package io.idnow.designsystem.styles.xml

import android.content.Context
import android.graphics.Paint
import android.graphics.Rect
import android.util.TypedValue
import androidx.annotation.Dimension
import androidx.annotation.DrawableRes
import io.idnow.designsystem.R
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.tokens.Tokens

internal object StepsProgressIndicatorStyle {
    /**
     * Color of the ring surrounding every bullet, whatever the step state.
     */
    val bulletBorderColor get() = Tokens.heading

    /**
     * Stroke width of the ring surrounding every bullet.
     */
    @Dimension(unit = Dimension.DP)
    const val bulletBorderWidth = 2

    /**
     * Typography and color of the step number displayed in the pending and active bullets.
     * The size is fixed by `idnow_steps_progress_step_number_text_size` so the number always fits in the bullet.
     */
    val stepNumberTypography = TypographyEnum.BODY_XSMALL
    fun stepNumberFont(context: Context) = stepNumberTypography.toTypography(context)
    val stepNumberColor = TextColorEnum.BODY

    /**
     * Color of the progress arc of the active bullet, drawn on top of the bullet ring.
     */
    val progressIndicatorColor get() = Tokens.active

    /**
     * Damping ratio and stiffness of the spring animating the progress arc between two values. Same values as the
     * Material `CircularProgressIndicator` determinate animation, so the XML and Compose arcs move alike.
     */
    const val progressAnimationDampingRatio = 1f
    const val progressAnimationStiffness = 50f

    /**
     * Icon displayed in place of the step number for a successful step, and the color of the disc behind it.
     */
    @DrawableRes
    val successIcon = R.drawable.sunflower_ic_check
    val successColor get() = Tokens.success

    /**
     * Icon displayed in place of the step number for a failed step, and the color of the disc behind it.
     */
    @DrawableRes
    val errorIcon = R.drawable.sunflower_ic_cross
    val errorColor get() = Tokens.error

    /**
     * Icon displayed in place of the step number for a delayed step, and the color of the disc behind it.
     */
    @DrawableRes
    val delayedIcon = R.drawable.sunflower_ic_dots_x
    val delayedColor get() = Tokens.processing

    /**
     * Tint of the success / error / delayed icon, drawn on top of its colored disc.
     */
    val stateIconColor get() = Tokens.overlay

    /**
     * Padding between the success / error / delayed disc edge and its icon.
     */
    @Dimension(unit = Dimension.DP)
    const val stateIconPadding = 2

    /**
     * Color of the line linking the bullets together.
     */
    val lineColor get() = Tokens.heading

    /**
     * Vertical space between the texts of a step and the next step.
     */
    val itemSpacing get() = Tokens.spacingLg

    /** Title typography and color. */
    val titleTypography = TypographyEnum.BODY_SMALL
    val titleColor = TextColorEnum.HEADING

    /**
     * Height of the title capital letters, in px. The bullet is vertically centered on them, i.e. at
     * `cap height / 2` above the first title baseline. Measured with the same typeface and size as the title.
     */
    fun titleCapHeightPx(context: Context): Float {
        val typography = titleTypography.toTypography(context)
        val paint = Paint().apply {
            typeface = typography.typeface
            textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, typography.size, context.resources.displayMetrics)
        }
        val bounds = Rect()
        paint.getTextBounds(CAP_HEIGHT_REFERENCE, 0, CAP_HEIGHT_REFERENCE.length, bounds)
        return bounds.height().toFloat()
    }

    private const val CAP_HEIGHT_REFERENCE = "H"

    /** Description typography and color. */
    val descriptionTypography = TypographyEnum.BODY_XSMALL
    val descriptionColor = TextColorEnum.BODY
}
