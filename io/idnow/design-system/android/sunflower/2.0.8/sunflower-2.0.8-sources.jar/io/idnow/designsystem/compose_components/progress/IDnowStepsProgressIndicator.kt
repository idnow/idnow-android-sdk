package io.idnow.designsystem.compose_components.progress

import androidx.annotation.DrawableRes
import androidx.annotation.FloatRange
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.AlignmentLine
import androidx.compose.ui.layout.FirstBaseline
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalResources
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.styles.compose.IDnowStepsProgressDefaults
import io.idnow.designsystem.styles.compose.IDnowStepsProgressStyle
import io.idnow.designsystem.xml_components.progress.IDnowStepProgressItem
import io.idnow.designsystem.xml_components.progress.IDnowStepProgressState
import io.idnow.designsystem.xml_components.progress.activeStepIndex
import io.idnow.designsystem.xml_components.progress.advancedToNextStep
import io.idnow.designsystem.xml_components.progress.clampedProgress
import io.idnow.designsystem.xml_components.progress.requireStep
import io.idnow.designsystem.xml_components.progress.stepContentDescription
import io.idnow.designsystem.xml_components.progress.stepsChangeAnnouncement
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * State holder of [IDnowStepsProgressIndicator], the Compose counterpart of the XML view's `steps`,
 * `advanceToNextStep()`, `setActiveStepProgress()`, `setStepProgress()`, `setStepState()` and `updateStep()` API.
 * Create it with [rememberIDnowStepsProgressIndicatorState].
 *
 * Reaching 100% does nothing on its own: the integrator decides when to move to the next step.
 *
 * Every step state change made through [advanceToNextStep], [setStepState], [setStepProgress] or [updateStep] is
 * announced once by the accessibility services, like the XML view. Replacing the whole list through [steps] is not.
 *
 * @param initialSteps the steps displayed initially.
 */
@Stable
class IDnowStepsProgressIndicatorState(initialSteps: List<IDnowStepProgressItem>) {
    private var _steps: List<IDnowStepProgressItem> by mutableStateOf(initialSteps.toList())

    /** The steps to display. Setting a new list is not announced by the accessibility services. */
    var steps: List<IDnowStepProgressItem>
        get() = _steps
        set(value) {
            _steps = value.toList()
            pendingChange = null
        }

    /**
     * Changes made through the update methods and not announced yet. Changes made before the next composition are
     * merged, so they are announced together.
     */
    internal var pendingChange: StepsChange? by mutableStateOf(null)
        private set

    /** Index of the step currently [IDnowStepProgressState.ACTIVE], or -1 if there is none. */
    val activeStepIndex: Int
        get() = steps.activeStepIndex

    /**
     * Advance the progress by one step.
     *
     * Every step before the next one is marked as [IDnowStepProgressState.SUCCESS] and the next step, if any,
     * is marked as [IDnowStepProgressState.ACTIVE]. When there is no active step yet, the first pending step
     * becomes active. When the last step was active, all the steps end up successful.
     * [IDnowStepProgressState.ERROR] steps are never changed.
     *
     * @return true if a step is active after the call, false otherwise.
     */
    fun advanceToNextStep(): Boolean {
        applyAnnounced(_steps.advancedToNextStep())
        return activeStepIndex != -1
    }

    /**
     * Update the progress of the active step, if any. Shortcut for [setStepProgress] on [activeStepIndex].
     * @param progress the new progress, between 0.0 (0%) and 1.0 (100%). Values out of range are clamped.
     * @return true if there is an active step, false if the call had no effect.
     */
    fun setActiveStepProgress(@FloatRange(from = 0.0, to = 1.0) progress: Float): Boolean {
        val index = activeStepIndex
        if (index == -1) return false
        setStepProgress(index, progress)
        return true
    }

    /**
     * Update the progress of a single step. The progress is only displayed while the step is
     * [IDnowStepProgressState.ACTIVE], and the change is animated.
     * @param index index of the step to update. Nothing happens if there is no step at this index.
     * @param progress the new progress, between 0.0 (0%) and 1.0 (100%). Values out of range are clamped.
     */
    fun setStepProgress(index: Int, @FloatRange(from = 0.0, to = 1.0) progress: Float) {
        val step = steps.requireStep(index) ?: return
        updateStep(index, step.copy(progress = progress))
    }

    /**
     * Update the state of a single step, e.g. to mark it as [IDnowStepProgressState.ERROR] or
     * [IDnowStepProgressState.PROCESSING].
     * @param index index of the step to update. Nothing happens if there is no step at this index.
     * @param state the new state of the step.
     */
    fun setStepState(index: Int, state: IDnowStepProgressState) {
        val step = steps.requireStep(index) ?: return
        updateStep(index, step.copy(state = state))
    }

    /**
     * Update a single step.
     * @param index index of the step to update. Nothing happens if there is no step at this index.
     * @param item the new value of the step.
     */
    fun updateStep(index: Int, item: IDnowStepProgressItem) {
        steps.requireStep(index) ?: return
        applyAnnounced(_steps.toMutableList().apply { set(index, item) })
    }

    /** Display [newSteps] and record the change, announced by the composable. */
    private fun applyAnnounced(newSteps: List<IDnowStepProgressItem>) {
        val previous = pendingChange?.previous ?: _steps
        // Progress only changes are not announced, no need to recompose for them.
        if (pendingChange != null || newSteps.map { it.state } != previous.map { it.state }) {
            pendingChange = StepsChange(previous = previous, current = newSteps)
        }
        _steps = newSteps
    }

    /** Called once [change] was announced. */
    internal fun onChangeAnnounced(change: StepsChange) {
        if (pendingChange === change) pendingChange = null
    }
}

/** A change of the steps, from [previous] to [current]. Not a data class: each change is announced once. */
internal class StepsChange(val previous: List<IDnowStepProgressItem>, val current: List<IDnowStepProgressItem>)

/** Create and remember an [IDnowStepsProgressIndicatorState] initialized with [initialSteps]. */
@Composable
fun rememberIDnowStepsProgressIndicatorState(initialSteps: List<IDnowStepProgressItem>): IDnowStepsProgressIndicatorState =
    remember { IDnowStepsProgressIndicatorState(initialSteps) }

/**
 * Compose counterpart of the XML `IDnowStepsProgressIndicator`, driven by an [IDnowStepsProgressIndicatorState].
 * Call [IDnowStepsProgressIndicatorState.advanceToNextStep] to move to the next step and
 * [IDnowStepsProgressIndicatorState.setActiveStepProgress] to fill the active step ring.
 */
@Composable
fun IDnowStepsProgressIndicator(
    state: IDnowStepsProgressIndicatorState,
    modifier: Modifier = Modifier,
) {
    val view = LocalView.current
    val resources = LocalResources.current
    val change = state.pendingChange
    LaunchedEffect(change) {
        if (change == null) return@LaunchedEffect
        resources.stepsChangeAnnouncement(change.previous, change.current)?.let(view::announceForAccessibility)
        state.onChangeAnnounced(change)
    }
    StepsColumn(steps = state.steps, modifier = modifier)
}

/**
 * Compose counterpart of the XML `IDnowStepsProgressIndicator`, stateless variant.
 *
 * Displays a vertical list of [IDnowStepProgressItem], each one with a bullet on the start side reflecting its
 * [IDnowStepProgressState] (step number, step number inside a ring filled up to the step progress, success or error
 * icon, delayed icon) and its title/subtitle next to it.
 * Spacing around the component is applied by the caller via [modifier].
 *
 * Accessibility: each step is read on its own as "Step 1 of 2: Title. Description, in progress.". The step state
 * changes between two [steps] lists with the same number of steps are announced once, e.g. "Step 1 of 2 completed.
 * Step 2 of 2: Title, in progress." or "Step 2 of 2: Title, failed.".
 */
@Composable
fun IDnowStepsProgressIndicator(
    steps: List<IDnowStepProgressItem>,
    modifier: Modifier = Modifier,
) {
    val view = LocalView.current
    val resources = LocalResources.current
    // Last announced steps, only read by the effect so updating it does not recompose.
    val announcedSteps = remember { mutableStateOf(steps) }
    LaunchedEffect(steps) {
        val previous = announcedSteps.value
        announcedSteps.value = steps
        resources.stepsChangeAnnouncement(previous, steps)?.let(view::announceForAccessibility)
    }
    StepsColumn(steps = steps, modifier = modifier)
}

@Composable
private fun StepsColumn(steps: List<IDnowStepProgressItem>, modifier: Modifier) {
    val style = IDnowStepsProgressDefaults.style()
    Column(modifier = modifier) {
        steps.forEachIndexed { index, item ->
            StepRow(
                item = item,
                stepNumber = index + 1,
                stepCount = steps.size,
                isFirst = index == 0,
                isLast = index == steps.lastIndex,
                style = style,
            )
        }
    }
}

/**
 * One step, mirrors the XML constraints: the bullet is vertically centered on the capital letters of the first
 * title line, the line segments run from the row top to the bullet and from the bullet to the row bottom, and the
 * spacing between steps is a bottom padding of the texts so the line goes through it.
 */
@Composable
private fun StepRow(
    item: IDnowStepProgressItem,
    stepNumber: Int,
    stepCount: Int,
    isFirst: Boolean,
    isLast: Boolean,
    style: IDnowStepsProgressStyle,
) {
    val title = item.title.toString()
    val description = item.subtitle?.toString()
    val resources = LocalResources.current
    // Same content description as the XML view: "Step 1 of 2: Title. Description, in progress."
    val contentDesc = remember(resources, stepNumber, stepCount, title, description, item.state) {
        resources.stepContentDescription(stepNumber - 1, stepCount, item)
    }
    val itemSpacing = if (isLast) 0.dp else style.itemSpacing

    Layout(
        modifier = Modifier
            .fillMaxWidth()
            .clearAndSetSemantics { contentDescription = contentDesc },
        content = {
            Line(visible = !isFirst, style = style)
            Bullet(state = item.state, progress = item.clampedProgress, stepNumber = stepNumber, style = style)
            Line(visible = !isLast, style = style)
            Column(modifier = Modifier.padding(start = 12.dp, bottom = itemSpacing)) {
                BasicText(text = title, style = style.titleTextStyle)
                if (!description.isNullOrEmpty()) {
                    Spacer(Modifier.height(style.descriptionSpacing))
                    BasicText(text = description, style = style.descriptionTextStyle)
                }
            }
        },
    ) { measurables, constraints ->
        val (topLine, bullet, bottomLine, texts) = measurables
        val bulletSize = style.bulletSize.roundToPx()
        val lineWidth = style.lineWidth.roundToPx()

        val bulletPlaceable = bullet.measure(Constraints.fixed(bulletSize, bulletSize))
        val textsPlaceable = texts.measure(
            constraints.copy(minWidth = 0, maxWidth = (constraints.maxWidth - bulletSize).coerceAtLeast(0), minHeight = 0),
        )

        // Same computation as the XML view: whichever is taller between the bullet and the title line goes at the top.
        val baseline = textsPlaceable[FirstBaseline]
        val bulletOffset = if (baseline == AlignmentLine.Unspecified) {
            0
        } else {
            (baseline - style.titleCapHeight.toPx() / 2f - bulletSize / 2f).roundToInt()
        }
        val bulletTop = bulletOffset.coerceAtLeast(0)
        val textsTop = (-bulletOffset).coerceAtLeast(0)
        val height = maxOf(textsTop + textsPlaceable.height, bulletTop + bulletSize)
        val width = constraints.maxWidth

        val topLinePlaceable = topLine.measure(Constraints.fixed(lineWidth, bulletTop))
        val bottomLinePlaceable = bottomLine.measure(Constraints.fixed(lineWidth, height - bulletTop - bulletSize))
        val lineX = (bulletSize - lineWidth) / 2

        layout(width, height) {
            topLinePlaceable.placeRelative(lineX, 0)
            bulletPlaceable.placeRelative(0, bulletTop)
            bottomLinePlaceable.placeRelative(lineX, bulletTop + bulletSize)
            textsPlaceable.placeRelative(bulletSize, textsTop)
        }
    }
}

/** A segment of the line linking the bullets, keeping its space when not [visible]. */
@Composable
private fun Line(visible: Boolean, style: IDnowStepsProgressStyle) {
    Box(modifier = if (visible) Modifier.background(style.lineColor) else Modifier)
}

@Composable
private fun Bullet(state: IDnowStepProgressState, progress: Float, stepNumber: Int, style: IDnowStepsProgressStyle) {
    // Every bullet is surrounded by the ring, mirrors the XML stroked oval *background* of the bullet container:
    // it is drawn behind the content so the progress arc is painted over it and replaces that part of the
    // ring (Modifier.border would draw on top and hide the outer part of the arc).
    Box(
        modifier = Modifier
            .size(style.bulletSize)
            .drawBehind {
                val strokeWidth = style.bulletBorderWidth.toPx()
                drawCircle(
                    color = style.bulletBorderColor,
                    radius = (size.minDimension - strokeWidth) / 2f,
                    style = Stroke(width = strokeWidth),
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        when (state) {
            IDnowStepProgressState.PENDING -> StepNumber(stepNumber, style)
            IDnowStepProgressState.ACTIVE -> {
                ProgressArc(progress, style)
                StepNumber(stepNumber, style)
            }
            IDnowStepProgressState.SUCCESS -> StateIcon(style.successIcon, style.successColor, style)
            IDnowStepProgressState.ERROR -> StateIcon(style.errorIcon, style.errorColor, style)
            IDnowStepProgressState.PROCESSING -> StateIcon(style.delayedIcon, style.delayedColor, style)
        }
    }
}

@Composable
private fun StepNumber(stepNumber: Int, style: IDnowStepsProgressStyle) {
    BasicText(text = stepNumber.toString(), style = style.stepNumberTextStyle)
}

/**
 * Arc filling the bullet ring clockwise from 12 o'clock up to [progress], mirrors the XML determinate
 * `CircularProgressIndicator` (transparent track, round caps kept inside the progress span, same spring).
 *
 * The arc only animates while the step stays active: entering the composition (the step becoming active) starts
 * directly at the current progress, like the XML view which only animates changes on an already active step.
 */
@Composable
private fun BoxScope.ProgressArc(progress: Float, style: IDnowStepsProgressStyle) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = style.progressAnimationSpec,
        label = "stepsProgressArc",
    )
    // The animated value is read in the draw phase only, so each frame only re-runs the draw block,
    // not composition or the draw cache.
    Spacer(
        modifier = Modifier
            .matchParentSize()
            .drawWithCache {
                val thickness = style.progressThickness.toPx()
                val radius = (size.minDimension - thickness) / 2f
                val topLeft = Offset(size.width / 2f - radius, size.height / 2f - radius)
                val arcSize = Size(radius * 2f, radius * 2f)
                // Angle covered by one round cap, the caps are drawn inside the span like the Material indicator.
                val capAngle = Math.toDegrees((thickness / 2f / radius).toDouble()).toFloat()
                onDrawBehind {
                    val sweep = 360f * animatedProgress
                    when {
                        sweep <= 0f -> Unit
                        // Full ring: no caps, so the ends do not overlap.
                        sweep >= 360f -> drawCircle(
                            color = style.progressIndicatorColor,
                            radius = radius,
                            style = Stroke(width = thickness),
                        )
                        // Shorter than its two caps: a dot shrinking with the progress, centered on the span.
                        sweep < 2f * capAngle -> {
                            val angle = Math.toRadians((-90f + sweep / 2f).toDouble())
                            drawCircle(
                                color = style.progressIndicatorColor,
                                radius = thickness / 2f * (sweep / (2f * capAngle)),
                                center = Offset(
                                    center.x + radius * cos(angle).toFloat(),
                                    center.y + radius * sin(angle).toFloat(),
                                ),
                            )
                        }
                        else -> drawArc(
                            color = style.progressIndicatorColor,
                            startAngle = -90f + capAngle,
                            sweepAngle = sweep - 2f * capAngle,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = thickness, cap = StrokeCap.Round),
                        )
                    }
                }
            },
    )
}

/** Success / error / delayed icon displayed in place of the step number, on a disc of the state color. */
@Composable
private fun StateIcon(@DrawableRes icon: Int, discColor: Color, style: IDnowStepsProgressStyle) {
    Image(
        painter = painterResource(icon),
        contentDescription = null,
        colorFilter = ColorFilter.tint(style.stateIconColor),
        modifier = Modifier
            .size(style.stateIconSize)
            .background(color = discColor, shape = CircleShape)
            .padding(style.stateIconPadding),
    )
}

// ---------------------------------------------------------------------------
// Previews
// ---------------------------------------------------------------------------

@Preview(name = "Steps progress", showBackground = true)
@Composable
private fun PreviewStepsProgress() {
    IDnowStepsProgressIndicator(
        steps = listOf(
            IDnowStepProgressItem("Uploading your video", "Sending 15 seconds of secure video", IDnowStepProgressState.SUCCESS),
            IDnowStepProgressItem("Checking security features", "Hologram, document details and face match", IDnowStepProgressState.ACTIVE, progress = 0.6f),
            IDnowStepProgressItem("Comparing your face", "Liveness check failed", IDnowStepProgressState.ERROR),
            IDnowStepProgressItem("Verifying your identity", "This is taking longer than expected", IDnowStepProgressState.PROCESSING),
            IDnowStepProgressItem("Analysis complete", "Your security check is finished"),
        ),
    )
}
