package io.idnow.designsystem.styles.compose

import android.content.Context
import android.graphics.Paint
import android.graphics.Rect
import android.util.TypedValue
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import io.idnow.designsystem.R
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.compose_components.extension.asTextStyle
import io.idnow.designsystem.compose_components.extension.composeColor
import io.idnow.designsystem.tokens.Tokens

/**
 * Fully-resolved visual values for the Compose `IDnowStepsProgressIndicator`.
 *
 * Compose counterpart of the XML `StepsProgressIndicatorStyle` (+ the `idnow_steps_progress_*` dimens). The values are
 * duplicated in [IDnowStepsProgressDefaults.style] rather than read from the XML style, which is meant to be removed
 * with the XML support: keep them in sync with it until then. The token reads
 * happen during composition, so a runtime `IDnowDesignSystem.setup()` recomposes with the new values.
 */
@Immutable
data class IDnowStepsProgressStyle(
    // --- Bullet ----------------------------------------------------------
    /** Side of the bullet (idnow_steps_progress_bullet_size). */
    val bulletSize: Dp,
    /** Color of the ring surrounding every bullet (HEADING). */
    val bulletBorderColor: Color,
    /** Stroke width of the ring surrounding every bullet. */
    val bulletBorderWidth: Dp,
    /** Text style of the step number in the pending and active bullets, not scaled with the font scale. */
    val stepNumberTextStyle: TextStyle,
    /** Color of the progress arc filling the ring of the active bullet. */
    val progressIndicatorColor: Color,
    /** Thickness of the progress arc (idnow_steps_progress_progress_thickness). */
    val progressThickness: Dp,
    /** Spring animating the progress arc, same damping ratio and stiffness as the XML Material indicator. */
    val progressAnimationSpec: AnimationSpec<Float>,
    /** Icon displayed in place of the step number for a successful step. */
    @DrawableRes val successIcon: Int,
    /** Color of the disc behind the success icon. */
    val successColor: Color,
    /** Icon displayed in place of the step number for a failed step. */
    @DrawableRes val errorIcon: Int,
    /** Color of the disc behind the error icon. */
    val errorColor: Color,
    /** Icon displayed in place of the step number for a delayed step. */
    @DrawableRes val delayedIcon: Int,
    /** Color of the disc behind the delayed icon. */
    val delayedColor: Color,
    /** Tint of the success / error / delayed icon. */
    val stateIconColor: Color,
    /** Side of the success / error / delayed disc (idnow_steps_progress_state_icon_size). */
    val stateIconSize: Dp,
    /** Padding between the success / error / delayed disc edge and its icon. */
    val stateIconPadding: Dp,
    // --- Line ------------------------------------------------------------
    /** Color of the line linking the bullets (HEADING). */
    val lineColor: Color,
    /** Width of the line linking the bullets (idnow_steps_progress_line_width). */
    val lineWidth: Dp,
    // --- Texts -----------------------------------------------------------
    /** Title typography (BODY_SMALL) and color (HEADING). */
    val titleTextStyle: TextStyle,
    /** Height of the title capital letters, the bullet is vertically centered on them. */
    val titleCapHeight: Dp,
    /** Description typography (BODY_XSMALL) and color (BODY). */
    val descriptionTextStyle: TextStyle,
    /** Space between the title and the description (idnow_steps_progress_description_top_margin). */
    val descriptionSpacing: Dp,
    /** Vertical space between the texts of a step and the next step. */
    val itemSpacing: Dp,
)

/** Default resolver for [IDnowStepsProgressStyle], analogous to Material3's `XxxDefaults`. */
object IDnowStepsProgressDefaults {

    /** Same values as the Material `CircularProgressIndicator` determinate animation. */
    private const val PROGRESS_ANIMATION_DAMPING_RATIO = 1f
    private const val PROGRESS_ANIMATION_STIFFNESS = 50f
    private const val CAP_HEIGHT_REFERENCE = "H"

    @Composable
    fun style(): IDnowStepsProgressStyle {
        val context = LocalContext.current
        val density = LocalDensity.current
        // The XML number size is a dimen in dp applied as px, so it ignores the font scale. Dp.toSp() divides by
        // the font scale, which keeps the rendered size at exactly that many dp.
        val stepNumberSize = with(density) {
            dimensionResource(R.dimen.idnow_steps_progress_step_number_text_size).toSp()
        }
        // Measured with a Paint, keyed on the primitives (typography) and the density (font scale) since the reads
        // done inside remember are not observed.
        val primitives = IDnowDesignSystem.primitives
        val titleCapHeight = remember(primitives, context, density) {
            with(density) { titleCapHeightPx(context).toDp() }
        }

        return IDnowStepsProgressStyle(
            bulletSize = dimensionResource(R.dimen.idnow_steps_progress_bullet_size),
            bulletBorderColor = TextColorEnum.HEADING.composeColor,
            bulletBorderWidth = 2.dp,
            stepNumberTextStyle = TypographyEnum.BODY_XSMALL.asTextStyle(color = TextColorEnum.BODY.composeColor).copy(
                fontSize = stepNumberSize,
                // The XML number only takes the typeface, not the typography line height, and trims the font padding.
                lineHeight = TextUnit.Unspecified,
                textAlign = TextAlign.Center,
                platformStyle = PlatformTextStyle(includeFontPadding = false),
            ),
            progressIndicatorColor = TintColorEnum.ACTIVE.composeColor,
            progressThickness = dimensionResource(R.dimen.idnow_steps_progress_progress_thickness),
            progressAnimationSpec = spring(
                dampingRatio = PROGRESS_ANIMATION_DAMPING_RATIO,
                stiffness = PROGRESS_ANIMATION_STIFFNESS,
            ),
            successIcon = R.drawable.sunflower_ic_check,
            successColor = TintColorEnum.SUCCESS.composeColor,
            errorIcon = R.drawable.sunflower_ic_cross,
            errorColor = TintColorEnum.ERROR.composeColor,
            delayedIcon = R.drawable.sunflower_ic_dots_x,
            delayedColor = TintColorEnum.PROCESSING.composeColor,
            stateIconColor = TintColorEnum.OVERLAY.composeColor,
            stateIconSize = dimensionResource(R.dimen.idnow_steps_progress_state_icon_size),
            stateIconPadding = 2.dp,
            lineColor = TextColorEnum.HEADING.composeColor,
            lineWidth = dimensionResource(R.dimen.idnow_steps_progress_line_width),
            titleTextStyle = TypographyEnum.BODY_SMALL.asTextStyle(color = TextColorEnum.HEADING.composeColor),
            titleCapHeight = titleCapHeight,
            descriptionTextStyle = TypographyEnum.BODY_XSMALL.asTextStyle(color = TextColorEnum.BODY.composeColor),
            descriptionSpacing = dimensionResource(R.dimen.idnow_steps_progress_description_top_margin),
            // Read from Tokens (not SpacingEnum, whose values are captured once) so a runtime setup() is followed.
            itemSpacing = Tokens.spacingLg.dp,
        )
    }

    /**
     * Height of the title capital letters, in px. The bullet is vertically centered on them, i.e. at
     * `cap height / 2` above the first title baseline. Measured with the same typeface and size as the title.
     */
    private fun titleCapHeightPx(context: Context): Float {
        val typography = TypographyEnum.BODY_SMALL.toTypography(context)
        val paint = Paint().apply {
            typeface = typography.typeface
            textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, typography.size, context.resources.displayMetrics)
        }
        val bounds = Rect()
        paint.getTextBounds(CAP_HEIGHT_REFERENCE, 0, CAP_HEIGHT_REFERENCE.length, bounds)
        return bounds.height().toFloat()
    }
}
