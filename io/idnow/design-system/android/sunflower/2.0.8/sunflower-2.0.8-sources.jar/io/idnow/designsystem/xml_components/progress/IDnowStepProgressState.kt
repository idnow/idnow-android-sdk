package io.idnow.designsystem.xml_components.progress

/** State of an [IDnowStepProgressItem]. */
enum class IDnowStepProgressState {
    /** The step is not started yet, its bullet displays the step number inside a ring. */
    PENDING,

    /** The step is in progress, its bullet displays the step number inside a ring filled up to its progress. */
    ACTIVE,

    /** The step is done, its bullet displays the success icon in place of the step number. */
    SUCCESS,

    /** The step failed, its bullet displays the error icon in place of the step number. */
    ERROR,

    /** The step takes longer than expected, its bullet displays the processing icon in place of the step number. */
    PROCESSING
}