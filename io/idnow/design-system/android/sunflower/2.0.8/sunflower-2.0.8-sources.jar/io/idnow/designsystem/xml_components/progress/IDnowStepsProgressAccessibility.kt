package io.idnow.designsystem.xml_components.progress

import android.content.res.Resources
import androidx.annotation.StringRes
import io.idnow.designsystem.R

/*
 * Accessibility texts of the steps progress indicator, shared by the XML and Compose components so both read the
 * same way.
 */

/** Label read after the step title for each state, e.g. "in progress". */
@get:StringRes
private val IDnowStepProgressState.accessibilityLabel: Int
    get() = when (this) {
        IDnowStepProgressState.PENDING -> R.string.sunflower_steps_progress_state_pending
        IDnowStepProgressState.ACTIVE -> R.string.sunflower_steps_progress_state_active
        IDnowStepProgressState.SUCCESS -> R.string.sunflower_steps_progress_state_success
        IDnowStepProgressState.ERROR -> R.string.sunflower_steps_progress_state_error
        IDnowStepProgressState.PROCESSING -> R.string.sunflower_steps_progress_state_delayed
    }

/** "Step 2 of 3: Checking security features, in progress." */
private fun Resources.stepStatus(index: Int, stepCount: Int, item: IDnowStepProgressItem): String =
    getString(
        R.string.sunflower_steps_progress_step,
        index + 1,
        stepCount,
        // The format already ends the title with a comma, avoid "Title., in progress".
        item.title.toString().trim().removeSuffix("."),
        getString(item.state.accessibilityLabel),
    )

/**
 * Content description of a step, read when the user moves the accessibility focus on it: the step position, its title
 * and description (subtitle) joined with a dot, then its state, e.g.
 * "Step 1 of 2: Uploading document video. Sending 15 seconds of secure video, in progress.".
 * Without a description: "Step 1 of 2: Uploading document video, in progress.".
 */
internal fun Resources.stepContentDescription(index: Int, stepCount: Int, item: IDnowStepProgressItem): String =
    getString(
        R.string.sunflower_steps_progress_step,
        index + 1,
        stepCount,
        // The format adds the comma before the state, so the trailing dots are removed: "Title. Description, state."
        listOfNotNull(item.title.toString(), item.subtitle?.toString())
            .map { it.trim().removeSuffix(".") }
            .filter { it.isNotEmpty() }
            .joinToString(". "),
        getString(item.state.accessibilityLabel),
    )

/**
 * Announcement of the step state changes between [previous] and [current], in step order, or null when no step
 * state changed (e.g. only the progress moved) or when the number of steps changed (the list was replaced):
 * - a completed step: "Step 1 of 2 completed."
 * - any other new state: "Step 2 of 2: Checking security features, in progress." (or failed, finishing, …)
 */
internal fun Resources.stepsChangeAnnouncement(
    previous: List<IDnowStepProgressItem>,
    current: List<IDnowStepProgressItem>,
): String? {
    if (previous.size != current.size) return null
    return current.indices
        .filter { current[it].state != previous[it].state }
        .joinToString(" ") { index ->
            val item = current[index]
            if (item.state == IDnowStepProgressState.SUCCESS) {
                getString(R.string.sunflower_steps_progress_step_completed, index + 1, current.size)
            } else {
                stepStatus(index, current.size, item)
            }
        }
        .takeIf { it.isNotEmpty() }
}
