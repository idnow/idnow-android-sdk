package io.idnow.designsystem.xml_components.controls.check_box

/** Check box state */
enum class CheckState {
    CHECKED, INDETERMINATE, UNCHECKED
}