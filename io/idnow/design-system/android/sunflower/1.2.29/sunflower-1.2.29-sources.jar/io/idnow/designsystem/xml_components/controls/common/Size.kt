package io.idnow.designsystem.xml_components.controls.common

enum class Size {
    SMALL, NORMAL, BIG
}