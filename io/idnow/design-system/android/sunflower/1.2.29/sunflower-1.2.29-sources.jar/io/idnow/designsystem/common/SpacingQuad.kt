package io.idnow.designsystem.common

private const val NO_MARGIN = -1

data class SpacingQuad(
    val start: SpacingEnum = SpacingEnum.NO_SPACING,
    val top: SpacingEnum = SpacingEnum.NO_SPACING,
    val end: SpacingEnum = SpacingEnum.NO_SPACING,
    val bottom: SpacingEnum = SpacingEnum.NO_SPACING,
) {
    constructor(horizontal: SpacingEnum = SpacingEnum.NO_SPACING, vertical: SpacingEnum = SpacingEnum.NO_SPACING) : this(
        start = horizontal,
        top = vertical,
        end = horizontal,
        bottom = vertical,
    )

    constructor(all: SpacingEnum = SpacingEnum.NO_SPACING) : this(
        start = all,
        top = all,
        end = all,
        bottom = all,
    )

    internal companion object {
        fun fromAttributes(margins: Int, startMargin: Int, topMargin: Int, endMargin: Int, bottomMargin: Int): SpacingQuad {
            var newMargins = SpacingQuad()
            margins.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.setMargin(SpacingEnum.entries[it]) }
            startMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(start = SpacingEnum.entries[it]) }
            topMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(top = SpacingEnum.entries[it]) }
            endMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(end = SpacingEnum.entries[it]) }
            bottomMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(bottom = SpacingEnum.entries[it]) }
            return newMargins
        }
    }

    /**
     * Update the margins from the value set on the component.
     * @param margins used to set the same margin to all side.
     * @param startMargin the given start margin.
     * @param endMargin the given end margin.
     * @param topMargin the given top margin.
     * @param bottomMargin the given bottom margin.
     * @return the updated spacing quad.
     */
    fun handleMargins(margins: Int, startMargin: Int, topMargin: Int, endMargin: Int, bottomMargin: Int): SpacingQuad {
        var newMargins: SpacingQuad = this
        margins.takeIf { it != NO_MARGIN }?.let { newMargins = setMargin(SpacingEnum.entries[it]) }
        startMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(start = SpacingEnum.entries[it]) }
        topMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(top = SpacingEnum.entries[it]) }
        endMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(end = SpacingEnum.entries[it]) }
        bottomMargin.takeIf { it != NO_MARGIN }?.let { newMargins = newMargins.copy(bottom = SpacingEnum.entries[it]) }
        return newMargins
    }

    /**
     * Apply a given margin to all side.
     * @param margin the margin to apply
     */
    fun setMargin(margin: SpacingEnum): SpacingQuad {
        return copy(
            start = margin,
            top = margin,
            end = margin,
            bottom = margin
        )
    }
}
