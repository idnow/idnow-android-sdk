package io.idnow.designsystem.xml_components.controls.check_box

interface OnCheckChangeListener {
    /**
     * Called when the checked state of a check box has changed.
     * @param isChecked The new checked state.
     */
    fun onCheckChange(isChecked: Boolean)
}