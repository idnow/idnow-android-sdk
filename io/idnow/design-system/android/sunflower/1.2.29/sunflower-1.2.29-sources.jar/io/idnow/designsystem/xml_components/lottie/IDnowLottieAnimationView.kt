package io.idnow.designsystem.xml_components.lottie

import android.content.Context
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.util.AttributeSet
import android.view.ViewGroup
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieProperty
import com.airbnb.lottie.model.KeyPath
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin

/**
 * Customizable component displaying a lottie animation.
 * Properties like "margins" can be set here or directly in xml.
 */
class IDnowLottieAnimationView : LottieAnimationView, IDnowMarginable {
    /** region Public Properties */
    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }
    /** endregion */

    /** region init */
    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowLottieAnimationView)
        /** Handle the component margin. */
        val margin = customArray.getInt(R.styleable.IDnowLottieAnimationView_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowLottieAnimationView_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowLottieAnimationView_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowLottieAnimationView_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowLottieAnimationView_token_endMargin, -1)
        margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        customArray.recycle()
        initialize()
    }
    /** endregion */

    /** region Override Methods */
    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(
            context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value
        )
        super.setLayoutParams(mParams)
    }
    /** endregion */

    /** region Private Enums */
    private enum class KeyPathsClass(val className: String) {
        MAIN_BACKGROUND(".lottie-color-main-background"),
        MAIN(".lottie-color-main"),
        BACKGROUND(".lottie-color-background"),
        ACCENT(".lottie-color-accent"),
        PATTERN(".lottie-color-pattern"),
        SUCCESS(".lottie-color-success"),
        ERROR(".lottie-color-error"),
        PROCESSING(".lottie-color-processing"),
        OVERLAY(".lottie-color-overlay");

        fun color() = when (this) {
            /** this main-background has a special handling for color setting */
            MAIN_BACKGROUND -> -1
            MAIN -> Tokens.main
            BACKGROUND -> Tokens.background
            ACCENT -> Tokens.accent
            PATTERN -> Tokens.pattern
            SUCCESS -> Tokens.success
            ERROR -> Tokens.error
            PROCESSING -> Tokens.processing
            OVERLAY -> Tokens.overlay
        }
    }
    /** endregion */

    /** region Private Methods */
    private fun initialize() {
        /**
         * Set lottie composition loaded listener so we can apply the color filter
         * for all the keyPaths in the current lottie json file and customize it
         */
        addLottieOnCompositionLoadedListener {
            KeyPathsClass.entries.forEach { keyPathClass ->
                val keyPath = KeyPath("**", keyPathClass.className, "**")
                when (keyPathClass) {
                    /**
                     * For main-background class handle it as follows
                     * - set [Tokens.main] color for stroke lottie layer
                     * - set [Tokens.background] color for fill lottie layer
                     */
                    KeyPathsClass.MAIN_BACKGROUND -> {
                        addValueCallback(keyPath, LottieProperty.STROKE_COLOR) { Tokens.main }
                        addValueCallback(keyPath, LottieProperty.COLOR) { Tokens.background }
                    }
                    else -> {
                        /** For all other classes just set the color filter with the enum color property */
                        addValueCallback(keyPath, LottieProperty.COLOR_FILTER) {
                            PorterDuffColorFilter(keyPathClass.color(), PorterDuff.Mode.SRC_ATOP)
                        }
                    }
                }
            }
        }
    }
    /** endregion */
}