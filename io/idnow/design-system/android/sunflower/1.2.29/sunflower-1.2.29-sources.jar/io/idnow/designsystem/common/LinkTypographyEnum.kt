package io.idnow.designsystem.common

import android.content.Context
import io.idnow.designsystem.tokens.Typography

enum class LinkTypographyEnum {
    LINKS_LARGE, LINKS, LINKS_SMALL;

    /**
     * Map a [LinkTypographyEnum] to a [Typography].
     * [LinkTypographyEnum] will be used when calling the handleUrlClicks on components with URL.
     * We map it to the internal [Typography] object that we used in all our components.
     * @param context context is needed to retrieve a typography
     * return the mapped typography.
     */
    internal fun toTypography(context: Context) : Typography {
        return when(this) {
            LinkTypographyEnum.LINKS_LARGE -> Typography.LinksLarge(context)
            LinkTypographyEnum.LINKS -> Typography.Links(context)
            LinkTypographyEnum.LINKS_SMALL -> Typography.LinksSmall(context)
        }
    }
}