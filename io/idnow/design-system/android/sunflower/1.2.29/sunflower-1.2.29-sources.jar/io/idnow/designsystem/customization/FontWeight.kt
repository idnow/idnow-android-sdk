package io.idnow.designsystem.customization

data class FontWeight(
    val regular: Int = DefaultPrimitives.regular,
    val medium: Int = DefaultPrimitives.medium
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            regular: Int? = null,
            medium: Int? = null
        ) = FontWeight(
            regular = regular ?: DefaultPrimitives.regular,
            medium = medium ?: DefaultPrimitives.medium
        )
    }
}
