package io.idnow.designsystem.xml_components.app_components.mask.path

import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Path
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad
import io.idnow.designsystem.xml_components.extension.UnitLambda
import androidx.core.graphics.withMatrix

/**
 * Transform a static path into an bouncing path.
 * @param overlayToDisplay the path that we want to bounce.
 */
internal class BouncePath(private val overlayToDisplay: PathToDisplay) : PathToDisplay {
    /** Keep track of the current scale */
    var scale = 1f
        set(value) {
            field = value
            matrix.reset()
            matrix.postScale(value, value, centerX, centerY)
        }

    /** Transformation matrix that will apply the bounce effect to the canvas */
    private val matrix = Matrix()

    /** X Center of the path that will bounce */
    private var centerX = 0f

    /** Y Center of the path that will bounce */
    private var centerY = 0f

    override fun getPathToDraw(path: Path, quad: IDnowMaskQuad) {
        centerX = (quad.leftTop.x + quad.rightTop.x) / 2f
        centerY = (quad.leftTop.y + quad.leftBottom.y) / 2f
        overlayToDisplay.getPathToDraw(path, quad)
    }

    /**
     * Apply the bouncing matrix to the canvas, draw the path then restore the canvas to it's normal state.
     */
    override fun withTransformation(canvas: Canvas, lambda: UnitLambda) {
        canvas.withMatrix(matrix) {
            lambda.invoke()
        }
    }
}