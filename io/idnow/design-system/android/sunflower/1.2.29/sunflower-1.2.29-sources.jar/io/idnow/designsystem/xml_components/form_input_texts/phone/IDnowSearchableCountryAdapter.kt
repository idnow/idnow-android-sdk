package io.idnow.designsystem.xml_components.form_input_texts.phone

import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.recyclerview.widget.RecyclerView
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowContainerItemBinding
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowCountryFlagItem
import io.idnow.designsystem.xml_components.form_input_texts.common.updateItem

internal class IDnowSearchableCountryAdapter(
    private val countries: List<IDnowCountryFlagItem>,
    private var selectedItem: IDnowCountryFlagItem?,
    private val onItemClick: (IDnowCountryFlagItem) -> Unit,
) : RecyclerView.Adapter<IDnowSearchableCountryAdapter.CountryViewHolder>() {

    private var filteredCountries: List<IDnowCountryFlagItem> = countries

    fun filter(query: String) {
        filteredCountries = if (query.isEmpty()) {
            countries
        } else {
            countries.filter { country ->
                country.content.contains(query, ignoreCase = true) || country.prefix.contains(query, ignoreCase = true)
            }
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val itemBinding = IdnowContainerItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CountryViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        holder.bind(filteredCountries[position])
    }

    override fun getItemCount(): Int = filteredCountries.size

    inner class CountryViewHolder(private val itemBinding: IdnowContainerItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {
        init {
            // Apply the same ripple as Spinner items
            val outValue = TypedValue()
            itemView.context.theme.resolveAttribute(android.R.attr.selectableItemBackground, outValue, true)
            itemView.setBackgroundResource(outValue.resourceId)
        }

        fun bind(country: IDnowCountryFlagItem) {
            itemBinding.updateItem(country, true, country == selectedItem)

            itemView.setOnClickListener {
                selectedItem = country
                onItemClick(country)
            }

            ViewCompat.setAccessibilityDelegate(itemView, object : AccessibilityDelegateCompat() {
                override fun onInitializeAccessibilityNodeInfo(
                    host: View,
                    info: AccessibilityNodeInfoCompat,
                ) {
                    super.onInitializeAccessibilityNodeInfo(host, info)

                    info.contentDescription = "${country.content}, ${country.prefix}"
                    info.isSelected = country == selectedItem
                    info.setCollectionItemInfo(null)

                    ViewCompat.replaceAccessibilityAction(
                        itemView,
                        AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_CLICK,
                        itemView.context.getString(R.string.sunflower_action_select),
                        null,
                    )
                }
            })
        }
    }
}
