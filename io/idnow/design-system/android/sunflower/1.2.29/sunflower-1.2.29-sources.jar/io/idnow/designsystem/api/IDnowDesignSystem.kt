package io.idnow.designsystem.api

import io.idnow.designsystem.customization.IDnowPrimitives

/**
 * Static object used to store and retrieve the primitives set for the design system.
 * Only the init is visible for integrator.
 */
object IDnowDesignSystem {
    /**
     * Used by the tokens to adapt the colors for the wanted ui mode.
     */
    internal var isLightMode = true

    /**
     * Used by the tokens to associate a functional colors to a primitive ones.
     */
    internal var primitives: IDnowPrimitives = IDnowPrimitives().applyFontUpdate()

    /**
     * Update the primitives with the given ones.
     * @param primitives the custom primitives
     * @param isLightMode choose between light and dark mode.
     */
    fun setup(primitives: IDnowPrimitives, isLightMode: Boolean = true) {
        this.isLightMode = isLightMode
        this.primitives = primitives.applyFontUpdate()
    }
}