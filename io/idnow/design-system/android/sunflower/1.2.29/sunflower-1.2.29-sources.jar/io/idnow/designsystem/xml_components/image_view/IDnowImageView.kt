package io.idnow.designsystem.xml_components.image_view

import android.content.Context
import android.util.AttributeSet
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageView
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.xml_components.extension.applyMargin

/**
 * Customizable imageview component.
 * New Properties can be set here or in xml.
 */
class IDnowImageView: AppCompatImageView, IDnowMarginable {
    /** region Public Properties */
    /** Margins. Reset the layout params to update in real time the component.
     * It allows to set the margin in the code or in xml.
     */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams}
        }
    /**
     * Tint color enum. Set the tint directly to this imageview .
     * It allows to set a specific token color in the code or in xml.
     */
    var tintColor: TintColorEnum? = null
        set(value) {
            field = value
            field?.let { setColorFilter(it.color()) }
        }
    /** endregion */

    /** region Init */
    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?): this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Get attributes from xml.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowImageView)
        // Setup the margins token according to given xml attribute.
        val margin = customArray.getInt(R.styleable.IDnowImageView_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowImageView_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowImageView_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowImageView_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowImageView_token_endMargin, -1)
        margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        // Apply a custom token to tint color.
        tintColor = customArray.getInt(R.styleable.IDnowImageView_token_tintColor, -1).takeIf { it != -1 }?.let { TintColorEnum.entries[it] }
        customArray.recycle()
    }
    /** endregion */

    /** region Override Methods */
    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        // Add margins to current params.
        val mParams = params?.applyMargin(
            context,
            margins.start.value,
            margins.top.value,
            margins.end.value,
            margins.bottom.value)
        super.setLayoutParams(mParams)
    }
    /** endregion*/
}