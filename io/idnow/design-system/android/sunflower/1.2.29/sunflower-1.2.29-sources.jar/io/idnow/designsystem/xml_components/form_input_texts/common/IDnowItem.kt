package io.idnow.designsystem.xml_components.form_input_texts.common

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * Item to use for the [IDnowSpinner]
 * Contains an icon and string.
 */
data class IDnowItem(
    @DrawableRes override val icon: Int? = null,
    override val content: CharSequence? = null
): IDnowItemData
