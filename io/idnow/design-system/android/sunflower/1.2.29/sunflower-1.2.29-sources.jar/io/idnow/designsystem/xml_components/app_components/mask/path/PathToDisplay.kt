package io.idnow.designsystem.xml_components.app_components.mask.path

import android.graphics.Canvas
import android.graphics.Path
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad
import io.idnow.designsystem.xml_components.extension.UnitLambda


internal interface PathToDisplay {
    /**
     * Fills the given path with the path to draw.
     * @param path an empty path to draw from.
     * @param quad the Quad to draw.
     */
    fun getPathToDraw(path: Path, quad: IDnowMaskQuad)

    /**
     * Can be override to apply custom transformation to a canvas.
     * It can be useful to apply animation on some specific path.
     * @param canvas the canvas that will be modified.
     * @param lambda any draw action done on the canvas.
     */
    fun withTransformation(canvas: Canvas, lambda: UnitLambda) {
        lambda.invoke()
    }
}