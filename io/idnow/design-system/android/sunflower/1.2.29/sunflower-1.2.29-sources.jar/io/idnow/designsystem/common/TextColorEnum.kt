package io.idnow.designsystem.common

import io.idnow.designsystem.tokens.Tokens

enum class TextColorEnum {
    HEADING,
    BODY,
    LINK,
    INPUT_TEXT;

    /**
     * Retrieve the token associated to this enum.
     * return @ColorInt
     */
    fun color(): Int {
        return when(this) {
            HEADING -> Tokens.heading
            BODY -> Tokens.body
            LINK -> Tokens.link
            INPUT_TEXT -> Tokens.inputText
        }
    }
}