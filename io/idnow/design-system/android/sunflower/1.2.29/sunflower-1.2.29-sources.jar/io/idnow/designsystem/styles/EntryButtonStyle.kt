package io.idnow.designsystem.styles

import androidx.annotation.Dimension
import io.idnow.designsystem.tokens.Tokens

internal object EntryButtonStyle {
    /**
     * Opacity of the description.
     */
    val descOpacity = 0.83f

    /**
     * Corner radius of the button.
     */
    val cornerRadius = Tokens.radiusMd

    /**
     * Container stroke width
     */
    @Dimension(unit = Dimension.DP)
    val strokeWidth = 1

    /**
     * Container stroke color
     */
    val strokeColor get() = Tokens.borderSecondary
}