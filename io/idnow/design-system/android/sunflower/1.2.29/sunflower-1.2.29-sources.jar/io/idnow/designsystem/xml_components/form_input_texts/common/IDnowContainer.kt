package io.idnow.designsystem.xml_components.form_input_texts.common

import android.content.Context
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp


class IDnowContainer : ConstraintLayout {
    /** The custom error state reference */
    private val stateError = intArrayOf(R.attr.state_error)

    /** Custom state to show an error background */
    var isError: Boolean = false
        set(value) {
            field = value
            refreshDrawableState()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowContainer)
        isEnabled = customArray.getBoolean(R.styleable.IDnowContainer_android_enabled, true)
        isError = customArray.getBoolean(R.styleable.IDnowContainer_state_error, false)
        customArray.recycle()
        initialize()
    }

    private fun initialize() {
        /** To trigger focused state, we must be focusable */
        isFocusable = true
        isFocusableInTouchMode = true

        /** First setup the background */
        setupBackground()
    }

    private fun setupBackground() {
        apply {
            setBackgroundResource(R.drawable.idnow_container_background)
            (background as StateListDrawable).apply {
                /** Update colors of disabled state */
                customizeBackgroundForStyleAndChild(style = ContainerStyle.Disabled, child = 0)
                /** Update colors of active state */
                customizeBackgroundForStyleAndChild(style = ContainerStyle.Filling, child = 1)
                /** Update colors of error state */
                customizeBackgroundForStyleAndChild(style = ContainerStyle.Error, child = 2)
                /** Update colors of classic state*/
                customizeBackgroundForStyleAndChild(style = ContainerStyle.Empty, child = 3)
            }
        }
    }

    /**
     * Customize a background specific state with a given style.
     * @param style the style to apply to the state
     * @param child the index where to find the specific state
     */
    private fun StateListDrawable.customizeBackgroundForStyleAndChild(style: ContainerStyle, child: Int) {
        customize(solidColor = style.backgroundColor,
            strokeColor = style.strokeColor,
            strokeWidth = style.strokeWidth.toDp(context),
            cornerRadius = ContainerStyle.cornerRadius.toDp(context).toFloat(),
            indexChild = child)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        /**
         * To be focused at the same time than the edittext, we need to inherit from children state.
         * BUT, to be able to enter the disable state we need to stop listening at child state.
         * Once done also disable the edittext.
         */
        setAddStatesFromChildren(enabled)
    }

    /** Override to apply the error state when the error boolean is triggered */
    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        val drawableState = super.onCreateDrawableState(extraSpace + 1)
        return if(isError) mergeDrawableStates(drawableState, stateError) else drawableState
    }
}