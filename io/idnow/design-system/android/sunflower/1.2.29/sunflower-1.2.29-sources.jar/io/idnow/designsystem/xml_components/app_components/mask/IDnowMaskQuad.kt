package io.idnow.designsystem.xml_components.app_components.mask

import android.graphics.Point

/**
 * Quad with 4 point, the shape of the mask will fit with Quad.
 */
data class IDnowMaskQuad(
    val leftTop: Point,
    val leftBottom: Point,
    val rightTop: Point,
    val rightBottom: Point,
) {
    /** If either the width or height is empty then we must not draw anything. */
    fun isEmpty() : Boolean {
        return rightTop.x - leftTop.x == 0 || leftBottom.y - leftTop.y == 0
    }
}