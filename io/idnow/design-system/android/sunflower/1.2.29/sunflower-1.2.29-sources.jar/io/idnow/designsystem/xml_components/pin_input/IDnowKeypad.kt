package io.idnow.designsystem.xml_components.pin_input

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import io.idnow.designsystem.databinding.IdnowKeypadBinding

class IDnowKeypad @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr), IDnowPinKeyboard by IDnowPinKeyboard.Default() {
    private val binding = IdnowKeypadBinding.inflate(LayoutInflater.from(context), this)
    private val digitsBindingInOrder = with(binding) {
        listOf(
            idnowKeypadTopLeft,
            idnowKeypadTop,
            idnowKeypadTopRight,
            idnowKeypadLeft,
            idnowKeypadCenter,
            idnowKeypadRight,
            idnowKeypadBottomLeft,
            idnowKeypadBottom,
            idnowKeypadBottomRight,
            idnowKeypadAbsoluteBottom,
        )
    }

    private var digits: List<Digits> = emptyList()
        set(value) {
            field = value

            digitsBindingInOrder.forEachIndexed { i, digitBinding -> digitBinding.text = "${value[i].value}" }
        }

    enum class Digits(
        internal val value: Char,
    ) { One('1'), Two('2'), Three('3'), Four('4'), Five('5'), Six('6'), Seven('7'), Eight('8'), Nine('9'), Zero('0') }

    init {
        with(binding) {
            digitsBindingInOrder.forEachIndexed { i, digitBinding ->
                //TODO change drawable color with Tokens
                digitBinding.setOnClickListener { dispatchAdded(i) }
            }
            idnowKeypadDelete.setOnClickListener { dispatchRemoved() }
        }
        digits = Digits.entries
    }

    fun setupDigits(digits: LinkedHashSet<Digits>) {
        if (digits.size != Digits.entries.size) return
        this.digits = digits.toList()
    }

    private fun dispatchAdded(i: Int) {
        listeners.forEach { it.addContent(digits[i].value) }
    }

    private fun dispatchRemoved() {
        listeners.forEach { it.removeLast() }
    }
}