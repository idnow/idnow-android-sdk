package io.idnow.designsystem.xml_components.pin_input

/**
 * Contract which a PIN keyboard should fulfill.
 *
 * The keyboard should send add and remove event to it's listeners.
 */
interface IDnowPinKeyboard {
    /** [Listener] subscribed to this keyboard events. */
    val listeners: Collection<Listener>

    /** The only contract for this keyboard. Should updates it's listeners when mandatory. */
    fun addListener(listener: Listener)

    /** Removes a subscribed listener from receiving this keyboard events. */
    fun removeListener(listener: Listener)

    /**
     * Handles the addition and removal of listeners.
     */
    class Default: IDnowPinKeyboard {
        private val _listeners = mutableSetOf<Listener>()
        override val listeners get(): Collection<Listener> = _listeners

        override fun addListener(listener: Listener) {
            _listeners.add(listener)
        }

        override fun removeListener(listener: Listener) {
            _listeners.remove(listener)
        }
    }

    /**
     * Used to receive events from a given keyboard.
     *
     * This Listener is used to receive input events from a keyboard and should not be used to infer whether a character has been added to the input,
     * this is the role of [IDnowPinInput.InputListener] defined when calling [IDnowPinInput.linkInputKeyboard].
     */
    interface Listener {
        fun addContent(c: Char)
        fun removeLast()
    }
}