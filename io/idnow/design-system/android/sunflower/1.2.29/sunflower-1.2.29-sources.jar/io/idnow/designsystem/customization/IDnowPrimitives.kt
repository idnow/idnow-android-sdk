package io.idnow.designsystem.customization

data class IDnowPrimitives(
    val colors: Colors = Colors(),
    val radius: Radius = Radius(),
    val spacing: Spacing = Spacing(),
    val font: Font = Font()
) {

    /**
     * Apply a transformation of font size from rem to sp.
     * @return the updated primitives object
     */
    fun applyFontUpdate(): IDnowPrimitives {
        val remToSp = DefaultPrimitives.remMultiplier
        val updatedFont = font.copy(
            fontSize = FontSize(
                fontSize00 = font.fontSize.fontSize00 * remToSp,
                fontSize0 = font.fontSize.fontSize0 * remToSp,
                fontSize1 = font.fontSize.fontSize1 * remToSp,
                fontSize2 = font.fontSize.fontSize2 * remToSp,
                fontSize3 = font.fontSize.fontSize3 * remToSp,
                fontSize4 = font.fontSize.fontSize4 * remToSp,
                fontSize5 = font.fontSize.fontSize5 * remToSp,
                fontSize6 = font.fontSize.fontSize6 * remToSp,
            )
        )
        return copy(font = updatedFont)
    }

    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            colors: Colors? = null,
            radius: Radius? = null,
            spacing: Spacing? = null,
            font: Font? = null
        ) = IDnowPrimitives(
            colors = colors ?: Colors(),
            radius = radius ?: Radius(),
            spacing = spacing ?: Spacing(),
            font = font ?: Font()
        )
    }
}
