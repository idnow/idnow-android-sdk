package io.idnow.designsystem.xml_components.pin_input

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
internal sealed interface IDnowPinBox : Parcelable {
    /** Get the currently displayed character, if null, it is not visible. */
    fun current(): Char?

    /** Convert the box to a viewable type */
    fun show()
    fun hide()

    fun interface Factory {
        fun create(c: Char, isVisible: Boolean): IDnowPinBox
    }

    companion object {
        private fun hiddenBoxFactory(c: Char, isVisible: Boolean): IDnowPinBox = HiddenBox(if (isVisible) c else null)
        private fun viewableBoxFactory(c: Char, isVisible: Boolean): IDnowPinBox = ViewableBox(c, isVisible)

        fun factory(viewable: Boolean): Factory = if (viewable) Factory(::viewableBoxFactory) else Factory(::hiddenBoxFactory)
    }

    /** Does not keep a reference to the hidden char, even if asked to show it. */
    class HiddenBox(private var c: Char?) : IDnowPinBox {
        override fun current(): Char? = c

        override fun show() { c = null }
        override fun hide() { c = null }
    }

    /** Keeps track of what digit is hidden underneath. */
    class ViewableBox(private var c: Char, private var isVisible: Boolean) : IDnowPinBox {
        override fun current(): Char? = if (isVisible) c else null

        override fun show() { isVisible = true }
        override fun hide() { isVisible = false }
    }
}