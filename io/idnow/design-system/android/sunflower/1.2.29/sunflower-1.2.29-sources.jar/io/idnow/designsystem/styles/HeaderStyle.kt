package io.idnow.designsystem.styles

import io.idnow.designsystem.tokens.Tokens

object HeaderStyle {
    /**
     * Icon color
     */
    val iconColor get() = Tokens.main

    /**
     * Icon opacity
     */
    val iconOpacity = 0.9f

    /**
     * Powered by opacity
     */
    val poweredByOpacity = 0.65f
}