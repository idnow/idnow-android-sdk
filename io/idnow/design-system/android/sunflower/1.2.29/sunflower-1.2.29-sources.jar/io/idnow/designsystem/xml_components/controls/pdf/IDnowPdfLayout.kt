package io.idnow.designsystem.xml_components.controls.pdf

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.FloatRange
import androidx.annotation.StringRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updateMargins
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowPdfLayoutBinding
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.extractMargins
import io.idnow.designsystem.xml_components.extension.marginable
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.extension.updatePadding
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * The IDnowPdfLayout component defines the controls layout for a PDF viewer, the actual viewer should be defined as a child of this layout.
 * ```xml
 *     <io.idnow.designsystem.xml_components.controls.pdf.IDnowPdfLayout
 *         android:layout_width="match_parent"
 *         android:layout_height="..."
 *         ...>
 *
 *         <ConcretePdfViewer
 *             android:layout_width="match_parent"
 *             android:layout_height="match_parent"
 *             .../>
 *
 *     </io.idnow.designsystem.xml_components.controls.pdf.IDnowPdfLayout>
 * ```
 *
 * The controls callback are defined through [Listener] with [setControlsListener].
 * The [totalPage], [currentPage] and [zoomScale] are updated in code.
 */
class IDnowPdfLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr), IDnowMarginable {
    interface Listener {
        fun onReuploadClick() {}
        fun onDecreaseZoomClick() {}
        fun onIncreaseZoomClick() {}
    }

    private var _binding: IdnowPdfLayoutBinding? = null
    private val binding get() = _binding!!

    private val contentPadding = SpacingEnum.SPACING_SM
    private var listener: Listener? = null

    var totalPage: Int = 0
        set(value) {
            field = max(0, value)
            updatePageLabel()
        }

    var currentPage: Int = 0
        set(value) {
            field = value.coerceIn(0, totalPage)
            updatePageLabel()
        }

    /** Updating Zoom scale will update the corresponding text. The value will always be at least 0. */
    @FloatRange(from = 0.0)
    var zoomScale: Float = 1.0f
        set(value) {
            field = max(0f, value)
            updateZoomScale()
        }

    var showReupload: Boolean = true
        set(value) {
            field = value
            binding.idnPdfViewerReuploadBtn.isVisible = value
        }

    override var margins by marginable()

    init {
        _binding = IdnowPdfLayoutBinding.inflate(LayoutInflater.from(context), this)

        context.withStyledAttributes(attrs, R.styleable.IDnowPdfLayout, defStyleAttr) {
            margins = extractMargins(R.styleable.IDnowPdfLayout)

            showReupload = getBoolean(R.styleable.IDnowPdfLayout_showReupload, true)
        }

        setBackgroundColor(Tokens.backgroundSecondary)

        updatePadding(SpacingQuad(all = contentPadding))
        binding.idnPdfViewerContainer.updateLayoutParams<MarginLayoutParams> {
            updateMargins(top = contentPadding.value.toDp(context))
        }
        zoomScale = 1f

        binding.idnPdfViewerReuploadBtn.setOnClickListener { listener?.onReuploadClick() }
        binding.idnPdfViewerDecreaseZoom.setOnClickListener { listener?.onDecreaseZoomClick() }
        binding.idnPdfViewerIncreaseZoom.setOnClickListener { listener?.onIncreaseZoomClick() }

        isFocusable = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        contentDescription = resources.getString(R.string.sunflower_pdf_accessibility_desc)

        binding.idnPdfViewerPageCountLabel.isFocusable = true
    }

    override fun addView(child: View?, index: Int, params: ViewGroup.LayoutParams?) {
        if (_binding == null) super.addView(child, index, params)
        else binding.idnPdfViewerContainer.addView(child, index, params)
    }

    fun setControlsListener(listener: Listener) {
        this.listener = listener
    }

    private fun updatePageLabel() {
        binding.idnPdfViewerPageCountLabel.text = "$currentPage/$totalPage"
        binding.idnPdfViewerPageCountLabel.contentDescription = resources.getString(R.string.sunflower_pdf_accessibility_page, currentPage, totalPage)
    }

    private fun updateZoomScale() {
        val zoomPercent = (zoomScale * 100f).roundToInt()

        fun accessibilityButtonZoom(@StringRes buttonSpecificRes: Int) = buildString {
            append(resources.getString(R.string.sunflower_pdf_accessibility_zoom, zoomPercent), " ")
            append(resources.getString(buttonSpecificRes))
        }

        binding.idnPdfViewerZoomLabel.text = resources.getString(R.string.sunflower_percent, zoomPercent)
        binding.idnPdfViewerDecreaseZoom.contentDescription = accessibilityButtonZoom(R.string.sunflower_pdf_accessibility_zoom_out)
        binding.idnPdfViewerIncreaseZoom.contentDescription = accessibilityButtonZoom(R.string.sunflower_pdf_accessibility_zoom_in)
    }
}