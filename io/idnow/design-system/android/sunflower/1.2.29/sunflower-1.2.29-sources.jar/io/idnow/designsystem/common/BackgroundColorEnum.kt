package io.idnow.designsystem.common

import io.idnow.designsystem.tokens.Tokens

enum class BackgroundColorEnum {
    PRIMARY,
    SECONDARY,
    TERTIARY,
    DARKER;

    /**
     * Retrieve the token associated to this enum.
     * return @ColorInt
     */
    fun color(): Int {
        return when(this) {
            PRIMARY -> Tokens.backgroundPrimary
            SECONDARY -> Tokens.backgroundSecondary
            TERTIARY -> Tokens.backgroundTertiary
            DARKER -> Tokens.backgroundDarker
        }
    }
}