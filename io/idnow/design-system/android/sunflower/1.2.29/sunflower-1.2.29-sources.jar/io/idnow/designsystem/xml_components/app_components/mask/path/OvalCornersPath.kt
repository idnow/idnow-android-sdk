package io.idnow.designsystem.xml_components.app_components.mask.path

import android.graphics.Path
import android.graphics.PathMeasure
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad

/**
 * Create a path with 4 corners in an oval shape (top, left, bottom, right)
 */
internal class OvalCornersPath: PathToDisplay {
    override fun getPathToDraw(path: Path, quad: IDnowMaskQuad) {
        val topLeft = quad.leftTop
        val bottomRight = quad.rightBottom
        // Create a oval path
        val ovalPath = Path().apply {
            addOval(topLeft.x.toFloat(), topLeft.y.toFloat(), bottomRight.x.toFloat(), bottomRight.y.toFloat(), Path.Direction.CW)
        }

        // Divide the path into 16 sections
        val pathMeasure = PathMeasure(ovalPath, false)
        val sectionLength = pathMeasure.length / 16

        path.apply {
            fillType = Path.FillType.EVEN_ODD
            // Draw only the section that correspond to a corner.
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 1))
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 4))
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 5))
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 8))
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 9))
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 12))
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 13))
            addPath(getSegmentedPathForSectionNumber(pathMeasure, sectionLength, 16))
        }
    }

    /**
     * Retrieve a section of a given.
     * @param pathMeasure the path to divide
     * @param sectionLength the length a one section
     * @param sectionNumber the number corresponding to the section we want to get from the full path
     */
    private fun getSegmentedPathForSectionNumber(pathMeasure: PathMeasure, sectionLength: Float, sectionNumber: Int) : Path {
        val path = Path()
        pathMeasure.getSegment(sectionLength * (sectionNumber - 1), sectionLength * sectionNumber, path, true)
        return path
    }
}