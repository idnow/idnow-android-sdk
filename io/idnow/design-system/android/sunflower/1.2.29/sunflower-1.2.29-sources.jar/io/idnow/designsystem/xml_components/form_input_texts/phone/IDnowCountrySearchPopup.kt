package io.idnow.designsystem.xml_components.form_input_texts.phone

import android.content.Context
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowCountrySearchPopupBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowCountryFlagItem

internal class IDnowCountrySearchPopup(
    private val context: Context,
    private val anchorView: View,
    private val countries: List<IDnowCountryFlagItem>,
    private val selectedItem: IDnowCountryFlagItem?,
    private val maxVisibleItem: Int,
    private val isSearchable: Boolean = true,
    private val onCountrySelected: (IDnowCountryFlagItem) -> Unit,
    private val onDismiss: () -> Unit,
) {
    private val popupWindow: PopupWindow
    private val contentView: IdnowCountrySearchPopupBinding = IdnowCountrySearchPopupBinding.inflate(LayoutInflater.from(context))
    private lateinit var adapter: IDnowSearchableCountryAdapter

    init {
        popupWindow = PopupWindow(
            contentView.root,
            anchorView.width,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true,
        )

        setupPopupStyle()
        setupViews()
    }

    private fun setupPopupStyle() {
        with(FormInputsStyle) {
            val background = GradientDrawable().apply {
                cornerRadius = ContainerStyle.cornerRadius.toDp(context).toFloat()
                setStroke(strokeWidth.toDp(context), popupBackgroundColor)
                setColor(popupBackgroundColor)
            }
            popupWindow.setBackgroundDrawable(background)
            popupWindow.elevation = 0f.toDp(context).toFloat()
            popupWindow.isOutsideTouchable = true
            popupWindow.setOnDismissListener { onDismiss() }
        }
    }

    private fun setupViews() {
        val searchEditText = contentView.idnCountrySearchPopupEdit
        val recyclerView = contentView.idnCountrySearchPopupRecyclerView

        searchEditText.isVisible = isSearchable

        adapter = IDnowSearchableCountryAdapter(
            countries = countries.toMutableList(),
            selectedItem = selectedItem,
            onItemClick = { country ->
                onCountrySelected(country)
                dismiss()
            },
        )
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        searchEditText.editText().addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                adapter.filter(s?.toString() ?: "")
            }
        })
    }

    private fun calculatePopupHeight(): Int {
        val searchField = contentView.idnCountrySearchPopupEdit
        val searchFieldHeight = if (isSearchable) {
            searchField.measure(
                View.MeasureSpec.makeMeasureSpec(anchorView.width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            searchField.measuredHeight + (FormInputsStyle.itemMargin.toDp(context) * 2) + Tokens.spacingSm.toDp(context)
        } else 0

        val itemHeight = context.resources.getDimension(R.dimen.idnow_item_size).toInt() + (Tokens.spacingSm.toDp(context) * 2)
        val visibleItems = minOf(countries.size, maxVisibleItem)
        val itemsHeight = visibleItems * itemHeight

        return searchFieldHeight + itemsHeight
    }

    fun show() {
        val desiredPopupHeight = calculatePopupHeight()

        val anchorLocation = IntArray(2)
        anchorView.getLocationOnScreen(anchorLocation)
        val anchorX = anchorLocation[0]
        val anchorY = anchorLocation[1]

        val visibleFrame = Rect()
        anchorView.getWindowVisibleDisplayFrame(visibleFrame)

        val spaceBelow = visibleFrame.bottom - (anchorY + anchorView.height)
        val spaceAbove = anchorY - visibleFrame.top

        val showAbove = spaceBelow < desiredPopupHeight && spaceAbove > spaceBelow
        val availableSpace = if (showAbove) spaceAbove else spaceBelow
        val finalPopupHeight = minOf(desiredPopupHeight, availableSpace)
        val yPosition = if (showAbove) anchorY - finalPopupHeight else anchorY + anchorView.height

        popupWindow.width = anchorView.width
        popupWindow.height = finalPopupHeight

        popupWindow.showAtLocation(
            anchorView,
            Gravity.NO_GRAVITY,
            anchorX,
            yPosition,
        )
    }

    fun dismiss() {
        popupWindow.dismiss()
    }
}
