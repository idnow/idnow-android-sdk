package io.idnow.designsystem.customization

import androidx.annotation.Dimension

data class FontSize(
    val fontSize00: Float,
    val fontSize0: Float,
    val fontSize1: Float,
    val fontSize2: Float,
    val fontSize3: Float,
    val fontSize4: Float,
    val fontSize5: Float,
    val fontSize6: Float
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            @Dimension(unit = Dimension.SP)
            fontSize00: Float? = null,
            @Dimension(unit = Dimension.SP)
            fontSize0: Float? = null,
            @Dimension(unit = Dimension.SP)
            fontSize1: Float? = null,
            @Dimension(unit = Dimension.SP)
            fontSize2: Float? = null,
            @Dimension(unit = Dimension.SP)
            fontSize3: Float? = null,
            @Dimension(unit = Dimension.SP)
            fontSize4: Float? = null,
            @Dimension(unit = Dimension.SP)
            fontSize5: Float? = null,
            @Dimension(unit = Dimension.SP)
            fontSize6: Float? = null,
        ) = FontSize (
            fontSize00 = fontSize00 ?: DefaultPrimitives.fontSize00,
            fontSize0 = fontSize0 ?: DefaultPrimitives.fontSize0,
            fontSize1 = fontSize1 ?: DefaultPrimitives.fontSize1,
            fontSize2 = fontSize2 ?: DefaultPrimitives.fontSize2,
            fontSize3 = fontSize3 ?: DefaultPrimitives.fontSize3,
            fontSize4 = fontSize4 ?: DefaultPrimitives.fontSize4,
            fontSize5 = fontSize5 ?: DefaultPrimitives.fontSize5,
            fontSize6 = fontSize6 ?: DefaultPrimitives.fontSize6
        )
    }
}
