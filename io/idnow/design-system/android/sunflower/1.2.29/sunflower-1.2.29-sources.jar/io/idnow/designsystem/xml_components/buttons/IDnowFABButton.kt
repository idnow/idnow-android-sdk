package io.idnow.designsystem.xml_components.buttons

import android.content.Context
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.styles.ButtonStyle
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.stroke
import io.idnow.designsystem.xml_components.extension.toDp

class IDnowFABButton : AppCompatImageButton, IDnowMarginable {
    /** Style, always primary for FAB button */
    private val style: ButtonStyle

    /** Margins */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowFABButton)
        val attrStyle = ButtonType.entries[customArray.getInt(R.styleable.IDnowFABButton_style, ButtonType.PRIMARY.ordinal)]
        val size = ButtonSize.entries[customArray.getInt(R.styleable.IDnowFABButton_size, ButtonSize.MEDIUM.ordinal)]

        style = when (attrStyle) {
            ButtonType.PRIMARY -> ButtonStyle.PrimaryButton(size)
            ButtonType.SECONDARY -> ButtonStyle.SecondaryButton(size)
            ButtonType.DANGER -> ButtonStyle.DangerButton(size)
            ButtonType.TRIGGER -> ButtonStyle.TriggerButton(size)
        }
        /** Handle the component margin. */
        val margin = customArray.getInt(R.styleable.IDnowFABButton_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowFABButton_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowFABButton_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowFABButton_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowFABButton_token_endMargin, -1)
        margins = style.margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        isEnabled = customArray.getBoolean(R.styleable.IDnowFABButton_android_enabled, true)

        customArray.recycle()
        initialize()
    }

    private fun initialize() {
        setupBackground()

        /** Color the drawable */
        drawable.setTint(style.textColor)
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        val iconSize = resources.getDimension(style.iconSize).toInt()
        // Padding size is hardcoded per Figma guideline
        val padding = when (style.size) {
            ButtonSize.SMALL -> 8
            ButtonSize.MEDIUM -> 14
            ButtonSize.LARGE -> 16
        }.toDp(context)
        val componentSize = iconSize + (padding * 2)

        setPadding(padding)

        /** Set a default margin. Update it only if no margin have been already set. */
        val mParams = params?.applyMargin(
            context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value
        )

        mParams?.width = componentSize
        mParams?.height = componentSize

        super.setLayoutParams(mParams)
    }

    private fun setupBackground() {
        if (style is ButtonStyle.TriggerButton) {
            val backgroundDrawable = ResourcesCompat.getDrawable(resources, R.drawable.idnow_button_trigger_background, null)
            background = (backgroundDrawable?.mutate() as? StateListDrawable)?.customize {
                // Size of the stroke in the drawable. It is used to correctly draw inner background corner radius when the component is not completely rounded.
                val strokeSize = 2.toDp(context)
                val cornerRadiusSize = style.cornerRadius.toDp(context).toFloat()

                // State - Pressed
                layer(index = 0) {
                    item(index = 0) {
                        solidColor = style.pressedColor
                        cornerRadius(cornerRadiusSize - strokeSize)
                    }

                    item(index = 1) {
                        stroke(color = style.pressedColor, width = strokeSize)
                        cornerRadius(cornerRadiusSize)
                    }
                }
                // State - Default
                layer(index = 1) {
                    item(index = 0) {
                        solidColor = style.backgroundColor
                        cornerRadius(cornerRadiusSize - strokeSize)
                    }

                    item(index = 1) {
                        stroke(color = style.backgroundColor, width = strokeSize)
                        cornerRadius(cornerRadiusSize)
                    }
                }
            }
        } else {
            setBackgroundResource(R.drawable.idnow_button_background)
            (background as StateListDrawable).apply {
                /** Update colors of pressed state */
                customize(
                    solidColor = style.backgroundColor,
                    strokeColor = style.strokeColor,
                    strokeWidth = style.strokeWidth.toDp(context),
                    cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                    indexChild = 0,
                    innerChild = 0,
                    multipleItem = true
                )
                /** Pressed over view */
                customize(
                    solidColor = Utils.adjustAlpha(style.pressedColor, style.pressedColorOpacity),
                    cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                    indexChild = 0,
                    innerChild = 1,
                    multipleItem = true
                )
                /** Update colors of classic state */
                customize(
                    solidColor = style.backgroundColor,
                    strokeColor = style.strokeColor,
                    strokeWidth = style.strokeWidth.toDp(context),
                    cornerRadius = style.cornerRadius.toDp(context).toFloat(),
                    indexChild = 1
                )
            }
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ButtonStyle.opacity(enabled)
    }
}