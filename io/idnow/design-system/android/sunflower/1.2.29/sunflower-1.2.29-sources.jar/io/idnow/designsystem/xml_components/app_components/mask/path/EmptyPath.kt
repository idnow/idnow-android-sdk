package io.idnow.designsystem.xml_components.app_components.mask.path

import android.graphics.Path
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad

/**
 * Empty path to draw nothing.
 */
internal class EmptyPath: PathToDisplay {
    override fun getPathToDraw(path: Path, quad: IDnowMaskQuad) { /* Draw nothing */ }
}