package io.idnow.designsystem.xml_components.form_input_texts.common

interface OnIDnowItemSelected {
    /**
     * Callback method to be invoked when an item in this view has been selected.
     * This callback is invoked only when the newly selected position is different from the previously selected position or if there was no selected item.
     * @param iDnowItem the selected item
     */
    fun onItemSelected(iDnowItem: IDnowItem)
}