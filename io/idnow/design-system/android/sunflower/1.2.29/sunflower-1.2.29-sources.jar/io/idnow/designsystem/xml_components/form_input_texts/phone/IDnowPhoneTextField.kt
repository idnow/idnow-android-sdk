package io.idnow.designsystem.xml_components.form_input_texts.phone

import android.content.Context
import android.content.res.ColorStateList
import android.os.Build
import android.text.InputType
import android.util.AttributeSet
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import androidx.core.content.res.ResourcesCompat
import androidx.core.content.withStyledAttributes
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowPhoneEdittextBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowBaseTextField
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowCountryFlagItem
import kotlin.math.max

private const val DEFAULT_MAX_VISIBLE_ITEM = 5

class IDnowPhoneTextField @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : IDnowBaseTextField(context, attrs, defStyleAttr) {
    private val textBinding: IdnowPhoneEdittextBinding =
        IdnowPhoneEdittextBinding.bind(binding.idnField.apply { layoutResource = R.layout.idnow_phone_edittext }.inflate())

    override val editText: EditText = textBinding.idnPhoneEditText

    private var searchable: Boolean = false

    private var countrySearchPopup: IDnowCountrySearchPopup? = null
    private var selectedFlagItem: IDnowCountryFlagItem? = null
        set(value) {
            field = value

            if (value == null) {
                textBinding.idnContFlagArea.isVisible = false
            } else {
                textBinding.idnContFlagArea.isVisible = true

                textBinding.idnowItemIcon.apply {
                    val iconSize = resources.getDimension(R.dimen.idnow_icon_size).toInt()
                    layoutParams.applyMargin(context = context, start = Tokens.spacingSm, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
                    layoutParams.width = iconSize
                    layoutParams.height = iconSize
                    setImageResource(value.icon)
                }

                textBinding.idnContChevron.apply {
                    val drawable = ResourcesCompat.getDrawable(resources, R.drawable.sunflower_ic_chevron_up_down, null)
                    layoutParams = layoutParams.applyMargin(context, start = FormInputsStyle.flagGroupMargin)
                    imageTintList = ColorStateList.valueOf(Tokens.primaryBackground)
                    val iconSize = resources.getDimension(R.dimen.idnow_icon_size).toInt()
                    drawable?.setBounds(0, 0, iconSize, iconSize)
                    setImageDrawable(drawable)
                }

                textBinding.idnContPhonePrefix.apply {
                    layoutParams.applyMargin(context = context, start = FormInputsStyle.flagGroupMargin, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
                    text = value.prefix
                    val font = ContainerStyle.font(context)
                    setTypography(font)
                    setTextColor(FormInputsStyle.popupTextColor)
                }
            }
        }

    /** Set the countries item list to display in the spinner. */
    var countriesFlagList: List<IDnowCountryFlagItem> = emptyList()
        set(value) {
            field = value
            selectedFlagItem = field.firstOrNull()
        }

    /** Set this value to receive callback on phone number country prefix change. */
    var onIDnowCountryPrefixChange: (IDnowCountryFlagItem) -> Unit = {}

    /** The maximum visible item in the dropdown, will always be at least 1. */
    var maxVisibleItem: Int = DEFAULT_MAX_VISIBLE_ITEM
        set(value) {
            field = max(1, value)
        }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowPhoneTextField, defStyleAttr) {
            searchable = getBoolean(R.styleable.IDnowPhoneTextField_searchable, false)
        }

        with(textBinding.idnContFlagArea) {
            setOnClickListener {
                showCountrySearchPopup()
            }

            accessibilityDelegate = object : AccessibilityDelegate() {
                override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfo) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    val selected = getSelectedCountry() ?: return

                    info.className = android.widget.Spinner::class.java.name

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        info.hintText = "${selected.content}, ${selected.prefix}"
                        info.contentDescription = resources.getString(R.string.sunflower_flag_content_description)
                    } else {
                        info.contentDescription = "${context.getString(R.string.sunflower_flag_content_description)} ${selected.content}, ${selected.prefix}"
                    }
                }
            }
        }

        editText.inputType = InputType.TYPE_CLASS_PHONE
    }

    override fun onDetachedFromWindow() {
        onIDnowCountryPrefixChange = {}
        super.onDetachedFromWindow()
    }

    fun getSelectedCountry(): IDnowCountryFlagItem? = selectedFlagItem

    fun setSelectedItem(flagItem: IDnowCountryFlagItem) {
        flagItem.takeIf { countriesFlagList.contains(it) }?.let { selectedFlagItem = it }
    }

    private fun showCountrySearchPopup() {
        countrySearchPopup?.dismiss()
        countrySearchPopup = IDnowCountrySearchPopup(
            context = context,
            anchorView = binding.idnContainer,
            countries = countriesFlagList,
            selectedItem = selectedFlagItem,
            maxVisibleItem = maxVisibleItem,
            isSearchable = searchable,
            onCountrySelected = { selectedCountry ->
                selectedFlagItem = selectedCountry
                onIDnowCountryPrefixChange(selectedCountry)
            },
            onDismiss = {
                textBinding.idnContChevron.isSelected = false
            }
        )

        textBinding.idnContChevron.isSelected = true
        countrySearchPopup?.show()
    }
}