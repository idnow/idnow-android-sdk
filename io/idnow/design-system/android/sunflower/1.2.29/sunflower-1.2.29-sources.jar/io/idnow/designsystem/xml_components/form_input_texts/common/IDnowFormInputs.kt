package io.idnow.designsystem.xml_components.form_input_texts.common

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.view.doOnLayout
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowFormInputsBinding
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTypography

abstract class IDnowFormInputs : ConstraintLayout, IDnowMarginable {
    /** Inflate the layout into the view. */
    protected val binding = IdnowFormInputsBinding.inflate(LayoutInflater.from(context), this)

    /** Default [Tokens.main] tint color for leading icon. Override this to provide different value */
    open val leadingIconTint: ColorStateList = ColorStateList.valueOf(Tokens.main)

    /** Display and set the label text. */
    var label: CharSequence = ""
        set(value) {
            field = value
            setContentDescription()
            binding.idnTvLabel.apply {
                isVisible = field.isNotEmpty()
                text = field
            }
        }

    /** Display and set the helper text. */
    var helperText: CharSequence = ""
        set(value) {
            field = value
            setContentDescription()
            binding.idnTvHelper.apply {
                isVisible = field.isNotEmpty()
                text = field
            }
        }

    /** Display and set the error text. */
    var errorText: CharSequence = ""
        set(value) {
            field = value
            setContentDescription()
            binding.idnTvError.text = field
        }

    /** Show/hide the error text group */
    var stateError: Boolean = false
        set(value) {
            field = value
            setContentDescription()
            binding.idnErrorGroup.isVisible = field && errorText.isNotEmpty()
            binding.idnContainer.isError = field
        }

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowFormInputs) {
            label = getString(R.styleable.IDnowFormInputs_label) ?: ""
            helperText = getString(R.styleable.IDnowFormInputs_helperText) ?: ""
            errorText = getString(R.styleable.IDnowFormInputs_errorText) ?: ""
            stateError = getBoolean(R.styleable.IDnowFormInputs_state_error, false)

            /** Handle the component margin. */
            val margin = getInt(R.styleable.IDnowFormInputs_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowFormInputs_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowFormInputs_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowFormInputs_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowFormInputs_token_endMargin, -1)
            margins = FormInputsStyle.margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        }
        initialize()
    }

    private fun initialize() {
        /** To apply the token to all the constraints, we need to update them all with the tokens here. */
        doOnLayout { updateConstraints() }
    }


    private fun updateConstraints() {
        with(FormInputsStyle) {
            binding.idnTvLabel.apply {
                layoutParams = layoutParams.applyMargin(context, bottom = itemMargin)
                setTypography(font(context))
                setTextColor(labelColor)
            }
            binding.idnIvError.imageTintList = ColorStateList.valueOf(errorColor)
            binding.idnTvError.apply {
                layoutParams = layoutParams.applyMargin(context, start = itemMargin, bottom = itemMargin)
                setTypography(font(context))
                setTextColor(errorColor)
            }
            binding.idnContainer.apply {
                layoutParams = layoutParams.applyMargin(context)
            }
            binding.idnTvHelper.apply {
                layoutParams = layoutParams.applyMargin(context, top = itemMargin)
                setTypography(font(context))
                setTextColor(helperColor)
            }
            binding.idnContLeadingIcon.apply {
                layoutParams = layoutParams.applyMargin(context, start = itemMargin)
                imageTintList = leadingIconTint
            }
            binding.idnContClear.apply {
                layoutParams = layoutParams.applyMargin(context, end = itemMargin)
                imageTintList = ColorStateList.valueOf(Tokens.main)
            }
            binding.idnContTrailingIcon.apply {
                layoutParams = layoutParams.applyMargin(context, end = itemMargin)
                imageTintList = ColorStateList.valueOf(Tokens.primaryBackground)
            }
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }


    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        binding.idnContainer.isEnabled = enabled
    }

    /**
     * Display the given view with the given icon.
     * If the icon is null, hide the view instead.
     * @param iconView the view to display/hide
     * @param icon the icon (null to hide view)
     */
    protected fun displayViewWithIcon(iconView: ImageView, icon: Drawable?) {
        if(icon != null) {
            iconView.apply {
                isVisible = true
                val iconSize = resources.getDimension(R.dimen.idnow_icon_size).toInt()
                icon.setBounds(0, 0, iconSize, iconSize)
                setImageDrawable(icon)
            }
        } else {
            iconView.isVisible = false
        }
    }

    open fun setContentDescription() { }

    /** Build the a custom content description for accessibility. */
    protected fun getAccessibilityContentText(): String {
        return buildString {
            if(label.isNotEmpty()) append("$label${if(!label.endsWith(".")) "." else ""} ")
            if(stateError && errorText.isNotEmpty()) {
                append("${context.getString(R.string.sunflower_warning)} ")
                append("$errorText${if(!errorText.endsWith(".")) "." else ""} ")
            }
            if(helperText.isNotEmpty()) append("$helperText${if(!helperText.endsWith(".")) "." else ""}")
        }
    }
}