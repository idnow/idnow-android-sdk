package io.idnow.designsystem.xml_components.controls.idn_switch

import android.content.Context
import android.graphics.Rect
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import android.view.accessibility.AccessibilityEvent
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.res.ResourcesCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.ControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp

internal class IDnowSwitchInternal : SwitchCompat {
    /** Internal usage only ! Notify a control of a change. */
    var onInternalChange: (() -> Unit)? = null

    /** Size of the switch */
    var size: Size = Size.NORMAL
        set(value) {
            field = value
            setupDrawable()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        initialize()
    }

    private fun initialize() {
        /** No Text required for ON and OFF states */
        textOn = ""
        textOff = ""
        /** Prevent switch to expand to larger width when custom track and thumb drawables are used */
        setEnforceSwitchWidth(false)
    }

    private fun setupDrawable() {
        /**
         * To update the width we have to update the switchMinWidth parameter
         * as it's the one that will be used by the onMeasure while drawing the view
         */
        switchMinWidth = ControlStyle.toggleWidth(size).toDp(context)
        val drawableTrack = ResourcesCompat.getDrawable(context.resources, R.drawable.idnow_toggle_button_background, null)
        val toggleBounds = Rect(0, 0, ControlStyle.toggleWidth(size).toDp(context), ControlStyle.toggleHeight(size).toDp(context))
        (drawableTrack as StateListDrawable).apply {
            /** Customization of checked state */
            customize(
                solidColor = ControlStyle.activeColor,
                indexChild = 0,
                bounds = toggleBounds
            )
            /** Customization of unchecked state */
            customize(
                solidColor = ControlStyle.uncheckedColor,
                indexChild = 1,
                bounds = toggleBounds
            )
        }
        trackDrawable = drawableTrack

        val drawableThumb = ResourcesCompat.getDrawable(context.resources, R.drawable.idnow_toggle_button_thumb, null)
        val thumbBounds = Rect(0, 0, ControlStyle.thumbSize(size).toDp(context), ControlStyle.thumbSize(size).toDp(context))
        (drawableThumb as StateListDrawable).apply {
            /** Customization knob */
            customize(
                solidColor = ControlStyle.toggleKnobColor,
                indexChild = 0,
                multipleItem = true,
                bounds = thumbBounds
            )
        }
        thumbDrawable = drawableThumb
    }

    override fun toggle() {
        /* Only trigger the state changes if the radio is enabled */
        if (isEnabled) {
            isChecked = !isChecked
            sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_CLICKED)
        }
    }

    override fun setChecked(checked: Boolean) {
        /** Notify internally */
        onInternalChange?.invoke()
        super.setChecked(checked)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ControlStyle.opacity(enabled)
    }
}