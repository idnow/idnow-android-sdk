package io.idnow.designsystem.common

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.annotation.ColorInt
import io.idnow.designsystem.api.IDnowDesignSystem
import io.idnow.designsystem.tokens.Tokens
import kotlin.math.roundToInt
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

internal object Utils {
    const val WCAG2_MINIMUM_RATIOS_AA_LARGE_TEXT = 3.5

    @ColorInt
    fun adjustAlpha(@ColorInt color: Int, factor: Float): Int {
        val alpha = (Color.alpha(color) * factor).roundToInt()
        val red = Color.red(color)
        val green = Color.green(color)
        val blue = Color.blue(color)
        return Color.argb(alpha, red, green, blue)
    }

    /**
     * Calculates the relative luminance of an RGB color according to WCAG 2.0.
     *
     * Formula source:
     * https://www.w3.org/TR/WCAG20-TECHS/G17.html#G17-tests
     *
     * Steps:
     * 1. Convert 0–255 RGB channels to 0–1 range
     * 2. Apply gamma correction
     * 3. Return relative luminance (0–1)
     *
     * @param color The color as an Android @ColorInt (ARGB or RGB Int)
     * @return Relative luminance between 0.0 and 1.0
     */
    @SuppressLint("DefaultLocale")
    fun getLuminance(@ColorInt color: Int): Double {
        // Extract RGB channels from the color Int
        val r = ((color shr 16) and 0xFF) / 255.0
        val g = ((color shr 8) and 0xFF) / 255.0
        val b = (color and 0xFF) / 255.0

        // Applies WCAG gamma correction
        fun transform(v: Double): Double =
            if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)

        val R = transform(r)
        val G = transform(g)
        val B = transform(b)

        // Compute luminance using WCAG coefficients
        val luminance = (0.2126 * R) + (0.7152 * G) + (0.0722 * B)

        return (luminance * 1000).roundToInt() / 1000.0
    }

    /**
     * Calculates the contrast ratio between two colors following the WCAG 2.0 formula.
     *
     * Formula source:
     * https://www.w3.org/TR/WCAG20-TECHS/G17.html#G17-tests
     *
     * Steps:
     * 1. Compute luminance of both colors
     * 2. Apply contrast formula:
     *    (Lighter + 0.05) / (Darker + 0.05)
     *
     * @param foreground The foreground color as Android @ColorInt
     * @param background The background color as Android @ColorInt
     * @return Contrast ratio between 1.00 and 21.00
     */
    @SuppressLint("DefaultLocale")
    fun getContrastWCAG2(@ColorInt foreground: Int, @ColorInt background: Int): Double {
        val l1 = getLuminance(foreground)
        val l2 = getLuminance(background)

        val ratio = (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)

        return (ratio * 100).roundToInt() / 100.0
    }

    /**
     * Returns either grey100 or grey900 depending on WCAG contrast
     * between primary text color and a background.
     *
     * In Light mode:
     *    Low contrast  -> use grey900
     *    High contrast -> use grey100
     *
     * In Dark mode:
     *    Low contrast  -> use grey100
     *    High contrast -> use grey900
     */
    fun getLuminanceTokenForPrimaryText(@ColorInt background: Int): Int {
        val colorRatio = getContrastWCAG2(Tokens.primaryText, background)
        val isLowContrast = colorRatio < WCAG2_MINIMUM_RATIOS_AA_LARGE_TEXT

        val greyLightMode = if (isLowContrast) Tokens.grey().grey900 else Tokens.grey().grey100
        val greyDarkMode  = if (isLowContrast) Tokens.grey().grey100 else Tokens.grey().grey900

        return if (IDnowDesignSystem.isLightMode) greyLightMode else greyDarkMode
    }

}