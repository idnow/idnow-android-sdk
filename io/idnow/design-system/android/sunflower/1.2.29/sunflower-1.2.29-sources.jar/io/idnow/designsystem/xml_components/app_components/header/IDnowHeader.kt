package io.idnow.designsystem.xml_components.app_components.header

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.withStyledAttributes
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.common.TintColorEnum
import io.idnow.designsystem.databinding.IdnowHeaderBinding
import io.idnow.designsystem.styles.HeaderStyle
import io.idnow.designsystem.xml_components.extension.UnitLambda

class IDnowHeader: ConstraintLayout {
    /** Inflate the layout into the view. */
    val binding = IdnowHeaderBinding.inflate(LayoutInflater.from(context), this)

    /** Display or hide the start icon. */
    var startIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(binding.idnowHeaderStartIcon, value, startIconTintColor)
        }

    /** Display or hide the end icon. */
    var endIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(binding.idnowHeaderEndIcon, value, endIconTintColor)
        }

    /** Display or hide the additional end icon. */
    var additionalEndIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(binding.idnowHeaderAdditionalEndIcon, value, additionalEndIconTintColor)
        }

    /**
     * Tint color enum for the start icon.
     * It allows to set a specific token color in the code or in xml.
     */
    var startIconTintColor: TintColorEnum = TintColorEnum.MAIN
        set(value) {
            field = value
            binding.idnowHeaderStartIcon.setColorFilter(field.color())
        }

    /**
     * Tint color enum for the end icon.
     * It allows to set a specific token color in the code or in xml.
     */
    var endIconTintColor: TintColorEnum = TintColorEnum.MAIN
        set(value) {
            field = value
            binding.idnowHeaderEndIcon.setColorFilter(field.color())
        }

    /**
     * Tint color enum for the additional end icon.
     * It allows to set a specific token color in the code or in xml.
     */
    var additionalEndIconTintColor: TintColorEnum = TintColorEnum.MAIN
        set(value) {
            field = value
            binding.idnowHeaderAdditionalEndIcon.setColorFilter(field.color())
        }

    var brand: Boolean = false
        set(value) {
            field = value
            binding.idnowHeaderBrand.isVisible = field
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowHeader) {
            brand = getBoolean(R.styleable.IDnowHeader_brand, false)
            startIcon = getDrawable(R.styleable.IDnowHeader_startIcon)
            endIcon = getDrawable(R.styleable.IDnowHeader_endIcon)
            additionalEndIcon = getDrawable(R.styleable.IDnowHeader_additionalEndIcon)
            startIconTintColor = TintColorEnum.entries[getInt(R.styleable.IDnowHeader_token_startIconTint, TintColorEnum.MAIN.ordinal)]
            endIconTintColor = TintColorEnum.entries[getInt(R.styleable.IDnowHeader_token_endIconTint, TintColorEnum.MAIN.ordinal)]
            additionalEndIconTintColor = TintColorEnum.entries[getInt(R.styleable.IDnowHeader_token_additionalEndIconTint, TintColorEnum.MAIN.ordinal)]
        }
        initialize()
    }

    private fun initialize() {
        /** Apply the opacity to all the icons. */
        binding.idnowHeaderStartIcon.alpha = HeaderStyle.iconOpacity
        binding.idnowHeaderEndIcon.alpha = HeaderStyle.iconOpacity
        binding.idnowHeaderAdditionalEndIcon.alpha = HeaderStyle.iconOpacity
    }

    /**
    * Register a callback to be invoked when the start icon is clicked.
    * @param lambda the callback that will run
    */
    fun setOnStartIconClickListener(lambda: UnitLambda?) {
        binding.idnowHeaderStartIcon.setOnClickListener {
            lambda?.invoke()
        }
    }


    /**
     * Register a callback to be invoked when the end icon is clicked.
     * @param lambda the callback that will run
     */
    fun setOnEndIconClickListener(lambda: UnitLambda?) {
        binding.idnowHeaderEndIcon.setOnClickListener {
            lambda?.invoke()
        }
    }


    /**
     * Register a callback to be invoked when the additional end icon is clicked.
     * @param lambda the callback that will run
     */
    fun setOnAdditionalEndIconClickListener(lambda: UnitLambda?) {
        binding.idnowHeaderAdditionalEndIcon.setOnClickListener {
            lambda?.invoke()
        }
    }

    /**
     * Display the given view with the given icon.
     * If the icon is null, hide the view instead.
     * @param iconView the view to display/hide
     * @param icon the icon (null to hide view)
     * @param tint the tint to apply
     */
    private fun displayViewWithIcon(iconView: ImageView?, icon: Drawable?, tint: TintColorEnum) {
        iconView?.apply {
            if (icon != null) {
                isVisible = true
                setImageDrawable(icon)
                setColorFilter(tint.color())
            } else {
                isVisible = false
            }
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        minHeight = resources.getDimensionPixelSize(R.dimen.idnow_header_icon_size)
        super.setLayoutParams(params)
    }
}