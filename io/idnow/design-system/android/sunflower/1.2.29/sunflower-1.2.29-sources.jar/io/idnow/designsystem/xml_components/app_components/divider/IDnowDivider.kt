package io.idnow.designsystem.xml_components.app_components.divider

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin

class IDnowDivider: View, IDnowMarginable {
    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad(SpacingEnum.NO_SPACING)
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowDivider)

        /** Handle the component margin. */
        val margin = customArray.getInt(R.styleable.IDnowDivider_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowDivider_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowDivider_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowDivider_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowDivider_token_endMargin, -1)
        margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        customArray.recycle()

        /** Update background color */
        setBackgroundColor(Tokens.borderPrimary)
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }
}