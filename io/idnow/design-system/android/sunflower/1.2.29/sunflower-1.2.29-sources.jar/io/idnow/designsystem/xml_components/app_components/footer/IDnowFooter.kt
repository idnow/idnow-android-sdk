package io.idnow.designsystem.xml_components.app_components.footer

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import io.idnow.designsystem.databinding.IdnowFooterBinding
import io.idnow.designsystem.styles.HeaderStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin

class IDnowFooter: ConstraintLayout {
    /** Inflate the layout into the view. */
    private val binding = IdnowFooterBinding.inflate(LayoutInflater.from(context), this)
    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        initialize()
    }

    private fun initialize() {
        /** Apply a token to the logo */
        binding.idnowFooterIcon.apply {
            layoutParams = layoutParams.applyMargin(context, bottom = Tokens.spacingXs)
            imageTintList = ColorStateList.valueOf(HeaderStyle.iconColor)
            alpha = HeaderStyle.poweredByOpacity
        }
    }
}