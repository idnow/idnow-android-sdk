package io.idnow.designsystem.xml_components.app_components.mask

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.annotation.ColorInt
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.MaskStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.app_components.mask.path.BouncePath
import io.idnow.designsystem.xml_components.app_components.mask.path.EmptyPath
import io.idnow.designsystem.xml_components.app_components.mask.path.OvalCornersPath
import io.idnow.designsystem.xml_components.app_components.mask.path.OvalPath
import io.idnow.designsystem.xml_components.app_components.mask.path.PathToDisplay
import io.idnow.designsystem.xml_components.app_components.mask.path.ProgressPath
import io.idnow.designsystem.xml_components.app_components.mask.path.RoundedRectPath
import io.idnow.designsystem.xml_components.extension.toDp

/**
 * Show a Mask view that can be display on top of a camera or an image to display only a part of the background.
 * The shape of the mast can be choose by changing the [IDnowMaskShape].
 * The color can be updated by changing the [IDnowMaskStatus].
 * You can adapt the size by giving a [IDnowMaskQuad].
 * And finally you can add an overlay with an animation using the different existing [IDnowMaskOverlay].
 */
class IDnowMaskView : View {
    /**
     * Main shape of the mask.
     */
    var shape: IDnowMaskShape = IDnowMaskShape.RECT
        set(value) {
            field = value
            determineShapeToDisplay()
            invalidate()
        }

    /**
     * Overlay to display on top of the mask.
     */
    var overlay: IDnowMaskOverlay = IDnowMaskOverlay.None
        set(value) {
            field = value
            determineShapeToDisplay()
            invalidate()
        }

    /**
     * Status of the capture, it will adapt the color based on the given status.
     */
    var quad: IDnowMaskQuad = IDnowMaskQuad(Point(0, 0), Point(0, 0), Point(0, 0), Point(0, 0))
        set(value) {
            field = value
            invalidate()
        }

    /**
     * Status of the capture, it will adapt the color based on the given status.
     */
    var status: IDnowMaskStatus = IDnowMaskStatus.ACTIVE
        set(value) {
            field = value
            invalidate()
        }

    /**
     * Mask background color.
     * Change the color of the mask background, it is not mandatory to have a token here
     * as you can have some use case with only a black transparent background.
     */
    @ColorInt
    var maskBackgroundColor = Tokens.backgroundSecondary
        set(value) {
            field = value
            invalidate()
        }

    /** Paint of the shape */
    private val shapePaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Paint of the overlay */
    private val overlayPaint: Paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Path of the shape */
    private val shapePath: Path = Path()

    /** Path of the overlay */
    private val overlayPath: Path = Path()

    /** Progress animation */
    private var animator: ValueAnimator? = null

    /** Shape path */
    private var shapeDisplay: PathToDisplay = RoundedRectPath(context, true)

    /** Overlay path */
    private var overlayDisplay: PathToDisplay = EmptyPath()

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowMaskView)

        val duration = customArray.getInteger(R.styleable.IDnowMaskView_progressDuration, MaskStyle.progressDuration)
        val bounce = customArray.getBoolean(R.styleable.IDnowMaskView_cornersBounce, false)
        shape = IDnowMaskShape.entries[customArray.getInt(R.styleable.IDnowMaskView_maskShape, IDnowMaskShape.RECT.ordinal)]
        status = IDnowMaskStatus.entries[customArray.getInt(R.styleable.IDnowMaskView_maskStatus, IDnowMaskStatus.ACTIVE.ordinal)]
        overlay = MaskOverlay.entries[customArray.getInt(R.styleable.IDnowMaskView_maskOverlay, MaskOverlay.NONE.ordinal)]
            .toIDnowMaskOverlay(duration, bounce)
        customArray.recycle()
    }

    init {
        setWillNotDraw(false)
    }

    override fun onDraw(canvas: Canvas) {
        drawShape(canvas)
        drawOverlay(canvas)
    }

    /**
     * Draw the chosen shape and color the background outside of the shape.
     */
    private fun drawShape(canvas: Canvas) {
        // Prepare the style of the shape.
        shapePaint.color = maskBackgroundColor
        shapePaint.strokeCap = Paint.Cap.ROUND
        shapePaint.style = Paint.Style.FILL
        shapePaint.strokeJoin = Paint.Join.ROUND

        // Start by outlining the view
        shapePath.reset()
        shapePath.moveTo(0f, 0f)
        shapePath.lineTo(0f, height.toFloat())
        shapePath.lineTo(width.toFloat(), height.toFloat())
        shapePath.lineTo(width.toFloat(), 0f)
        shapePath.lineTo(0f, 0f)
        // Then outline the shape
        if(!quad.isEmpty()) {
            shapeDisplay.getPathToDraw(shapePath, quad)
        }

        // Draw the shape.
        canvas.drawPath(shapePath, shapePaint)
    }

    /**
     * Draw an overlay in top of the shape.
     */
    private fun drawOverlay(canvas: Canvas) {
        if(quad.isEmpty()) return // Nothing to draw if there is no quad.
        // Prepare the style of the overlay.
        overlayPaint.strokeWidth = MaskStyle.strokeWidth.toDp(context).toFloat()
        overlayPaint.color = status.color()
        overlayPaint.style = Paint.Style.STROKE
        overlayPaint.strokeJoin = Paint.Join.ROUND

        // Prepare the path
        overlayPath.reset()
        overlayDisplay.getPathToDraw(overlayPath, quad)

        // Draw the overlay with a potential transformation.
        overlayDisplay.withTransformation(canvas) {
            canvas.drawPath(overlayPath, overlayPaint)
        }
    }

    /**
     * Determine the shape path and overlay path based on the shape and the overlay.
     */
    private fun determineShapeToDisplay() {
        // Avoid force cast later as the value can changed.
        val overlay = overlay
        // Security. Cancel the animator if there is one.
        animator?.cancel()
        when (shape) {
            IDnowMaskShape.RECT -> {
                shapeDisplay = RoundedRectPath(context, useCompleteLines = true)
                overlayDisplay = when (overlay) {
                    is IDnowMaskOverlay.Corners -> withBounce(RoundedRectPath(context, useCompleteLines = false), overlay.isBouncing)
                    IDnowMaskOverlay.Full -> RoundedRectPath(context, useCompleteLines = true)
                    is IDnowMaskOverlay.Progress -> withProgress(RoundedRectPath(context, useCompleteLines = true), overlay.duration.toLong())
                    else -> EmptyPath()
                }
            }

            IDnowMaskShape.OVAL -> {
                shapeDisplay = OvalPath()
                overlayDisplay = when (overlay) {
                    is IDnowMaskOverlay.Corners -> withBounce(OvalCornersPath(), overlay.isBouncing)
                    IDnowMaskOverlay.Full -> OvalPath()
                    is IDnowMaskOverlay.Progress -> withProgress(OvalPath(), overlay.duration.toLong())
                    else -> EmptyPath()
                }
            }
        }
    }

    /**
     * Used by the progress path to draw the overlay during a time
     */
    private fun withProgress(path: PathToDisplay, progressDuration: Long): PathToDisplay {
        val progressPath = ProgressPath(path)
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = progressDuration
            interpolator = LinearInterpolator()
            addUpdateListener { animation ->
                progressPath.progress = animation.animatedValue as Float
                invalidate()
            }
        }
        animator?.start()
        return progressPath
    }

    /**
     * Check if the bounce is enabled, return the corresponding path.
     * Start the animation if necessary.
     */
    private fun withBounce(path: PathToDisplay, isBouncing: Boolean): PathToDisplay {
        return if (isBouncing) {
            val bouncePath = BouncePath(path)
            animator = ValueAnimator.ofFloat(1f, MaskStyle.bouncePower, 1f).apply {
                duration = MaskStyle.bounceDuration
                interpolator = LinearInterpolator()
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.RESTART
                addUpdateListener { animation ->
                    bouncePath.scale = animation.animatedValue as Float
                    invalidate()
                }
            }
            animator?.start()
            bouncePath
        } else {
            path
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()

        animator?.removeAllUpdateListeners()
    }
}