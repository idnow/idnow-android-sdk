package io.idnow.designsystem.common

import android.content.Context
import io.idnow.designsystem.tokens.Typography

enum class TypographyEnum {
    H1, H2, H3, H4, H5, H6,
    LINKS_LARGE, LINKS, LINKS_SMALL,
    BODY_LARGE, BODY, BODY_SMALL,
    BODY_BOLD_LARGE, BODY_BOLD, BODY_BOLD_SMALL,
    BODY_XSMALL, BODY_XSMALL_BOLD;

    /**
     * Map a [TypographyEnum] to a [Typography].
     * [TypographyEnum] will be used by customer in xml or programmatically when creating an object.
     * We map it to the internal [Typography] object that we used in all our components.
     * @param context context is needed to retrieve a typography
     * return the mapped typography.
     */
    fun toTypography(context: Context): Typography {
        return when (this) {
            H1 -> Typography.H1(context)
            H2 -> Typography.H2(context)
            H3 -> Typography.H3(context)
            H4 -> Typography.H4(context)
            H5 -> Typography.H5(context)
            H6 -> Typography.H6(context)
            LINKS_LARGE -> Typography.LinksLarge(context)
            LINKS -> Typography.Links(context)
            LINKS_SMALL -> Typography.LinksSmall(context)
            BODY_LARGE -> Typography.BodyLarge(context)
            BODY -> Typography.Body(context)
            BODY_SMALL -> Typography.BodySmall(context)
            BODY_BOLD_LARGE -> Typography.BodyBoldLarge(context)
            BODY_BOLD -> Typography.BodyBold(context)
            BODY_BOLD_SMALL -> Typography.BodyBoldSmall(context)
            BODY_XSMALL -> Typography.BodyXSmall(context)
            BODY_XSMALL_BOLD -> Typography.BodyXSmallBold(context)
        }
    }
}