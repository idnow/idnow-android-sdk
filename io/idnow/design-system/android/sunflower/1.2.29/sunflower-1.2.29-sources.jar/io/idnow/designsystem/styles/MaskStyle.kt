package io.idnow.designsystem.styles

import androidx.annotation.Dimension

object MaskStyle {
    /**
     * Default progress duration
     */
    val progressDuration = 6000

    /**
     * Default bounce duration
     */
    val bounceDuration = 1000L

    /**
     * Bounce power
     */
    val bouncePower = 1.07f

    /**
     * Corner width (For Rect path)
     */
    @Dimension(unit = Dimension.DP)
    val cornerWidth = 48

    /**
     * Cubic Corner width (For Rect path)
     */
    @Dimension(unit = Dimension.DP)
    val cubicCornerWidth = 8

    /**
     * Stroke width
     */
    @Dimension(unit = Dimension.DP)
    val strokeWidth = 4
}