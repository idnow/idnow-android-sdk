package io.idnow.designsystem.xml_components.app_components.mask

import io.idnow.designsystem.tokens.Tokens

/**
 * Changing the status of the mask will update its color.
 */
enum class IDnowMaskStatus {
    ACTIVE,
    PROCESSING,
    SUCCESS,
    ERROR;

    /**
     * Retrieve the token associated to this enum.
     * return @ColorInt
     */
    fun color(): Int {
        return when(this) {
            ACTIVE -> Tokens.active
            PROCESSING -> Tokens.processing
            SUCCESS -> Tokens.success
            ERROR -> Tokens.error
        }
    }
}