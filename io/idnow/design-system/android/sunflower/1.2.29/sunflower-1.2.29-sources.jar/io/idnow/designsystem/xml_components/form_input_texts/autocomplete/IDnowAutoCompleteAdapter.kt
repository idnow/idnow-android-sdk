package io.idnow.designsystem.xml_components.form_input_texts.autocomplete

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Filter
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowContainerItemBinding
import io.idnow.designsystem.styles.FormInputsStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.setTypography
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowItem


internal class IDnowAutoCompleteAdapter(
    private val context: Context,
    val itemList: ArrayList<IDnowItem> = arrayListOf(),
    var autoCompleteFilterType: IDnowAutoCompleteTextView.AutoCompleteFilterType,
) : ArrayAdapter<IDnowItem>(context, 0, itemList) {

    /** Keep original list */
    private val originalList: ArrayList<IDnowItem> = arrayListOf()

    private val filter = object : Filter() {

        override fun convertResultToString(resultValue: Any?): CharSequence {
            return (resultValue as? IDnowItem).getContentText()
        }

        override fun performFiltering(query: CharSequence?): FilterResults {
            /** Update item list based on local filtering */
            val queryInput = query?.toString()?.lowercase()?.trim() ?: ""
            val results = if (queryInput.isEmpty()) {
                originalList.toList() //if no input revert to original list
            } else {
                originalList.toList().filter {
                    when(autoCompleteFilterType) {
                        IDnowAutoCompleteTextView.AutoCompleteFilterType.STARTS_WITH -> it.getContentText().lowercase().trim().startsWith(queryInput)
                        IDnowAutoCompleteTextView.AutoCompleteFilterType.CONTAINS -> it.getContentText().lowercase().trim().contains(queryInput)
                    }
                }
            }
            return FilterResults().apply {
                values = results
                count = results.size
            }
        }

        override fun publishResults(query: CharSequence?, results: FilterResults?) {
            with(itemList) {
                clear()
                addAll(results?.values as? List<IDnowItem> ?: emptyList())
                notifyDataSetChanged()
            }
        }
    }

    fun onDatasetUpdated(newItemList: List<IDnowItem>) {
        with(itemList)  {
            clear()
            addAll(newItemList)
        }
        with(originalList) {
            clear()
            addAll(itemList)
        }
        notifyDataSetChanged()
    }

    override fun getFilter(): Filter = filter

    override fun getCount(): Int = itemList.size

    override fun getItem(position: Int): IDnowItem = itemList[position]

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding: IdnowContainerItemBinding
        var row = convertView
        if (row == null) {
            val layoutInflater = LayoutInflater.from(context)
            binding = IdnowContainerItemBinding.inflate(layoutInflater, parent, false)
            row = binding.root
        } else {
            binding = IdnowContainerItemBinding.bind(row)
        }
        updateItem(itemList[position], binding)
        return row
    }

    /**
     * Update item content visibility, values and constraint (with token)
     * @param item the item to use to draw the cell
     * @param binding the view to update
     */
    private fun updateItem(item: IDnowItem, binding: IdnowContainerItemBinding) {
        item.icon?.let {
            binding.idnowItemIcon.apply {
                val resIconSize = R.dimen.idnow_item_size
                val iconSize = resources.getDimension(resIconSize).toInt()
                layoutParams.applyMargin(context = context, start = Tokens.spacingMd, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
                layoutParams.width = iconSize
                layoutParams.height = iconSize
                setImageResource(it)
                isVisible = true
            }
        }
        item.content?.let {
            binding.idnowItemText.apply {
                layoutParams.applyMargin(context = context, start = Tokens.spacingMd, bottom = Tokens.spacingSm, top = Tokens.spacingSm)
                setText(it)
                val font = FormInputsStyle.fontItem(context)
                setTypography(font)
                setTextColor(FormInputsStyle.popupTextColor)
                isVisible = true
            }
        }
    }

    private fun IDnowItem?.getContentText(): String {
        return this?.content?.toString() ?: ""
    }
}
