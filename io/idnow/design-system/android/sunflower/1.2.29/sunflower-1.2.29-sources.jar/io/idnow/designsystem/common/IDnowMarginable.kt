package io.idnow.designsystem.common

/**
 * All views that implement [IDnowMarginable] can only set their margins through the [margins] parameter.
 */
interface IDnowMarginable {
    /** Resets the layout params to update in real time the component. It allows to set the margin in the code and not only in xml. */
    var margins: SpacingQuad
}