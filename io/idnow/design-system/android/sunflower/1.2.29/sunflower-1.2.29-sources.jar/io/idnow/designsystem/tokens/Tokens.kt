package io.idnow.designsystem.tokens

import androidx.annotation.ColorInt
import io.idnow.designsystem.api.IDnowDesignSystem

/**
 * Expose the tokens classes so a client app cas still use them for every component/margin which is not part of the design system.
 */
object Tokens {
    /** color/text token */
    val heading get() = withLight(grey().grey800, grey().grey200)
    val body get() = withLight(grey().grey600, grey().grey300)
    val link get() = withLight(brand().secondary, brand().secondaryVariant)
    val linkVisited get() = withLight(grey().grey600, grey().grey400)
    val inputText get() = withLight(grey().grey800, grey().grey200)

    /** color/graphic token */
    val main get() = withLight(grey().grey500, grey().grey200)
    val accent get() = withLight(brand().primary, brand().primaryVariant)
    val accentVariant get() = withLight(brand().primaryVariant, brand().primary)
    val background get() = withLight(grey().grey100, grey().grey900)
    val overlay get() = withLight(grey().grey100, grey().grey100)
    val pattern get() = withLight(brand().secondary, brand().secondaryVariant)

    /** color/functional token */
    val error get() = withLight(brand().error, brand().error)
    val processing get() = withLight(brand().processing, brand().processing)
    val success get() = withLight(brand().success, brand().success)
    val active get() = withLight(brand().active, brand().active)

    /** color/button token */
    val primaryBackground get() = withLight(brand().primary, brand().primaryVariant)
    val primaryText get() = withLight(grey().grey100, grey().grey900)
    val secondaryActiveBackground get() = withLight(grey().grey100, grey().grey900)
    val secondaryActiveStroke get() = withLight(grey().grey200, grey().grey600)
    val secondaryActiveText get() = withLight(brand().secondary, brand().secondaryVariant)
    val recording = 0xFFFF3D2F.toInt()

    /** color/container token */
    val backgroundPrimary get() = withLight(grey().grey100, grey().grey900)
    val backgroundSecondary get() = withLight(grey().grey200, grey().grey800)
    val backgroundTertiary get() = withLight(grey().grey300, grey().grey600)
    val backgroundDarker get() = withLight(grey().grey800, grey().grey200)
    val borderPrimary get() = withLight(grey().grey300, grey().grey600)
    val borderSecondary get() = withLight(grey().grey400, grey().grey500)
    val borderTertiary get() = withLight(grey().grey500, grey().grey400)

    /** spacing token */
    val spacingXs get() = spacing().spacing0_5
    val spacingSm get() = spacing().spacing1
    val spacingMd get() = spacing().spacing2
    val spacingLg get() = spacing().spacing3
    val spacingXl get() = spacing().spacing4
    val spacing2xl get() = spacing().spacing5
    val spacing3xl get() = spacing().spacing6

    /** radius token */
    val radiusSm get() = radius().radius1
    val radiusMd get() = radius().radius2
    val radiusLg get() = radius().radius3
    val radiusFull get() = radius().radius4

    /** Factorize the switch between light and dark color */
    @ColorInt
    private fun withLight(light: Int, dark: Int) : Int = if(IDnowDesignSystem.isLightMode) light else dark

    /** Simplify the way of retrieving brand colors */
    private fun brand() = IDnowDesignSystem.primitives.colors.brand

    /** Simplify the way of retrieving grey colors */
    internal fun grey() = IDnowDesignSystem.primitives.colors.grey

    /** Simplify the way of retrieving spacing values */
    private fun spacing() = IDnowDesignSystem.primitives.spacing

    /** Simplify the way of retrieving radius values */
    private fun radius() = IDnowDesignSystem.primitives.radius
}