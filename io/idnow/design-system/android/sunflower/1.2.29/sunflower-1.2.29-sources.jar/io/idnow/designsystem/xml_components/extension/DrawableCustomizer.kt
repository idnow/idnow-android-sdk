package io.idnow.designsystem.xml_components.extension

import android.content.res.ColorStateList
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.DrawableContainer
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.graphics.drawable.VectorDrawable
import android.os.Build
import androidx.annotation.ColorInt

@DslMarker
@Target(AnnotationTarget.CLASS, AnnotationTarget.TYPE, AnnotationTarget.FUNCTION)
internal annotation class DrawableCustomizerDsl

@DrawableCustomizerDsl
internal sealed interface DrawableSelector {
    fun item(index: Int, bounds: Rect? = null, customize: ItemCustomizer.() -> Unit)
}

@DrawableCustomizerDsl
internal class ItemCustomizer {
    data class CornerRadius(
        val topLeft: Float? = null,
        val topRight: Float? = null,
        val bottomLeft: Float? = null,
        val bottomRight: Float? = null,
    ) {
        constructor(radius: Float) : this(radius, radius, radius, radius)

        fun toRadii() = floatArrayOf(
            topLeft ?: 0f, topLeft ?: 0f,
            topRight ?: 0f, topRight ?: 0f,
            bottomLeft ?: 0f, bottomLeft ?: 0f,
            bottomRight ?: 0f, bottomRight ?: 0f,
        )

        @DrawableCustomizerDsl
        class Builder {
            var topLeft: Float? = null
            var topRight: Float? = null
            var bottomLeft: Float? = null
            var bottomRight: Float? = null

            fun toCornerRadius() = CornerRadius(
                topLeft = topLeft,
                topRight = topRight,
                bottomLeft = bottomLeft,
                bottomRight = bottomRight,
            )
        }
    }

    data class Stroke(@field:ColorInt val color: Int, val width: Int)

    var solidColor: Int? = null
    var stroke: Stroke? = null
    var cornerRadius: CornerRadius? = null
    var solidColorStateList: ColorStateList? = null

    fun applyCustomization(drawable: Drawable, bounds: Rect? = null) {
        when (drawable) {
            is GradientDrawable -> drawable.customize(bounds)
            is VectorDrawable -> drawable.customize()
        }
    }

    private fun GradientDrawable.customize(bounds: Rect?) {
        this@ItemCustomizer.solidColor?.let { setColor(it) }
        this@ItemCustomizer.solidColorStateList?.let { color = it }
        this@ItemCustomizer.stroke?.let { setStroke(it.width, it.color) }
        this@ItemCustomizer.cornerRadius?.let { cornerRadii = it.toRadii() }
        bounds?.let { setSize(it.width(), it.height()) }
    }

    private fun VectorDrawable.customize() {
        this@ItemCustomizer.solidColor?.let { setTint(it) }
        this@ItemCustomizer.solidColorStateList?.let { setTintList(it) }
    }
}

// --- Drawable Selectors --- //

@DrawableCustomizerDsl
internal class StateListDrawableCustomizer(
    private val drawable: StateListDrawable,
) : DrawableSelector {

    fun layer(index: Int, customize: LayerDrawableCustomizer.() -> Unit) {
        (drawable.getChildAt(index) as? LayerDrawable)?.let { layer -> LayerDrawableCustomizer(layer).apply(customize) }
    }

    override fun item(index: Int, bounds: Rect?, customize: ItemCustomizer.() -> Unit) {
        drawable.getChildAt(index)?.let { ItemCustomizer().apply(customize).applyCustomization(it, bounds) }
    }

    private fun StateListDrawable.getChildAt(index: Int) =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) getStateDrawable(index)
        else (constantState as? DrawableContainer.DrawableContainerState)?.children?.getOrNull(index)
}

@DrawableCustomizerDsl
internal class LayerDrawableCustomizer(private val parent: LayerDrawable) : DrawableSelector {
    override fun item(index: Int, bounds: Rect?, customize: ItemCustomizer.() -> Unit) {
        /** Some drawable such as [VectorDrawable] doesn't have an API to update their size dynamically, so we need to do it at the layers level. */
        bounds?.let { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) parent.setLayerSize(index, it.right, it.bottom) }
        ItemCustomizer().apply(customize).applyCustomization(parent.getDrawable(index), bounds)
    }
}

internal fun StateListDrawable.customize(block: StateListDrawableCustomizer.() -> Unit) = apply { StateListDrawableCustomizer(this).apply(block) }

// --- Utilities --- //

@DrawableCustomizerDsl
internal fun ItemCustomizer.stroke(@ColorInt color: Int, width: Int) {
    this.stroke = ItemCustomizer.Stroke(color, width)
}

@DrawableCustomizerDsl
internal fun ItemCustomizer.cornerRadius(radius: Float) {
    this.cornerRadius = ItemCustomizer.CornerRadius(radius)
}

@DrawableCustomizerDsl
internal fun ItemCustomizer.cornerRadius(builder: ItemCustomizer.CornerRadius.Builder.() -> Unit) {
    this.cornerRadius = ItemCustomizer.CornerRadius.Builder().apply(builder).toCornerRadius()
}