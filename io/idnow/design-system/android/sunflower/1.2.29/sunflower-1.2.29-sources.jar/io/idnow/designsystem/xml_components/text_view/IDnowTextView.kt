package io.idnow.designsystem.xml_components.text_view

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.text.Html
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.withStyledAttributes
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.LinkTypographyEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.common.TypographyEnum
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.handleUrlClicks
import io.idnow.designsystem.xml_components.extension.setTypography

class IDnowTextView: AppCompatTextView, IDnowMarginable {
    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** Typography of this text. Contains [Typeface] and text size. */
    var typography: TypographyEnum = TypographyEnum.BODY
        set(value) {
            field = value
            setTypography(field.toTypography(context))
            setAccessibilityHeading()
        }

    /** Assign a token to the text color. */
    var textColor: TextColorEnum = TextColorEnum.BODY
        set(value) {
            field = value
            setTextColor(field.color())
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        context.withStyledAttributes(attrs, R.styleable.IDnowTextView) {
            typography = TypographyEnum.entries[getInt(R.styleable.IDnowTextView_typography, TypographyEnum.BODY.ordinal)]
            textColor = TextColorEnum.entries[getInt(R.styleable.IDnowTextView_token_textColor, TextColorEnum.BODY.ordinal)]

            /** Handle the component margin. */
            val margin = getInt(R.styleable.IDnowTextView_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowTextView_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowTextView_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowTextView_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowTextView_token_endMargin, -1)
            margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        }
    }

    /**
     * Mandatory call if the string contains URI.
     * When a link is clicked the callback is called with the link as parameters.
     * @param linkTypography typography of the link. Default is normal size.
     * @param onClicked Called when a link is clicked, contains the link as String
     */
    fun handleUrlClicks(linkTypography: LinkTypographyEnum = LinkTypographyEnum.LINKS,
                        onClicked: ((String) -> Unit)? = null) {
        (this as TextView).handleUrlClicks(linkTypography.toTypography(context), onClicked)
    }

    /**
     * Parse a text containing some HTML to a Spanned object and set it as a text to be displayed.
     * It will also works if the string does have any HTML in it.
     * @param value the string containing the HTML.
     */
    @Suppress("DEPRECATION")
    fun setHtmlText(value: String) {
        text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(value)
        }
    }

    /**
     * Parse a text containing some HTML to a Spanned object and set it as a text to be displayed.
     * It will also works if the string does have any HTML in it.
     * @param resId the res is of the string containing the HTML.
     */
    @Suppress("DEPRECATION")
    fun setHtmlText(@StringRes resId:Int) {
        text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(context.resources.getText(resId) as String?, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(context.resources.getText(resId) as String?)
        }
    }

    /**
     * Parse a parameterized text containing some HTML to a Spanned object and set it as a text to be displayed.
     * It will also works if the string does have any HTML in it.
     * @param resId the res is of the string containing the HTML.
     * @param params the parameters to apply on the string res.
     */
    @Suppress("DEPRECATION")
    fun setHtmlText(@StringRes resId:Int, vararg params: String) {
        text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(context.resources.getString(resId, *params) as String?, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(context.resources.getString(resId, *params) as String?)
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    /** Set this text view as heading if needed. */
    private fun setAccessibilityHeading() {
        val heading = typography == TypographyEnum.H1
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            isAccessibilityHeading = heading
        } else {
            ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
                override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                    info.isHeading = heading
                    super.onInitializeAccessibilityNodeInfo(host, info)
                }
            })
        }
    }
}