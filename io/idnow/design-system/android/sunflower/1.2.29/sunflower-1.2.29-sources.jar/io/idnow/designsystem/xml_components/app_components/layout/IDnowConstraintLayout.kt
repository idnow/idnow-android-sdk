package io.idnow.designsystem.xml_components.app_components.layout

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.view.updatePadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.BackgroundColorEnum
import io.idnow.designsystem.databinding.IdnowConstraintLayoutBinding

/**
 * Automatically handles system bars and display cutouts insets using window insets listener, which allows consumers to handle insets before this component does.
 */
class IDnowConstraintLayout : ConstraintLayout {
    /** Inflate the layout into the view. */
    private var _binding: IdnowConstraintLayoutBinding? = null
    private val binding get() = _binding!!

    /** Assign a token to the background color. */
    var backgroundColor: BackgroundColorEnum = BackgroundColorEnum.PRIMARY
        set(value) {
            field = value
            binding.root.setBackgroundColor(field.color())
        }

    /** Show/hide the footer view. */
    var withFooter: Boolean = false
        set(value) {
            field = value
            binding.idnowFooter.isVisible = field
        }

    /** Show/hide the header view. */
    var withHeader: Boolean = false
        set(value) {
            field = value
            binding.idnowHeader.isVisible = field
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        _binding = IdnowConstraintLayoutBinding.inflate(LayoutInflater.from(context), this)

        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowConstraintLayout)
        binding.idnowHeader.brand = customArray.getBoolean(R.styleable.IDnowConstraintLayout_brand, false)
        binding.idnowHeader.startIcon = customArray.getDrawable(R.styleable.IDnowConstraintLayout_startIcon)
        binding.idnowHeader.endIcon = customArray.getDrawable(R.styleable.IDnowConstraintLayout_endIcon)
        binding.idnowHeader.additionalEndIcon = customArray.getDrawable(R.styleable.IDnowConstraintLayout_additionalEndIcon)
        binding.idnowHeader.isVisible = customArray.getBoolean(R.styleable.IDnowConstraintLayout_header, false)
        binding.idnowFooter.isVisible = customArray.getBoolean(R.styleable.IDnowConstraintLayout_footer, false)
        backgroundColor = BackgroundColorEnum.entries[customArray.getInt(R.styleable.IDnowConstraintLayout_token_backgroundColor, BackgroundColorEnum.PRIMARY.ordinal)]
        customArray.recycle()

        ViewCompat.setOnApplyWindowInsetsListener(this) { v, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            // Apply the insets as a padding to apply the layout background color below system bars.
            v.updatePadding(
                left = insets.left,
                bottom = insets.bottom,
                right = insets.right,
                top = insets.top,
            )

            // Return CONSUMED if you don't want the window insets to keep passing
            // down to descendant views.
            WindowInsetsCompat.CONSUMED
        }
    }

    /** We override the addView to add all the views in the child constraint layout at the same level with the header and footer. */
    override fun addView(child: View?, params: ViewGroup.LayoutParams?) {
        if (_binding == null) return super.addView(child, params)

        // Only continue if the params are not null.
        val cParams = params as? LayoutParams ?: return
        // Update the params of the item attached to the top to attached them to the header instead.
        if(cParams.topToTop == LayoutParams.PARENT_ID) {
            cParams.topToTop = -1
            cParams.topToBottom = binding.idnowHeader.id
        }
        // Update the params of the item attached to the bottom to attached them to the footer instead.
        if(cParams.bottomToBottom == LayoutParams.PARENT_ID) {
            cParams.bottomToBottom = -1
            cParams.bottomToTop = binding.idnowFooter.id
        }
        super.addView(child, cParams)
    }

    /** Expose the header to add click action. */
    fun header() = binding.idnowHeader
}