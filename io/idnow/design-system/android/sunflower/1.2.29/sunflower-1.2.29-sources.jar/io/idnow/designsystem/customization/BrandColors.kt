package io.idnow.designsystem.customization

import androidx.annotation.ColorInt

data class BrandColors(
    val primary: Int,
    val primaryVariant: Int,
    val secondary: Int,
    val secondaryVariant: Int,
    val error: Int,
    val processing: Int,
    val success: Int,
    val active: Int
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            @ColorInt
            primary: Int? = null,
            @ColorInt
            primaryVariant: Int? = null,
            @ColorInt
            secondary: Int? = null,
            @ColorInt
            secondaryVariant: Int? = null,
            @ColorInt
            error: Int? = null,
            @ColorInt
            processing: Int? = null,
            @ColorInt
            success: Int? = null,
            @ColorInt
            active: Int? = null
        ) = BrandColors(
            primary = primary ?: DefaultPrimitives.primary,
            primaryVariant = primaryVariant ?: DefaultPrimitives.primaryVariant,
            secondary = secondary ?: DefaultPrimitives.secondary,
            secondaryVariant = secondaryVariant ?: DefaultPrimitives.secondaryVariant,
            error = error ?: DefaultPrimitives.error,
            processing = processing ?: DefaultPrimitives.processing,
            success = success ?: DefaultPrimitives.success,
            active = active ?: DefaultPrimitives.active
        )
    }
}
