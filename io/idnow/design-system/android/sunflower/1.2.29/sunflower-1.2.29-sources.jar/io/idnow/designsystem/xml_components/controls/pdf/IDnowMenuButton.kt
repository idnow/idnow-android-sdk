package io.idnow.designsystem.xml_components.controls.pdf

import android.content.Context
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.core.content.withStyledAttributes
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.isGone
import androidx.core.view.updateLayoutParams
import androidx.core.view.updateMarginsRelative
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.TextColorEnum
import io.idnow.designsystem.databinding.IdnowMenuButtonBinding
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.cornerRadius
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.extractMargins
import io.idnow.designsystem.xml_components.extension.marginable
import io.idnow.designsystem.xml_components.extension.toDp
import io.idnow.designsystem.xml_components.extension.updatePadding

class IDnowMenuButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr), IDnowMarginable {
    private val binding = IdnowMenuButtonBinding.inflate(LayoutInflater.from(context), this)

    private val contentPadding = SpacingEnum.SPACING_SM

    override var margins: SpacingQuad by marginable()

    var active: Boolean = false
        set(value) {
            field = value
            updateContent()
            refreshDrawableState()
        }

    var text: CharSequence
        get() = binding.idnMenuButtonLabel.text
        set(value) {
            binding.idnMenuButtonLabel.text = value
        }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowMenuButton, defStyleAttr) {
            margins = extractMargins(R.styleable.IDnowMenuButton)

            text = getString(R.styleable.IDnowMenuButton_android_text) ?: ""
            getDrawable(R.styleable.IDnowMenuButton_android_drawableStart)?.let {
                binding.idnMenuButtonIcon.setImageDrawable(it)
            } ?: run {
                binding.idnMenuButtonIcon.isGone = true
            }

            active = getBoolean(R.styleable.IDnowMenuButton_active, false)
        }

        isClickable = true
        isFocusable = true

        minHeight = resources.getDimension(R.dimen.idnow_icon_size).toInt() + (contentPadding.value.toDp(context) * 2)
        updatePadding(SpacingQuad(all = contentPadding))
        binding.idnMenuButtonIcon.updateLayoutParams<MarginLayoutParams> {
            updateMarginsRelative(end = contentPadding.value.toDp(context))
        }

        val backgroundDrawable = ResourcesCompat.getDrawable(resources, R.drawable.idnow_menu_button_background, null)
        background = (backgroundDrawable?.mutate() as? StateListDrawable)?.customize {
            val radius = Tokens.radiusSm.toDp(context).toFloat()

            // State - Pressed
            layer(index = 0) {
                item(index = 0) {
                    solidColor = Tokens.primaryBackground
                    cornerRadius {
                        topLeft = radius
                        topRight = radius
                    }
                }
                item(index = 1) {
                    solidColor = Tokens.backgroundSecondary
                    cornerRadius {
                        topLeft = radius
                        topRight = radius
                    }
                }
            }

            // State - Active
            layer(index = 1) {
                item(index = 0) { solidColor = Tokens.primaryBackground }
                item(index = 1) { solidColor = Tokens.background }
            }
        }

        ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.className = Button::class.java.name
                info.isClickable = true
            }
        })
    }

    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        return if (active) {
            val drawableState = super.onCreateDrawableState(extraSpace + 1)
            mergeDrawableStates(drawableState, intArrayOf(android.R.attr.state_activated))
            drawableState
        } else {
            super.onCreateDrawableState(extraSpace)
        }
    }

    private fun updateContent() {
        binding.idnMenuButtonLabel.textColor = if (active) TextColorEnum.HEADING else TextColorEnum.BODY
        binding.idnMenuButtonIcon.setColorFilter(if (active) Tokens.heading else Tokens.body)
    }
}