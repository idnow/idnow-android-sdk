package io.idnow.designsystem.xml_components.form_input_texts.text_field

import android.content.Context
import android.graphics.drawable.Drawable
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.util.AttributeSet
import android.widget.EditText
import androidx.core.content.res.ResourcesCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowEdittextBinding
import io.idnow.designsystem.xml_components.form_input_texts.common.IDnowBaseTextField


class IDnowTextField : IDnowBaseTextField {
    /** Stub binding, replace the view stub with an edit text. */
    private val textBinding: IdnowEdittextBinding = IdnowEdittextBinding.bind(binding.idnField.inflate())

    /** Direct access to the underlying inflated [EditText] */
    override val editText: EditText = textBinding.root

    /** Display or hide the leading icon. */
    var leadingIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(binding.idnContLeadingIcon, value)
        }

    /** Display or hide the trailing icon. */
    var trailingIcon: Drawable? = null
        set(value) {
            field = value
            displayViewWithIcon(binding.idnContTrailingIcon, value)
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowTextField)

        val inputType = customArray.getInt(R.styleable.IDnowTextField_android_inputType, InputType.TYPE_CLASS_TEXT)
        val passwordToggleEnabled = customArray.getBoolean(R.styleable.IDnowTextField_passwordToggleEnabled, false)
        leadingIcon = customArray.getDrawable(R.styleable.IDnowTextField_leadingIcon)
        isEnabled = customArray.getBoolean(R.styleable.IDnowTextField_android_enabled, true)

        customArray.recycle()
        initialize(passwordToggleEnabled, inputType)
    }

    private fun initialize(passwordToggleEnabled: Boolean, inputType: Int) {
        /** Set the input type to the edit text. */
        editText.inputType = inputType

        /** Add a trailing icon to show/hide the password is necessary */
        if (passwordToggleEnabled) {
            trailingIcon = ResourcesCompat.getDrawable(resources, R.drawable.sunflower_ic_eye_on, null)
            binding.idnContTrailingIcon.apply {
                togglePassword(false)
                setOnClickListener {
                    isSelected = !isSelected
                    togglePassword(isSelected)
                }
            }
        }

        /** Set a clear action */
        binding.idnContClear.apply {
            contentDescription = context.getString(R.string.sunflower_clear_content_description)
            setOnClickListener {
                editText.text.clear()
            }
        }

        /** Set content description if needed */
        setContentDescription()
    }

    /** Change the transformation method of the text to show/hide the text */
    private fun togglePassword(isSelected: Boolean) {
        with(editText) {
            // Save cursor position
            val selectionStart = selectionStart
            val selectionEnd = selectionEnd
            // Show/Hide the text content
            transformationMethod = if (isSelected) {
                null
            } else {
                PasswordTransformationMethod()
            }
            // Restore the cursor position to have a better UX.
            setSelection(selectionStart, selectionEnd)
            // Update accessibility
            setPasswordContentDescription(isSelected)
        }
    }

    /** Update password content description for Accessibility */
    private fun setPasswordContentDescription(isSelected: Boolean) {
        val (contentDescription, announce) = if (isSelected) {
            context.getString(R.string.sunflower_hide_password_content_description) to context.getString(R.string.sunflower_password_visible)
        } else {
            context.getString(R.string.sunflower_show_password_content_description) to context.getString(R.string.sunflower_password_hidden)
        }
        binding.idnContTrailingIcon.announceForAccessibility(announce)
        binding.idnContTrailingIcon.contentDescription = contentDescription
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        editText.isEnabled = enabled
    }
}