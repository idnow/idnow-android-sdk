package io.idnow.designsystem.xml_components.buttons

enum class ButtonSize {
    SMALL,
    MEDIUM,
    LARGE;
}