package io.idnow.designsystem.xml_components.app_components.mask

/**
 * Choose the main shape of your mask.
 */
enum class IDnowMaskShape {
    RECT, OVAL
}