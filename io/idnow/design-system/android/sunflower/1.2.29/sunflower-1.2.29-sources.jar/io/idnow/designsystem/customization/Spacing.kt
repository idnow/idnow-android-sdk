package io.idnow.designsystem.customization

import androidx.annotation.Dimension

data class Spacing(
    @Dimension(unit = Dimension.DP)
    val spacing0_5: Int,
    val spacing1: Int,
    val spacing2: Int,
    val spacing3: Int,
    val spacing4: Int,
    val spacing5: Int,
    val spacing6: Int
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            @Dimension(unit = Dimension.DP)
            spacing0_5: Int? = null,
            @Dimension(unit = Dimension.DP)
            spacing1: Int? = null,
            @Dimension(unit = Dimension.DP)
            spacing2: Int? = null,
            @Dimension(unit = Dimension.DP)
            spacing3: Int? = null,
            @Dimension(unit = Dimension.DP)
            spacing4: Int? = null,
            @Dimension(unit = Dimension.DP)
            spacing5: Int? = null,
            @Dimension(unit = Dimension.DP)
            spacing6: Int? = null
        ) = Spacing(
            spacing0_5 = spacing0_5 ?:DefaultPrimitives.spacing0_5,
            spacing1 = spacing1 ?: DefaultPrimitives.spacing1,
            spacing2 = spacing2 ?: DefaultPrimitives.spacing2,
            spacing3 = spacing3 ?: DefaultPrimitives.spacing3,
            spacing4 = spacing4 ?: DefaultPrimitives.spacing4,
            spacing5 = spacing5 ?: DefaultPrimitives.spacing5,
            spacing6 = spacing6 ?: DefaultPrimitives.spacing6
        )
    }
}
