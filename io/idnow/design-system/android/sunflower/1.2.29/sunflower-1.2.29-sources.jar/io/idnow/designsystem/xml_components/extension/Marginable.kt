package io.idnow.designsystem.xml_components.extension

import android.view.View
import androidx.core.view.doOnAttach
import androidx.core.view.updateLayoutParams
import io.idnow.designsystem.common.SpacingQuad
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/**
 * Simple delegate to apply [SpacingQuad] as margins in a [View].
 */
private class MarginableDelegate(
    private var margins: SpacingQuad = SpacingQuad(),
) : ReadWriteProperty<View, SpacingQuad> {
    override fun getValue(thisRef: View, property: KProperty<*>): SpacingQuad = margins

    override fun setValue(thisRef: View, property: KProperty<*>, value: SpacingQuad) {
        margins = value
        with(thisRef) {
            val runnable = Runnable { updateLayoutParams { applyMargin(context, value) } }

            if (thisRef.isAttachedToWindow) post(runnable)
            else doOnAttach { runnable.run() }
        }
    }
}

/** Delegate for [io.idnow.designsystem.common.IDnowMarginable] margins handling. */
internal fun marginable(): ReadWriteProperty<View, SpacingQuad> = MarginableDelegate()
