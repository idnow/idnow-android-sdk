package io.idnow.designsystem.xml_components.app_components.mask.path

import android.graphics.Path
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad

/**
 * Create a path for a classic oval.
 */
internal class OvalPath : PathToDisplay {
    override fun getPathToDraw(path: Path, quad: IDnowMaskQuad) {
        val topLeft = quad.leftTop
        val bottomRight = quad.rightBottom

        path.apply {
            fillType = Path.FillType.EVEN_ODD
            addOval(topLeft.x.toFloat(), topLeft.y.toFloat(), bottomRight.x.toFloat(), bottomRight.y.toFloat(), Path.Direction.CW)
        }
    }
}