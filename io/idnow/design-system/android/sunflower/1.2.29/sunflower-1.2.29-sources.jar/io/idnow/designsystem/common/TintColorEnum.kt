package io.idnow.designsystem.common

import io.idnow.designsystem.tokens.Tokens

/** List tint color tokens */
enum class TintColorEnum {
    MAIN,
    ACCENT,
    ACCENT_VARIANT,
    BACKGROUND,
    OVERLAY,
    PATTERN,
    ERROR,
    PROCESSING,
    SUCCESS,
    ACTIVE,
    RECORDING;

    /**
     * Retrieve the color token associated to this enum.
     * return @ColorInt
     */
    fun color(): Int {
        return when(this) {
            MAIN -> Tokens.main
            ACCENT -> Tokens.accent
            ACCENT_VARIANT -> Tokens.accentVariant
            BACKGROUND -> Tokens.background
            OVERLAY -> Tokens.overlay
            PATTERN -> Tokens.pattern
            ERROR -> Tokens.error
            PROCESSING -> Tokens.processing
            SUCCESS -> Tokens.success
            ACTIVE -> Tokens.active
            RECORDING -> Tokens.recording
        }
    }
}