package io.idnow.designsystem.xml_components.tutorial_step

import io.idnow.designsystem.styles.TutorialStepStyle

enum class TutorialStepIndicator(internal val style: TutorialStepStyle) {
    LARGE(TutorialStepStyle.Large),
    INLINE(TutorialStepStyle.Inline)
}