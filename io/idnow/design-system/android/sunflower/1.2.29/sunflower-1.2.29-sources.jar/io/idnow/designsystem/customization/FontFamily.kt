package io.idnow.designsystem.customization

import android.graphics.Typeface

data class FontFamily(
    val heading: Map<Int, Typeface>? = null,
    val content: Map<Int, Typeface>? = null
)
