package io.idnow.designsystem.xml_components.form_input_texts.common

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * Item to use for the [IDnowFlagAdapter]
 * Contains an icon and string.
 */
data class IDnowCountryFlagItem(
    @DrawableRes override val icon: Int,
    override val content: String,
    val prefix: String,
): IDnowItemData
