package io.idnow.designsystem.xml_components.extension

import android.os.Build
import android.text.Html
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.URLSpan
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.core.view.ViewCompat
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography

/**
 * Searches for all URLSpans in current text replaces them with our own ClickableSpans
 * forwards clicks to provided function.
 * Automatically update the link color to [Tokens.linkVisited] when an URL is clicked.
 */
internal fun TextView.handleUrlClicks(typography: Typography, onClicked: ((String) -> Unit)? = null, lambdaAccessibilityAction: ((String, ClickableSpan) -> Unit)? = null) {
    // Creates span builder and replaces current text with it.
    text = SpannableStringBuilder.valueOf(text).apply {
        // Searches for all URL spans and replace all spans with our own clickable spans.
        getSpans(0, length, URLSpan::class.java).forEachIndexed { index, it ->
            // Add a new clickable span at the same position
            val span = object : ClickableSpan() {
                var linkColor = Tokens.link

                override fun onClick(widget: View) {
                    linkColor = Tokens.linkVisited
                    onClicked?.invoke(it.url)
                }

                override fun updateDrawState(ds: TextPaint) {
                    ds.color = linkColor
                    ds.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, typography.size + 0.5f, context.resources.displayMetrics)
                    ds.typeface = typography.typeface
                    ds.isUnderlineText = typography.isUnderlined
                }
            }
            setSpan(span, getSpanStart(it), getSpanEnd(it), Spanned.SPAN_INCLUSIVE_EXCLUSIVE)
            // Add the Span to Accessibility Actions.
            lambdaAccessibilityAction?.invoke(text.subSequence(getSpanStart(it), getSpanEnd(it)).toString(), span)
            // Removes the old URLSpan.
            removeSpan(it)
        }
    }

    // Makes sure movement method is set.
    movementMethod = LinkMovementMethod.getInstance()
}

/**
 * Add action to open links
 * Must be called by the HandleUrl which create the ClickableSpan.
 */
internal fun addActionForLinks(container: View, widget: View, actionName: String, clickableSpan: ClickableSpan) {
    ViewCompat.addAccessibilityAction(container, actionName) { _, _ ->
        clickableSpan.onClick(widget)
        true
    }
}

@Suppress("DEPRECATION")
internal fun TextView.setHtmlText(value: String) {
    text = value.toHtmlText()
}

@Suppress("DEPRECATION")
internal fun String.toHtmlText(): Spanned {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        Html.fromHtml(this, Html.FROM_HTML_MODE_LEGACY)
    } else {
        Html.fromHtml(this)
    }
}