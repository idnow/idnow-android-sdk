package io.idnow.designsystem.customization

import androidx.annotation.Dimension
import io.idnow.designsystem.R

internal object DefaultPrimitives {
    /** Brand colors default values */
    const val primary: Int = 0xFFE75C33.toInt()
    const val primaryVariant: Int = 0xFFFFA886.toInt()
    const val secondary: Int = 0xFF344D81.toInt()
    const val secondaryVariant: Int = 0xFFA1B3D9.toInt()
    const val error: Int = 0xFFD93B3B.toInt()
    const val processing: Int = 0xFFF7B53E.toInt()
    const val success: Int = 0xFF4EB3B2.toInt()
    const val active: Int = 0xFF47A7FF.toInt()

    /** Grey colors default values */
    const val grey100: Int = 0xFFFFFFFF.toInt()
    const val grey200: Int = 0xFFEEEEEE.toInt()
    const val grey300: Int = 0xFFDEDEDE.toInt()
    const val grey400: Int = 0xFFB6B6B6.toInt()
    const val grey500: Int = 0xFF888888.toInt()
    const val grey600: Int = 0xFF595959.toInt()
    const val grey800: Int = 0xFF333333.toInt()
    const val grey900: Int = 0xFF141620.toInt()

    /** Radius default values */
    @Dimension(unit = Dimension.DP)
    const val radius1 = 4
    @Dimension(unit = Dimension.DP)
    const val radius2 = 8
    @Dimension(unit = Dimension.DP)
    const val radius3 = 16
    @Dimension(unit = Dimension.DP)
    const val radius4 = 400

    /** Spacing default values */
    @Dimension(unit = Dimension.DP)
    const val spacing0_5 = 4
    @Dimension(unit = Dimension.DP)
    const val spacing1 = 8
    @Dimension(unit = Dimension.DP)
    const val spacing2 = 16
    @Dimension(unit = Dimension.DP)
    const val spacing3 = 24
    @Dimension(unit = Dimension.DP)
    const val spacing4 = 32
    @Dimension(unit = Dimension.DP)
    const val spacing5 = 40
    @Dimension(unit = Dimension.DP)
    const val spacing6 = 48

    /** Font weight default values */
    const val regular = 400
    const val medium = 500

    /** Font family default values */
    val heading = mapOf(Pair(regular, R.font.idnow_sans_regular), Pair(medium, R.font.idnow_sans_medium))
    val content = mapOf(Pair(regular, R.font.idnow_sans_regular), Pair(medium, R.font.idnow_sans_medium))

    /** Font size default values */
    const val remMultiplier = 16
    @Dimension(unit = Dimension.SP)
    const val fontSize00 = 0.875f
    @Dimension(unit = Dimension.SP)
    const val fontSize0 = 1f
    @Dimension(unit = Dimension.SP)
    const val fontSize1 = 1.125f
    @Dimension(unit = Dimension.SP)
    const val fontSize2 = 1.266f
    @Dimension(unit = Dimension.SP)
    const val fontSize3 = 1.424f
    @Dimension(unit = Dimension.SP)
    const val fontSize4 = 1.602f
    @Dimension(unit = Dimension.SP)
    const val fontSize5 = 1.802f
    @Dimension(unit = Dimension.SP)
    const val fontSize6 = 2.027f

    /** Line height */
    const val lineHeightHeading = 1.1f
    const val lineHeightContent = 1.2f
}