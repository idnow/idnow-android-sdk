package io.idnow.designsystem.customization

data class Colors(
    val brand: BrandColors,
    val grey: GreyColors
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            brand: BrandColors? = null,
            grey: GreyColors? = null
        ) = Colors(
            brand = brand ?: BrandColors(),
            grey = grey ?: GreyColors()
        )
    }
}
