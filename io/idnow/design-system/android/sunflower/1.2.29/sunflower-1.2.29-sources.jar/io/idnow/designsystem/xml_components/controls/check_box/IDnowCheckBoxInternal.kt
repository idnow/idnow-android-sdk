package io.idnow.designsystem.xml_components.controls.check_box

import android.content.Context
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatCheckBox
import androidx.core.content.res.ResourcesCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.ControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp


internal class IDnowCheckBoxInternal : AppCompatCheckBox {
    /** The custom indeterminate state reference */
    private val stateIndeterminate = intArrayOf(R.attr.state_indeterminate)

    /** Current state of the checkbox */
    var checkState: CheckState = CheckState.UNCHECKED
        set(value) {
            field = value
            refreshDrawableState()
        }

    /** Check change listener */
    var onCheckChangeListener: OnCheckChangeListener? = null

    /** Internal usage only ! Notify a control of a change. */
    var onInternalChange: (() -> Unit)? = null

    /** Size of the check box */
    var size: Size = Size.NORMAL
        set(value) {
            field = value
            setupDrawable()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    private fun setupDrawable() {
        val drawable = ResourcesCompat.getDrawable(context.resources, R.drawable.idnow_checkbox_button, null)
        /** Customization of checked state */
        customizeChild(drawable, indexChild = 0)
        /** Customization of indeterminate state */
        customizeChild(drawable, indexChild = 1)
        /** Customization of unchecked state */
        customizeChild(drawable, indexChild = 2, multipleItem = false)
        buttonDrawable = drawable
    }

    private fun customizeChild(drawable: Drawable?, indexChild: Int, multipleItem: Boolean = true) {
        drawable ?: return
        with(ControlStyle) {
            val bounds = Rect(0, 0, controlSize(size).toDp(context), controlSize(size).toDp(context))
            (drawable as StateListDrawable).customize(
                solidColor = if(multipleItem) activeColor else null,
                strokeColor = if(multipleItem) null else strokeColor,
                strokeWidth = strokeWidth().toDp(context),
                cornerRadius = checkBoxRadius(size).toDp(context).toFloat(),
                multipleItem = multipleItem,
                indexChild = indexChild,
                innerChild = 0,
                bounds = bounds
            )
            if(multipleItem) {
                drawable.customize(solidColor = iconColor, multipleItem = true, indexChild = indexChild, innerChild = 1, bounds = bounds)
            }
        }
    }

    /**
     * Add the indeterminate state to the current state list if it has been set.
     */
    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        val drawableStates = super.onCreateDrawableState(extraSpace + 1)
        if(checkState == CheckState.INDETERMINATE) {
            mergeDrawableStates(drawableStates, stateIndeterminate)
        }
        return drawableStates
    }


    override fun isChecked(): Boolean = checkState == CheckState.CHECKED

    override fun toggle() {
        isChecked = !isChecked
    }

    override fun setChecked(checked: Boolean) {
        /** If the checkbox is disabled, check state can't be updated. */
        if(!isEnabled) return

        checkState = (if(checked) CheckState.CHECKED else CheckState.UNCHECKED)
        /** Notify internally */
        onInternalChange?.invoke()
        /** Notify of state changes. */
        onCheckChangeListener?.onCheckChange(checked)
        super.setChecked(checked)
        refreshDrawableState()
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ControlStyle.opacity(enabled)
    }
}