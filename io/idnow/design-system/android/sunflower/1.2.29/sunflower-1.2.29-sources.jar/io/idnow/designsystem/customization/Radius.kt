package io.idnow.designsystem.customization

import androidx.annotation.Dimension

data class Radius(
    val radius1: Int,
    val radius2: Int,
    val radius3: Int,
    val radius4: Int
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            @Dimension(unit = Dimension.DP)
            radius1: Int? = null,
            @Dimension(unit = Dimension.DP)
            radius2: Int? = null,
            @Dimension(unit = Dimension.DP)
            radius3: Int? = null,
            @Dimension(unit = Dimension.DP)
            radius4: Int? = null
        ) = Radius(
            radius1 = radius1 ?: DefaultPrimitives.radius1,
            radius2 = radius2 ?: DefaultPrimitives.radius2,
            radius3 = radius3 ?: DefaultPrimitives.radius3,
            radius4 = radius4 ?: DefaultPrimitives.radius4
        )
    }
}
