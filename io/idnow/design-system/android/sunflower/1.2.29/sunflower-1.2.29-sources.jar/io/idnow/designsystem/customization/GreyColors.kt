package io.idnow.designsystem.customization

import androidx.annotation.ColorInt

data class GreyColors(
    val grey100: Int,
    val grey200: Int,
    val grey300: Int,
    val grey400: Int,
    val grey500: Int,
    val grey600: Int,
    val grey800: Int,
    val grey900: Int
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            @ColorInt
            grey100: Int? = null,
            @ColorInt
            grey200: Int? = null,
            @ColorInt
            grey300: Int? = null,
            @ColorInt
            grey400: Int? = null,
            @ColorInt
            grey500: Int? = null,
            @ColorInt
            grey600: Int? = null,
            @ColorInt
            grey800: Int? = null,
            @ColorInt
            grey900: Int? = null
        ) = GreyColors (
            grey100 = grey100 ?: DefaultPrimitives.grey100,
            grey200 = grey200 ?: DefaultPrimitives.grey200,
            grey300 = grey300 ?: DefaultPrimitives.grey300,
            grey400 = grey400 ?: DefaultPrimitives.grey400,
            grey500 = grey500 ?: DefaultPrimitives.grey500,
            grey600 = grey600 ?: DefaultPrimitives.grey600,
            grey800 = grey800 ?: DefaultPrimitives.grey800,
            grey900 = grey900 ?: DefaultPrimitives.grey900
        )
    }
}
