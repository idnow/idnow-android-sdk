package io.idnow.designsystem.xml_components.controls.check_box

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.databinding.IdnowCheckBoxBinding
import io.idnow.designsystem.xml_components.controls.common.IDnowControls
import io.idnow.designsystem.xml_components.controls.common.Size

class IDnowCheckBox : IDnowControls {
    /** Stub binding, replace the view stub with a check box. */
    private val checkBoxBinding: IdnowCheckBoxBinding = IdnowCheckBoxBinding.bind(binding.idnField.inflate())
    private val checkBox = checkBoxBinding.root

    var size: CheckSize = CheckSize.NORMAL
        set(value) {
            val size = Size.valueOf(value.name)
            controlSize = size
            checkBox.size = size
            field = value
        }

    /** Return the id of the element that will be focused by accessibility. */
    val accessibilityId: Int
        get() = binding.idnContainer.id

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Android state restoration saves state keyed by view ID — since all internal checkboxes have no ID (View.NO_ID), they all share the same state slot.
        // Hence, why an id is mandatory for the internal checkbox for correct state restoration.
        checkBoxBinding.root.id = id
        // This avoids conflicts in state restoration, as only the internal component will be restoring its state.
        isSaveEnabled = false

        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowCheckBox)
        val stateIndeterminate = customArray.getBoolean(R.styleable.IDnowCheckBox_state_indeterminate, false)
        val isChecked = customArray.getBoolean(R.styleable.IDnowCheckBox_android_checked, false)
        val size = CheckSize.entries[customArray.getInt(R.styleable.IDnowCheckBox_checkSize, CheckSize.NORMAL.ordinal)]
        val isEnabled = customArray.getBoolean(R.styleable.IDnowCheckBox_android_enabled, true)
        customArray.recycle()
        initialize(stateIndeterminate, isChecked, isEnabled, size)
    }

    private fun initialize(stateIndeterminate: Boolean, isChecked: Boolean, isEnabled: Boolean, size: CheckSize) {
        this.size = size
        /** We initialize the controls here because we wait that all the variable retrieve from xml are transmit to the controls object before initializing it. */
        initializeControls()
        /** Is the component enable */
        this.isEnabled = isEnabled
        /** Remove error state on check changed */
        checkBox.onInternalChange = { stateError = false }
        /** Transmit parameters to the custom check box */
        checkBox.apply {
            checkState = when {
                stateIndeterminate -> CheckState.INDETERMINATE
                isChecked -> CheckState.CHECKED
                else -> CheckState.UNCHECKED
            }
        }
        /** Check the checkbox when the area and text are clicked */
        binding.idnContainer.setOnClickListener {
            checkBox.toggle()
        }

        /** Set content description for accessibility */
        setContentDescription()
    }

    /**
     * Mandatory call if the string contains URI.
     * When a link is clicked the callback is called with the link as parameters.
     * @param onClicked Called when a link is clicked, contains the link as String
     */
    override fun handleUrlClicks(onClicked: ((String) -> Unit)) {
        // Add a click listener on the text as the other one from the check view won't work on the text once we have change the URL click.
        binding.idnContent.setOnClickListener { checkBox.toggle() }
        super.handleUrlClicks(onClicked)
    }

    /**
     * Register a callback to be invoked when the checked state of this button
     * changes.
     *
     * @param onCheckChangeListener the callback to call on checked state change
     */
    @Suppress("Unused")
    fun setOnCheckedChangeListener(onCheckChangeListener: OnCheckChangeListener) {
        checkBox.onCheckChangeListener = onCheckChangeListener
    }

    /**
     * Register a callback to be invoked when the checked state of this button
     * changes.
     *
     * @param listener the callback to call on checked state change
     */
    fun setOnCheckedChangeListener(listener: (IDnowCheckBox, Boolean) -> Unit) {
        checkBox.onCheckChangeListener = object : OnCheckChangeListener {
            override fun onCheckChange(isChecked: Boolean) {
                listener(this@IDnowCheckBox, isChecked)
            }
        }
    }

    /**
     * Update the current check box with an indeterminate state
     * @param checkState new check box state
     */
    fun setCheckState(checkState: CheckState) {
        checkBox.checkState = checkState
        setContentDescription()
    }

    /** Is the check box checked */
    fun isChecked(): Boolean {
        return checkBox.isChecked
    }

    override fun getStubView(): View = checkBox

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        checkBox.isEnabled = isEnabled
        setContentDescription()
    }

    enum class CheckSize {
        SMALL, NORMAL, BIG
    }

    /** Set a custom description for accessibility. */
    override fun setContentDescription() {
        ViewCompat.setAccessibilityDelegate(binding.idnContainer, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.contentDescription = buildString {
                    append(accessibilityContentText())
                    append("${accessibilityClassName()} ")
                    append("${accessibilityStatus()} ")
                    if (!isEnabled) append(context.getString(R.string.sunflower_disabled))
                }
            }
        })
    }

    /** Retrieve the status of the checkbox for accessibility. */
    private fun accessibilityClassName(): String {
        return context.getString(R.string.sunflower_checkbox)
    }

    /** Retrieve the status of the checkbox for accessibility. */
    private fun accessibilityStatus(): String {
        return when (checkBox.checkState) {
            CheckState.CHECKED -> context.getString(R.string.sunflower_checked)
            CheckState.UNCHECKED -> context.getString(R.string.sunflower_not_checked)
            CheckState.INDETERMINATE -> context.getString(R.string.sunflower_indeterminate)
        }
    }
}