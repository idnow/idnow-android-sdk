package io.idnow.designsystem.xml_components.message

import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.common.Utils
import io.idnow.designsystem.databinding.IdnowMessageViewBinding
import io.idnow.designsystem.styles.MessageViewStyle
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp

class IDnowMessageView : ConstraintLayout, IDnowMarginable {
    /** Inflate the layout into the view. */
    private val binding = IdnowMessageViewBinding.inflate(LayoutInflater.from(context), this)

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    /** Show or hide the start icon */
    var startIcon: Drawable?
        get() = binding.idnowIcon.drawable
        set(value) {
            binding.idnowIcon.isVisible = value != null
            binding.idnowIcon.setImageDrawable(value)
        }

    /** Title of the message view. */
    var title: CharSequence = ""
        set(value) {
            field = value
            binding.idnowTitle.text = field
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr, R.style.IDnowMessageView) {
        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowMessageView)
        val margin = customArray.getInt(R.styleable.IDnowMessageView_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowMessageView_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowMessageView_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowMessageView_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowMessageView_token_endMargin, -1)
        margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        title = customArray.getString(R.styleable.IDnowMessageView_title) ?: ""
        startIcon = customArray.getDrawable(R.styleable.IDnowMessageView_startIcon)
        customArray.recycle()
        initialize()
    }

    /**
     * Update views with a token color.
     */
    private fun initialize() {
        with(MessageViewStyle) {
            binding.idnowTitle.setTextColor(foregroundColor)
            binding.idnowIcon.setColorFilter(foregroundColor)
            (binding.root.background as? GradientDrawable)?.customize(
                cornerRadius = cornerRadius.toDp(context).toFloat(),
                solidColor = Utils.adjustAlpha(solidColor, backgroundOpacity),
            )
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }
}