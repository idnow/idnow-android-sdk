package io.idnow.designsystem.styles

import io.idnow.designsystem.tokens.Tokens

internal object MessageViewStyle {
    /**
     * Color of the icon and text.
     */
    val foregroundColor get() = Tokens.backgroundPrimary

    /**
     * Corner radius of the button.
     */
    val cornerRadius get() = Tokens.radiusMd

    /**
     * Container stroke color
     */
    val solidColor get() = Tokens.backgroundDarker

    /**
     * Background alpha color
     */
    const val backgroundOpacity: Float = 0.8f
}