package io.idnow.designsystem.styles

import android.content.Context
import androidx.annotation.Dimension
import io.idnow.designsystem.common.SpacingEnum
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.tokens.Typography

internal object FormInputsStyle {
    /**
     * Label text color
     */
    val labelColor get() = Tokens.body

    /**
     * Error text color
     */
    val errorColor get() = Tokens.error

    /**
     * Helper text color
     */
    val helperColor get() = Tokens.main

    /**
     * Item margins
     */
    val itemMargin get() = Tokens.spacingSm

    /**
     * All the margins in DP
     */
    val margins = SpacingQuad()

    /**
     * Small margin for the internal part of the flag area
     */
    val flagGroupMargin get() = Tokens.spacingXs

    /**
     * Container popup background color
     */
    val popupBackgroundColor get() = Tokens.backgroundSecondary

    /**
     * Container popup background color
     */
    val popupTextColor get() = Tokens.body

    /**
     * Container popup background color
     */
    val popupCheckColor get() = Tokens.borderTertiary

    /**
     * Container stroke width
     */
    @Dimension(unit = Dimension.DP)
    val strokeWidth = 1

    /**
     * Labels font
     */
    fun font(context: Context) = Typography.BodySmall(context)


    /**
     * Items font
     */
    fun fontItem(context: Context) = Typography.Body(context)
}
