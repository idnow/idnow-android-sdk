package io.idnow.designsystem.xml_components.tab_view

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.core.util.Pools
import androidx.core.util.Pools.SynchronizedPool
import androidx.core.view.ViewCompat
import com.google.android.material.tabs.TabLayout
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.styles.TabLayoutStyle
import io.idnow.designsystem.xml_components.extension.UnitLambda
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp

class IDnowTabLayout: TabLayout, IDnowMarginable {

    /** Inner tab pool for creating/reusing [IDnowTab] */
    private val tabPool: Pools.Pool<IDnowTab> = SynchronizedPool(16)

    /** Margins. Reset the layout params to update in real time the component. It allow to set the margin in the code and not only in xml. */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {

        // Retrieve all the custom attributes from XML.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowTabLayout)
        /** Handle the component margin. */
        val margin = customArray.getInt(R.styleable.IDnowTabLayout_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowTabLayout_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowTabLayout_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowTabLayout_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowTabLayout_token_endMargin, -1)

        margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)

        customArray.recycle()
        initialize()
    }

    private fun initialize() {
        /** Apply custom background drawable */
        val bgDrawable = ResourcesCompat.getDrawable(context.resources, R.drawable.idnow_tab_layout_background, null)
        (bgDrawable as StateListDrawable).apply {
            customize(
                solidColor = TabLayoutStyle.backgroundColor,
                indexChild = 0,
                cornerRadius = TabLayoutStyle.cornerRadius.toDp(context).toFloat(),
            )
        }
        /** Apply custom setup for TabLayout */
        background = bgDrawable

        /** Apply the selected tab indicator drawable and configure it */
        val tabSelectedIndicator = ResourcesCompat.getDrawable(context.resources, R.drawable.idnow_selected_tab_indicator, null)
        (tabSelectedIndicator as GradientDrawable).apply {
            customize(
                solidColor = TabLayoutStyle.selectedTabColor,
                cornerRadius = TabLayoutStyle.cornerRadius.toDp(context).toFloat(),
            )
        }
        setSelectedTabIndicator(tabSelectedIndicator)
        setSelectedTabIndicatorGravity(INDICATOR_GRAVITY_STRETCH)
        setSelectedTabIndicatorColor(TabLayoutStyle.selectedTabColor)

        /** Remove the tab ripple effect */
        tabRippleColor = null
        /** Set tab gravity and tab mode */
        tabGravity = GRAVITY_FILL
        tabMode = MODE_FIXED
        /** Mark inline label so internal tabLayout won't add additional top/bottom margins to tab icon */
        isInlineLabel = true
        /** Set tab selected icon tint */
        val states = arrayOf(intArrayOf(android.R.attr.state_selected), intArrayOf())
        val colors = intArrayOf(TabLayoutStyle.selectedTabTextColor, TabLayoutStyle.defaultTabTextColor)
        tabIconTint = ColorStateList(states, colors)
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        /** Always update the margin with the one set in the component. */
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value,
            margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    /** Override the new tab method to remove the padding of the [TabView] that will be created. */
    override fun newTab(): Tab {
        val tab = super.newTab()
        ViewCompat.setPaddingRelative(tab.view, 0, 0, 0, 0)
        return tab
    }

    /**
     * Override the [createTabFromPool] to return [IDnowTab] instance .
     * The [newTab] method needs to be left as it is because the [TabView] class can only pe set
     * and customized internally
     */
    override fun createTabFromPool(): Tab {
        var tab = tabPool.acquire()
        if (tab == null) {
            tab = IDnowTab(context)
        }
        return tab
    }

    /** Override the [releaseFromTabPool] to release the [IDnowTab] instance */
    override fun releaseFromTabPool(tab: Tab): Boolean {
        return tabPool.release(tab as IDnowTab)
    }

    /** Allow only [IDnowTab] instance */
    override fun addTab(tab: Tab) {
        withIDnowTab(tab) {
            super.addTab(tab)
        }
    }

    /** Allow only [IDnowTab] instance */
    override fun addTab(tab: Tab, position: Int) {
        withIDnowTab(tab) {
            super.addTab(tab, position)
        }
    }

    /** Allow only [IDnowTab] instance */
    override fun addTab(tab: Tab, setSelected: Boolean) {
        withIDnowTab(tab) {
            super.addTab(tab, setSelected)
        }
    }

    /** Allow only [IDnowTab] instance */
    override fun addTab(tab: Tab, position: Int, setSelected: Boolean) {
        withIDnowTab(tab) {
            super.addTab(tab, position, setSelected)
        }
    }

    /** Check if a tab is an [IDnowTab]. Otherwise throw an [IllegalArgumentException] */
    private fun withIDnowTab(tab: Tab, lambda: UnitLambda) {
        if(tab !is IDnowTab) throw IllegalArgumentException("Adding is allowed only for tabs created via IDnowTabLayout.newTab()")
        lambda()
    }
}