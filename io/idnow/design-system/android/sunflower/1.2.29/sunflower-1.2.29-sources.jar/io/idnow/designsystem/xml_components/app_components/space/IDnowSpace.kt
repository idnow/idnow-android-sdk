package io.idnow.designsystem.xml_components.app_components.space

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.xml_components.extension.applyMargin

/**
 * Customizable space component with margins.
 */
class IDnowSpace: View, IDnowMarginable {
    /** region Public Properties */
    /** Margins. Reset the layout params to update in real time the component.
     * It allows to set the margin in the code or in xml.
     */
    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams}
        }
    /** endregion */

    /** region Init */
    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?): this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        // Get attributes from xml.
        val customArray = context.obtainStyledAttributes(attrs, R.styleable.IDnowSpace)
        // Setup the margins token according to given xml attribute.
        val margin = customArray.getInt(R.styleable.IDnowSpace_token_margin, -1)
        val topMargin = customArray.getInt(R.styleable.IDnowSpace_token_topMargin, -1)
        val bottomMargin = customArray.getInt(R.styleable.IDnowSpace_token_bottomMargin, -1)
        val startMargin = customArray.getInt(R.styleable.IDnowSpace_token_startMargin, -1)
        val endMargin = customArray.getInt(R.styleable.IDnowSpace_token_endMargin, -1)
        margins = SpacingQuad().handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)
        customArray.recycle()
        visibility = INVISIBLE
    }
    /** endregion */

    /** region Override Methods */
    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        // Add margins to current params.
        val mParams = params?.applyMargin(
            context,
            margins.start.value,
            margins.top.value,
            margins.end.value,
            margins.bottom.value)
        super.setLayoutParams(mParams)
    }

    override fun onDraw(canvas: Canvas) {

    }
    /** endregion*/
}