package io.idnow.designsystem.xml_components.controls.radio

import android.content.Context
import android.graphics.Rect
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatRadioButton
import androidx.core.content.res.ResourcesCompat
import io.idnow.designsystem.R
import io.idnow.designsystem.styles.ControlStyle
import io.idnow.designsystem.xml_components.controls.common.Size
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp

internal class IDnowRadioButtonInternal : AppCompatRadioButton {
    /** Internal usage only ! Notify a control of a change. */
    var onInternalChange: (() -> Unit)? = null

    /** Size of the check box */
    var size: Size = Size.NORMAL
        set(value) {
            field = value
            setupDrawable()
        }

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    override fun toggle() {
        /* Only trigger the state changes if the radio is enabled */
        if(isEnabled) {
            isChecked = !isChecked
        }
    }

    override fun setChecked(checked: Boolean) {
        /** Notify internally */
        onInternalChange?.invoke()
        super.setChecked(checked)
    }

    private fun setupDrawable() {
        val drawable = ResourcesCompat.getDrawable(context.resources, R.drawable.idnow_radio_button, null)
        val bounds = Rect(0, 0, ControlStyle.controlSize(size).toDp(context), ControlStyle.controlSize(size).toDp(context))
        (drawable as StateListDrawable).apply {
            /** Customization of checked state */
            customize(
                indexChild = 0,
                multipleItem = true,
                innerChild = 0,
                strokeWidth = ControlStyle.strokeWidth().toDp(context),
                strokeColor = ControlStyle.activeColor,
                bounds = bounds)
            // No bounds for this ones, it will take the space left by its parent.
            customize(
                indexChild = 0,
                multipleItem = true,
                innerChild = 1,
                solidColor = ControlStyle.activeColor)
            /** Customization of unchecked state */
            customize(
                indexChild = 1,
                strokeWidth = ControlStyle.strokeWidth().toDp(context),
                strokeColor = ControlStyle.strokeColor,
                bounds = bounds
            )
        }
        buttonDrawable = drawable
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = ControlStyle.opacity(enabled)
    }
}