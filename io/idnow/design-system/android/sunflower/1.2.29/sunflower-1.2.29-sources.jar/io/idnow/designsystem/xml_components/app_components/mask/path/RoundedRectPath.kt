package io.idnow.designsystem.xml_components.app_components.mask.path

import android.content.Context
import android.graphics.Path
import io.idnow.designsystem.styles.MaskStyle
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad
import io.idnow.designsystem.xml_components.extension.toDp

/**
 * Create a rounded rect path with either only corners or full lines.
 * @param context to retrieve DP from pixel
 * @param useCompleteLines true to display full lines, false to display only the corners.
 */
internal class RoundedRectPath(private val context: Context, private val useCompleteLines: Boolean): PathToDisplay {
    override fun getPathToDraw(path: Path, quad: IDnowMaskQuad) {
        val cornerWidth = MaskStyle.cornerWidth.toDp(context)
        val cornerCubic = MaskStyle.cubicCornerWidth.toDp(context)
        val topLeft = quad.leftTop
        val topRight = quad.rightTop
        val bottomRight = quad.rightBottom
        val bottomLeft = quad.leftBottom

        // Point to draw the corners with the specified width
        val topLeftXCorner = topLeft.x + cornerWidth
        val topLeftYCorner = topLeft.y + cornerWidth
        val topRightXCorner = topRight.x - cornerWidth
        val topRightYCorner = topRight.y + cornerWidth
        val bottomRightXCorner = bottomRight.x - cornerWidth
        val bottomRightYCorner = bottomRight.y - cornerWidth
        val bottomLeftXCorner = bottomLeft.x + cornerWidth
        val bottomLeftYCorner = bottomLeft.y - cornerWidth

        // All the start and end point of the cubic.
        val topLeftXCubic = topLeft.x + cornerCubic
        val topLeftYCubic = topLeft.y + cornerCubic
        val topRightXCubic = topRight.x - cornerCubic
        val topRightYCubic = topRight.y + cornerCubic
        val bottomRightXCubic = bottomRight.x - cornerCubic
        val bottomRightYCubic = bottomRight.y - cornerCubic
        val bottomLeftXCubic = bottomLeft.x + cornerCubic
        val bottomLeftYCubic = bottomLeft.y - cornerCubic

        // Draws a simple square with corners only or with full lines.
        path.apply {
            fillType = Path.FillType.EVEN_ODD
            moveTo(topLeft.x.toFloat(), topLeftYCorner.toFloat())
            lineTo(topLeft.x.toFloat(), topLeftYCubic.toFloat())
            cubicTo(topLeft.x.toFloat(), topLeftYCubic.toFloat(), topLeft.x.toFloat(), topLeft.y.toFloat(), topLeftXCubic.toFloat(), topLeft.y.toFloat())
            lineTo(topLeftXCorner.toFloat(), topLeft.y.toFloat())
            goTo(topRightXCorner.toFloat(), topRight.y.toFloat(), useCompleteLines)
            lineTo(topRightXCubic.toFloat(), topRight.y.toFloat())
            cubicTo(topRightXCubic.toFloat(), topRight.y.toFloat(), topRight.x.toFloat(), topRight.y.toFloat(), topRight.x.toFloat(), topRightYCubic.toFloat())
            lineTo(topRight.x.toFloat(), topRightYCorner.toFloat())
            goTo(bottomRight.x.toFloat(), bottomRightYCorner.toFloat(), useCompleteLines)
            lineTo(bottomRight.x.toFloat(), bottomRightYCubic.toFloat())
            cubicTo(bottomRight.x.toFloat(), bottomRightYCubic.toFloat(), bottomRight.x.toFloat(), bottomRight.y.toFloat(), bottomRightXCubic.toFloat(), bottomRight.y.toFloat())
            lineTo(bottomRightXCorner.toFloat(), bottomRight.y.toFloat())
            goTo(bottomLeftXCorner.toFloat(), bottomLeft.y.toFloat(), useCompleteLines)
            lineTo(bottomLeftXCubic.toFloat(), bottomLeft.y.toFloat())
            cubicTo(bottomLeftXCubic.toFloat(), bottomLeft.y.toFloat(), bottomLeft.x.toFloat(), bottomLeft.y.toFloat(), bottomLeft.x.toFloat(), bottomLeftYCubic.toFloat())
            lineTo(bottomLeft.x.toFloat(), bottomLeftYCorner.toFloat())
            goTo(topLeft.x.toFloat(), topLeftYCorner.toFloat(), useCompleteLines)
            close()
        }
    }

    private fun Path.goTo(x: Float, y: Float, useCompleteLines: Boolean) {
        if (useCompleteLines) {
            lineTo(x, y)
        } else {
            moveTo(x, y)
        }
    }
}