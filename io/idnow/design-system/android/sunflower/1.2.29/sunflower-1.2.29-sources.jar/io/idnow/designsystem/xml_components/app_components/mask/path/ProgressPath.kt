package io.idnow.designsystem.xml_components.app_components.mask.path

import android.graphics.Path
import android.graphics.PathMeasure
import io.idnow.designsystem.xml_components.app_components.mask.IDnowMaskQuad

/**
 * Transform a static path into an animated path.
 * @param overlayToDisplay the path that we want to display with a progression.
 */
internal class ProgressPath(private val overlayToDisplay: PathToDisplay) : PathToDisplay {
    /** Keep track of the current progress */
    var progress = 0f
    override fun getPathToDraw(path: Path, quad: IDnowMaskQuad) {
        val fullPath = Path()
        overlayToDisplay.getPathToDraw(fullPath, quad)

        // Animate a path, if progress is 1f the the full path will be displayed.
        val pathMeasure = PathMeasure(fullPath, true)
        val length = pathMeasure.length
        pathMeasure.getSegment(0f, length * progress, path, true)
    }
}