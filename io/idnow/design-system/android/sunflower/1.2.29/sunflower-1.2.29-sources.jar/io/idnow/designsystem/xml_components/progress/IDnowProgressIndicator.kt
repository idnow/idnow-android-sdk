package io.idnow.designsystem.xml_components.progress

import android.content.Context
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.FloatRange
import androidx.core.content.withStyledAttributes
import androidx.core.view.setPadding
import io.idnow.designsystem.R
import io.idnow.designsystem.common.IDnowMarginable
import io.idnow.designsystem.common.SpacingQuad
import io.idnow.designsystem.databinding.IdnowProgressIndicatorBinding
import io.idnow.designsystem.styles.ContainerStyle
import io.idnow.designsystem.tokens.Tokens
import io.idnow.designsystem.xml_components.extension.applyMargin
import io.idnow.designsystem.xml_components.extension.customize
import io.idnow.designsystem.xml_components.extension.toDp
import kotlin.math.roundToInt

/**
 * The IDnowProgressIndicator component.
 *
 * The progress can either be determinate or indeterminate by setting android:indeterminate.
 */
class IDnowProgressIndicator @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
): FrameLayout(context, attrs, defStyleAttr), IDnowMarginable {
    private val binding = IdnowProgressIndicatorBinding.inflate(LayoutInflater.from(context), this)

    /**
     * The current progress.
     * Represents the progress in percent, will always be between 0.0 and 1.0, 0 being 0% and 1 being 100%.
     * Has no effect if this is indeterminate.
     */
    var progress: Float = 0.0f
        set(@FloatRange(from = 0.0, to = 1.0) value) {
            field = value.coerceIn(0.0f, 1.0f)
            with(binding.idnowProgressIndicatorBar) {
                val newProgress = (max * field.coerceIn(0.0f, 1.0f)).roundToInt()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    setProgress(newProgress, true)
                } else {
                    this@with.progress = newProgress
                }
            }
        }

    override var margins: SpacingQuad = SpacingQuad()
        set(value) {
            field = value
            post { layoutParams = layoutParams }
        }

    init {
        context.withStyledAttributes(attrs, R.styleable.IDnowProgressIndicator, defStyleAttr) {
            val margin = getInt(R.styleable.IDnowProgressIndicator_token_margin, -1)
            val topMargin = getInt(R.styleable.IDnowProgressIndicator_token_topMargin, -1)
            val bottomMargin = getInt(R.styleable.IDnowProgressIndicator_token_bottomMargin, -1)
            val startMargin = getInt(R.styleable.IDnowProgressIndicator_token_startMargin, -1)
            val endMargin = getInt(R.styleable.IDnowProgressIndicator_token_endMargin, -1)
            margins = margins.handleMargins(margin, startMargin, topMargin, endMargin, bottomMargin)

            binding.idnowProgressIndicatorBar.isIndeterminate = getBoolean(R.styleable.IDnowProgressIndicator_android_indeterminate, false)
        }

        val style = ContainerStyle.Empty
        val expectedHeight = resources.getDimension(R.dimen.idnow_progress_indicator_height).roundToInt()
        val strokeWidth = style.strokeWidth.toDp(context)
        val cornerRadius = Tokens.radiusFull.toDp(context)

        // Mandatory padding to show stroke border
        setPadding(strokeWidth)
        setBackgroundResource(R.drawable.idnow_container_background)
        (background as StateListDrawable).apply {
            customize(
                solidColor = style.backgroundColor,
                strokeColor = style.strokeColor,
                strokeWidth = strokeWidth,
                cornerRadius = cornerRadius.toFloat(),
                indexChild = 3,
            )
        }

        with(binding.idnowProgressIndicatorBar) {
            trackThickness = expectedHeight
            trackCornerRadius = cornerRadius
            trackColor = Tokens.backgroundSecondary
            setIndicatorColor(Tokens.active)
        }
    }

    override fun setLayoutParams(params: ViewGroup.LayoutParams?) {
        val mParams = params?.applyMargin(context, margins.start.value, margins.top.value, margins.end.value, margins.bottom.value)
        super.setLayoutParams(mParams)
    }
}