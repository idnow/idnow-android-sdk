package io.idnow.designsystem.customization

data class Font(
    val fontFamily: FontFamily,
    val fontSize: FontSize,
    val fontWeight: FontWeight
) {
    companion object {
        /**
         * Override the constructor to allow to send nullable without losing the default values.
         * It will simplify the integration as the server might send a lot a null values.
         */
        operator fun invoke(
            fontFamily: FontFamily? = null,
            fontSize: FontSize? = null,
            fontWeight: FontWeight? = null
        ) = Font(
            fontFamily = fontFamily ?: FontFamily(),
            fontSize = fontSize ?: FontSize(),
            fontWeight = fontWeight ?: FontWeight()
        )
    }
}
